日期: 2018-06-27
# 祉云医疗 1.5 文档
#### 索引

[用户注册：/api/users](#用户注册)

[用户快速登录并更新信息：/api/user/quick/login](#用户快速登录并更新信息)

[机构注册：/api/agencies](#机构注册)

[通用登录：/api/commonlogin](#通用登录)

[用户修改密码：/api/users/resetPassword](#用户修改密码)

[机构修改密码：/api/agency/resetPassword](#机构修改密码)

[用户所有报告列表：/api/reportsAll](#用户所有报告列表)

## 用户机构账号管理

*****
#### 用户注册
[返回索引](#索引)

**POST**

*接口： /api/users*

**用于A机构下用户注册**

body

**Media type:**
json

**Type:**
object

**Properties:**
* **name** : nullable(string) 姓名
* **birthday** : nullable(string) 生日（年龄、生日传一个即可）
* **age** : nullable(string) 年龄
* **gender** : required(string) 1男 2女
* **height** : required(integer) 身高　单位cm
* **weight** : required(integer) 体重　单位kg
* **medical_history** : nullable(array of) 病史列表, 可为空
* **cellphone** : required(string) 用户手机号
* **code** : required(string) 手机号验证码
* **password** : required(string) 登录密码
* **agency_key** : nullable(string) 机构key
* **vendor_code** : nullable(string) 厂商码

请求
```json
{
    "cellphone": "13636382436",
    "code": "131123",
    "password": "123456",
    "name": "lei",
    "age": "20"
    "gender": 1,
    "height": 170,
    "weight": 65,
    "vendor_code": "aaa",
}
```

返回
```json
{
    "age": 20,
    "avatar": null,
    "birthday": "1998-06-26",
    "cellphone": "13636382436",
    "gender": 1,
    "height": 170,
    "id": 38,
    "medical_history": [],
    "name": "lei",
    "report_num": 0,
    "weight": 65
}
```


*****
#### 用户快速登录并更新信息
[返回索引](#索引)

**说明：** 用户注册， 如果用户已注册则更新信息， 然后返回用户登录后信息
**POST**

*接口: /api/user/quick/login*

**用途： 用于用户注册兼登录， 返回的是一个带有用户token的用户信息**

body:

**Media type:**
json

**Type:**
object

**Properties:**
* **cellphone** : required(string) 用户手机号
* **age** : nullable(string) 年龄
* **gender** : required(string) 1男 2女
* **height** : required(integer) 身高　单位cm
* **weight** : required(integer) 体重　单位kg


请求
```json
{
    "cellphone": "13636382439",
    "age": "20",
    "gender": 1,
    "height": 170,
    "weight": 65
}

```

返回
```json
{
    "Info": {
        "age": 20,
        "avatar": null,
        "birthday": "2008-06-19",
        "cellphone": "13636382439",
        "gender": 1,
        "height": 170,
        "id": 2,
        "medical_history": [],
        "name": null,
        "report_num": 0,
        "weight": 65
    },
    "expiresAt": 1530074349,
    "issuedAt": 1529987949,
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1MzAwNzQzNTAsImlhdCI6MTUyOTk4Nzk1MCwibmJmIjoxNTI5OTg3OTUwLCJ1c2VyX2lkIjoyfQ.Rwb2-w_KgGbqc2CiJHdy7lIYgcqkpQwXGW26DnlS-eo",
    "type": "user"
}
```

*****
#### 机构注册
[返回索引](#索引)

**POST**

*接口: /api/agencies*

**用途： 用于机构注册， 必须带一个有效的厂商码**

body:

**Media type:**
json

**Type:**
object

**Properties:**
* **name** : nullable(string) (机构名字）
* **loginName** : required(string) (机构登录名）
* **password** : required(string) 登录密码
* **key** : nullable(string)
* **anonymousReport** : 0代表A机构 1代表B机构
* **vendor_code** : 厂商码

请求
```json
{
    "loginName": "lei1",
    "password": "123",
    "vendor_code": "aaa",
    "anonymousReport":1
}
```

返回
```json
{
    "loginName": "lei1",
    "name": "lei1",
    "key": "lei1",
    "registration_url": "https://127.0.0.1:5000/?agencyKey=lei1#/register",
    "anonymousReport": true
}
```

*****
#### 通用登录
[返回索引](#索引)

**POST**

*接口: /api/commonlogin*

**用途： 用于机构或者用户登录， 如果是用户登录，用户注册时候必须有带厂商码**

body:

**Media type:**
json

**Type:**
object

**Properties:**
* **name** : required(string) (机构登录名或者用户手机号)
* **password** : required(string) 登录密码

请求（用户）
```json
{
    "name":"13636382435",
    "password": "123456"
}
```

返回
```json
{
    "Info": {
        "age": 10,
        "avatar": null,
        "birthday": "2008-06-19",
        "cellphone": "13636382435",
        "gender": 1,
        "height": 2,
        "id": 2,
        "medical_history": [],
        "name": null,
        "report_num": 0,
        "weight": 3
    },
    "expiresAt": 1530074349,
    "issuedAt": 1529987949,
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1MzAwNzQzNTAsImlhdCI6MTUyOTk4Nzk1MCwibmJmIjoxNTI5OTg3OTUwLCJ1c2VyX2lkIjoyfQ.Rwb2-w_KgGbqc2CiJHdy7lIYgcqkpQwXGW26DnlS-eo",
    "type": "user"
}
```

请求（机构）
```json
{
    "name":"lei",
    "password": "123"
}
```

返回
```json
{
    "Info": {
        "anonymousReport": false,
        "key": "lei",
        "loginName": "lei",
        "name": "lei",
        "registration_url": "https://127.0.0.1:5000/?agencyKey=lei#/register"
    },
    "expiresAt": 1530074379,
    "issuedAt": 1529987979,
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1MzAwNzQzNzksImlhdCI6MTUyOTk4Nzk3OSwibmJmIjoxNTI5OTg3OTc5LCJhZ2VuY3lfaWQiOjF9.Tn9s9DTDxZPDAHlBWENjwW-nPH06dqjORshim3UN3Po",
    "type": "agency"
}
```

*****
#### 用户修改密码
[返回索引](#索引)

**POST**

*接口: /api/users/resetPassword*

body:

**Media type:**
json

**Type:**
object

**Properties:**
* **cellphone** : required(string) 用户手机号
* **code** : required(string) 验证码
* **new_password** : required(string) 新密码

请求
```
{
    "cellphone": "13636382436",
    "code": "863878",
    "new_password": "12345"
}
```

返回
```
{
    "age": 20,
    "avatar": null,
    "birthday": "1998-06-26",
    "cellphone": "13636382436",
    "gender": 1,
    "height": 170,
    "id": 38,
    "medical_history": [],
    "name": "lei",
    "report_num": 0,
    "weight": 65
}
```

*****
#### 机构修改密码
[返回索引](#索引)

**POST**

*接口: /api/agency/resetPassword*

**用途： 用于机构修改密码， 必须是带厂商码注册的机构**

body:

**Media type:**
json

**Type:**
object

**Properties:**
* **name** : required(string) 机构登录名
* **new_password** : required(string) 新密码
* **vendor_code** : required(string) 厂商码

请求
```json
{
    "name": "lei",
    "new_password": "1234",
    "vendor_code": "aaa"
}
```

返回
```json
{
    "loginName": "lei",
    "name": "lei",
    "key": "lei",
    "registration_url": "https://127.0.0.1:5000/?agencyKey=lei#/register",
    "anonymousReport": false
}
```

## 报告列表

*****
#### 用户所有报告列表
[返回索引](#索引)

**GET**

*接口: /api/reportsAll*

head:

**X-ZHIYUN-USER-TOKEN:**
token对应本次请求具体用户

返回
```
{
    "data": [
        {
            "report_url": "https://m-test.zhiyuntcm.com/#/history/SREBUO4Bpa3OHYYg",
            "health_score": 81,
            "time": "Tue, 05 Jun 2018 10:12:13 -0000",
            "display_time": "2018-06-05 18:12 小满过15天"
        },
        {
            "report_url": "https://m-test.zhiyuntcm.com/#/history/SRKTti98Il6Jpdgw",
            "health_score": 81,
            "time": "Tue, 05 Jun 2018 10:12:48 -0000",
            "display_time": "2018-06-05 18:12 小满过15天"
        }
    ]
}
```