from setuptools import setup, find_packages

setup(
    name='ExaminationModalApi',
    version='1.0',
    long_description=__doc__,
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        'Flask', 'Flask-RESTful', 'requests',
        'eacal', 'pytz', 'oss2', 'wechatpy',
        'PyJWT', 'Flask-JWT', 'Flask-Cache',
        'Flask-Migrate', 'Flask-SQLAlchemy',
    ],
)
