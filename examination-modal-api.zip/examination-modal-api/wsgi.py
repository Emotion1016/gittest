from ExaminationModalApi import app
from flask_cors import CORS

CORS(app, supports_credentials=True)

if __name__ == "__main__":
    print(app.url_map)
    app.run()