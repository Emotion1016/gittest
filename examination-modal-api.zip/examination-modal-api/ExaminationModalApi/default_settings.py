DEBUG = False  # make sure DEBUG is off unless enabled explicitly otherwise
LOG_DIR = './log/'  # create log files in current working directory
