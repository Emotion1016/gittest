import os
import redis

from flask import Flask, Blueprint
from flask_bcrypt import Bcrypt
from flask_cache import Cache
from flask_jwt import JWT
from flask_migrate import Migrate
from flask_restful import Api
from flask_sqlalchemy import SQLAlchemy
from wechatpy import WeChatClient
from wechatpy.client.api import WeChatJSAPI, WeChatMedia, WeChatQRCode

from ExaminationModalApi.content_loader.storage import MemoryStorage
from ExaminationModalApi.extension.safer_proxy_fix import SaferProxyFix
from ExaminationModalApi.service.oss import Bucket
from ExaminationModalApi.service.sms import AliSms
from ExaminationModalApi.util import front_page_url_handler

DEFAULT_PAGINATION_ITEM_NUM = 25

app = Flask(__name__)
app.wsgi_app = SaferProxyFix(app.wsgi_app)

app.config.from_object('ExaminationModalApi.default_settings')
app.config.from_envvar('EXAMINATIONMODALAPI_SETTINGS')

app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024

app.url_build_error_handlers.append(front_page_url_handler)

if not app.debug:
    import logging
    from logging.handlers import TimedRotatingFileHandler

    # https://docs.python.org/3.6/library/logging.handlers.html#timedrotatingfilehandler
    file_handler = TimedRotatingFileHandler(os.path.join(app.config['LOG_DIR'], 'ExaminationModalApi.log'), 'midnight')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        logging.Formatter('[%(asctime)s>] [%(levelname)s] <-%(filename)s-%(funcName)s-line %(lineno)s>  %(message)s')
    )
    app.logger.addHandler(file_handler)
    app.logger.setLevel(logging.DEBUG)

api_bp = Blueprint('api', __name__)
api = Api(api_bp)
api16_bp = Blueprint('api16', __name__)
api16 = Api(api16_bp)
api30_bp = Blueprint('api30', __name__)
api30 = Api(api30_bp)
openapi_bp = Blueprint('openapi', __name__)
openapi = Api(openapi_bp, prefix='/openapi')
db = SQLAlchemy(app)
migrate = Migrate(app, db)
bcrypt = Bcrypt(app)

wechat_client = WeChatClient(app.config['APPID'], app.config['SECRET'])
jsapi = WeChatJSAPI(wechat_client)
wechat_media = WeChatMedia(wechat_client)
qrcode_client = WeChatQRCode(wechat_client)

app.content_storage = MemoryStorage()
app.content_storage.load(app.config['CONTENT_DIR'])
cache = Cache(app, config={'CACHE_TYPE': 'simple'})
jwt = JWT(app)

import ExaminationModalApi.model

from . import jwt_login

app.bucket = Bucket(
    app.config['OSS_ACCESS_KEY_ID'],
    app.config['OSS_ACCESS_KEY_SECRET'],
    app.config['OSS_ENDPOINT'],
    app.config.get('OSS_INTERNAL_ENDPOINT'),
    app.config['OSS_BUCKET'],
    logger=app.logger
)

app.sms = AliSms(
    app.config['SMS_ACCESS_KEY_ID'],
    app.config['SMS_ACCESS_KEY_SECRET'],
    logger=app.logger
)

redis_conn = redis.Redis()

import ExaminationModalApi.command

import ExaminationModalApi.views


# from ExaminationModalApi.blueprints.wechat import wechat_blueprint
# app.register_blueprint(wechat_blueprint)


from ExaminationModalApi.blueprints.test_tool import test_tool_blueprint
if app.config.get('USE_MODAL_TEST_TOOL', False):
    app.register_blueprint(test_tool_blueprint)

import ExaminationModalApi.api
import ExaminationModalApi.api16
import ExaminationModalApi.api30
import ExaminationModalApi.openapi

app.register_blueprint(api_bp)
app.register_blueprint(api16_bp)
app.register_blueprint(api30_bp)
app.register_blueprint(openapi_bp)
