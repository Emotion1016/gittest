from collections import OrderedDict


def make_content(name, symptom, content, picture):
    return {
        'symptom': symptom,
        'name': name,
        'content': content,
        'asset': picture,
    }


def group_content(contents):
    ans = OrderedDict()
    for c in contents:
        ans.setdefault(c['symptom'], list()).append(c)
    return ans
