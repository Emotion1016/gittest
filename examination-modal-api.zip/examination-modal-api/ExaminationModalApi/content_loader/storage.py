import os

from ExaminationModalApi.content_loader.content import group_content
from ExaminationModalApi.content_loader.csvloader import load as csvloader

CONTENT_DIET_THERAPY = 'diet_therapy'
CONTENT_HERB_TEA = 'herb_tea'
CONTENT_HEALTH_PRINCIPLE = 'health_principle'
CONTENT_HEALTH_GUIDANCE = 'health_guidance'
CONTENT_SYMPTOM_DEFINITION = 'symptom_definition'
CONTENT_MASSAGE = 'massage'
CONTENT_MUSIC = 'music'
CONTENT_MUSIC_HOMEPAGE = 'music_homepage'
CONTENT_VIDEO = 'video'
CONTENT_PRESCRIPTION = 'prescription'
CONTENT_GOOD_FOOD = 'good_food'
CONTENT_BAD_FOOD = 'bad_food'
CONTENT_DISEASE_ALL = 'disease_all'
CONTENT_DISEASE_MALE = 'disease_male'
CONTENT_DISEASE_FEMALE = 'disease_female'
CONTENT_HEALTH_RISK = 'health_risk'
CONTENT_FACE_RESULT = 'face_result'
CONTENT_TONGUE_RESULT = 'tongue_result'
CONTENT_MOXIBUSTION = 'moxibustion'
CONTENT_MOXIBUSTION_WUXING = 'moxibustion_wuxing'

TIZHI_DEFINITION = 'tizhi_definition'
TIZHI_TEA = 'tizhi_tea'
TIZHI_MASSAGE = 'tizhi_massage'
TIZHI_GOOD_FOOD = 'tizhi_good_food'
TIZHI_BAD_FOOD = 'tizhi_bad_food'
TIZHI_DIET_THERAPY = 'tizhi_diet_therapy'

ALL_CONTENT_TYPES = (
    CONTENT_DIET_THERAPY, CONTENT_HERB_TEA, CONTENT_HEALTH_PRINCIPLE, CONTENT_SYMPTOM_DEFINITION, CONTENT_MASSAGE,
    CONTENT_MUSIC, CONTENT_VIDEO, CONTENT_HEALTH_GUIDANCE, CONTENT_PRESCRIPTION, CONTENT_GOOD_FOOD, CONTENT_BAD_FOOD,
    CONTENT_DISEASE_ALL, CONTENT_DISEASE_MALE, CONTENT_DISEASE_FEMALE, CONTENT_HEALTH_RISK, CONTENT_MOXIBUSTION,
    CONTENT_MOXIBUSTION_WUXING
)

ALL_CONTENT_TYPES_TIZHI = (
    TIZHI_DEFINITION,
    TIZHI_TEA,
    TIZHI_MASSAGE,
    TIZHI_GOOD_FOOD,
    TIZHI_BAD_FOOD,
    TIZHI_DIET_THERAPY,
)


class BaseStorage(object):
    def load(self, dir):
        raise NotImplementedError()

    @property
    def content(self):
        raise NotImplementedError()


def isnumber(s):
    numbers = [str(i) for i in range(0, 10)]
    return all(c in numbers for c in s)


solution_count = {
    CONTENT_DIET_THERAPY: 3,
    CONTENT_PRESCRIPTION: 3,
    CONTENT_BAD_FOOD: 10,
    CONTENT_GOOD_FOOD: 10,
    CONTENT_DISEASE_ALL: 10,
    CONTENT_DISEASE_MALE: 10,
    CONTENT_DISEASE_FEMALE: 10,
    CONTENT_MOXIBUSTION: 3,
    TIZHI_GOOD_FOOD: 10,
    TIZHI_BAD_FOOD: 10,
}


class MemoryStorage(BaseStorage):
    to_load = {
        CONTENT_HEALTH_PRINCIPLE: {
            'path': '保健原则-20181212.csv',
            'with_title': True,
            'name_column': 0,
            'symptom_column': 0,
            'content_columns': [2, 3],
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_SYMPTOM_DEFINITION: {
            'path': '病症定义-20181102.csv',
            'with_title': True,
            'name_column': 0,
            'symptom_column': 0,
            'content_columns': list(range(1, 7)),
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_MASSAGE: {
            'path': '穴位按压-20180205.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [2, 3, ],
            'asset_columns': [1, ],
            'asset_formatter': '穴位按压/{}.jpg',
        },
        CONTENT_HERB_TEA: {
            'path': '茶饮.csv',
            'with_title': True,
            'name_column': 2,
            'symptom_column': 0,
            'content_columns': [3, 4],
            'asset_columns': [2, ],
            'asset_formatter': '茶饮/{}.jpg',
        },
        CONTENT_DIET_THERAPY: {
            'path': '药膳-20180620.csv',
            'with_title': True,
            'name_column': 2,
            'symptom_column': 0,
            'content_columns': [3, 4],
            'asset_columns': list(range(7, 34)),
            'asset_formatter': lambda assets: [
                (name, '药材库/{}.jpg'.format(herb_id) if isnumber(herb_id) else '食材库/{}.jpg'.format(food_id))
                for name, food_id, herb_id in
                [(assets[n], assets[n + 1], assets[n + 2]) for n in range(0, len(assets), 3)]
                if name
            ]
        },
        CONTENT_MUSIC: {
            'path': '音乐列表.csv',
            'with_title': False,
            'name_column': 2,
            'symptom_column': 1,
            'content_columns': [],
            'asset_columns': [0, 3],
            'asset_formatter': lambda assets: ['养生音乐' + assets[0].replace('\\', '/'),
                                               '养生音乐' + assets[1].replace('\\', '/')],
        },
        CONTENT_VIDEO: {
            'path': '视频列表-20180921.csv',
            'with_title': False,
            'name_column': 2,
            'symptom_column': 1,
            'content_columns': [],
            'asset_columns': [0, 3],
            'asset_formatter': lambda assets: ['功法' + assets[0].replace('\\', '/'),
                                               '功法' + assets[1].replace('\\', '/')],
        },
        CONTENT_HEALTH_GUIDANCE: {
            'path': '起居指导-20180326.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [2, ],
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_PRESCRIPTION: {
            'path': '中成药经典方目录_20190114.csv',
            'with_title': True,
            'name_column': 2,
            'symptom_column': 0,
            'content_columns': [3, 4, 5, 6, 7],
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_GOOD_FOOD: {
            'path': '病症宜食1022.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [],
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_BAD_FOOD: {
            'path': '病症忌食0913.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [],
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_DISEASE_ALL: {
            'path': '20180830易患疾病列表.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [],
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_DISEASE_MALE: {
            'path': '20180830易患疾病列表-male.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [],
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_DISEASE_FEMALE: {
            'path': '20180830易患疾病列表-female.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [],
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_MUSIC_HOMEPAGE: {
            'path': '音乐列表-homepage-20180921.csv',
            'with_title': False,
            'name_column': 2,
            'symptom_column': 0,
            'content_columns': [],
            'asset_columns': [3, 4],
            'asset_formatter': lambda assets: ['养生音乐' + assets[0].replace('\\', '/'),
                                               '养生音乐' + assets[1].replace('\\', '/')],
        },
        CONTENT_HEALTH_RISK: {
            'path': '健康风险提示-2018-11-03.csv',
            'with_title': True,
            'name_column': 0,
            'symptom_column': 0,
            'content_columns': [1],
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_FACE_RESULT: {
            'path': 'face_result_2018-11-08.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': list(range(2, 7)),
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_TONGUE_RESULT: {
            'path': 'tongue_result_2018-11-08.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': list(range(2, 7)),
            'asset_columns': None,
            'asset_formatter': None,
        },
        CONTENT_MOXIBUSTION: {
            'path': '艾灸-20190408.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [2, ],
            'asset_columns': [1, ],
            'asset_formatter': '艾灸/{}.jpg',
        },
        CONTENT_MOXIBUSTION_WUXING: {
            'path': '艾灸-五行熏蒸.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': list(range(2, 12)),
            'asset_columns': None,
            'asset_formatter': None,
        },

        TIZHI_DEFINITION: {
            'path': '体质-定义-20190611.csv',
            'with_title': True,
            'name_column': 0,
            'symptom_column': 0,
            'content_columns': [1, 2, 3],
            'asset_columns': None,
            'asset_formatter': None,
        },
        TIZHI_TEA: {
            'path': '体质-茶饮-20190611.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [2, 3],
            'asset_columns': [1, ],
            'asset_formatter': '茶饮/{}.jpg',
        },
        TIZHI_MASSAGE: {
            'path': '体质-穴位-20190611.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [2],
            'asset_columns': [1, ],
            'asset_formatter': '穴位按压/{}.jpg',
        },
        TIZHI_GOOD_FOOD: {
            'path': '体质-宜食-20190611.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [],
            'asset_columns': None,
            'asset_formatter': None,
        },
        TIZHI_BAD_FOOD: {
            'path': '体质-忌食-20190611.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [],
            'asset_columns': None,
            'asset_formatter': None,
        },
        TIZHI_DIET_THERAPY: {
            'path': '体质-药膳-20190611.csv',
            'with_title': True,
            'name_column': 1,
            'symptom_column': 0,
            'content_columns': [2],
            'asset_columns': [1, ],
            'asset_formatter': '体质药膳/{}.jpg',
        },
    }

    def __init__(self):
        self._content = {}

    def load(self, dir):
        for category, meta in self.to_load.items():
            meta['path'] = os.path.join(dir, meta['path'])
            self._content[category] = group_content(csvloader(check_asset_file=False, **meta))

    @property
    def content(self):
        return self._content


if __name__ == '__main__':
    import pprint

    s = MemoryStorage()
    s.load('.')
    pprint.pprint(s.content)
