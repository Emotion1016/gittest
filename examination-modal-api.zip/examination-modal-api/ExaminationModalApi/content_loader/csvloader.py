import csv
from logging import getLogger

from os.path import isfile

from .content import make_content, group_content

L = getLogger(__name__)


def load(path, with_title, name_column, symptom_column, content_columns, asset_columns, asset_formatter,
         check_asset_file=True):
    ans = list()
    with open(path, newline='') as csvfile:
        reader = csv.reader(csvfile)
        i = iter(reader)
        if with_title:
            next(i)
        for row in i:
            content = []
            name = row[name_column].strip()
            symptom = row[symptom_column].strip()
            for col in content_columns:
                if row[col].strip():
                    content.extend(row[col].strip().split('\n'))
            if asset_columns is None:
                asset = None
            elif callable(asset_formatter):
                asset = asset_formatter([row[col].strip() for col in asset_columns])
            else:
                asset = list(map(lambda idx: asset_formatter.format(row[idx].strip()), asset_columns))
            if check_asset_file and asset and not isfile(asset):
                L.warning('picture file %s not exists.', asset)
            ans.append(make_content(name, symptom, content, asset))
    return ans
