from flask import jsonify
from flask_restful import fields, marshal

from ExaminationModalApi import api_bp
from ExaminationModalApi.jwt_login import end_user_required, local_user
from ExaminationModalApi.model.daily_report import DailyReport
from ExaminationModalApi.model.report import simple_report_fields, Report

event_report_fields = {
    'best': fields.Nested(simple_report_fields),
    'first': fields.Nested(simple_report_fields),
    'latest': fields.Nested(simple_report_fields),
    'worst': fields.Nested(simple_report_fields),
}


@api_bp.route('/api/statistics/events', methods=['GET'])
@end_user_required()
def health_event():
    query = DailyReport.query.filter(
        DailyReport.owner_id == local_user.id
    ).join(Report)
    data = {
        'first': query.order_by(DailyReport.date).first().report,
        'latest': query.order_by(DailyReport.date.desc()).first().report,
        'best': query.order_by(
            Report.health_score.desc()
        ).order_by(DailyReport.date.desc()).first().report,
        'worst': query.order_by(
            Report.health_score
        ).order_by(DailyReport.date.desc()).first().report,
    }
    return jsonify(marshal(data, event_report_fields))
