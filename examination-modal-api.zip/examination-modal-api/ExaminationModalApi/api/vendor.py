# -*- encoding: utf-8 -*-
from flask_restful import Resource, abort, reqparse, marshal_with

from ExaminationModalApi.model.vendor import Vendor, vendor_field
from ExaminationModalApi.model.util import Status
from ExaminationModalApi import api


class VendorResource(Resource):
    @marshal_with(vendor_field)
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('vendor_code', help='vendor code', required=True)
        args = parser.parse_args()
        vendor_code = args.get('vendor_code')
        if vendor_code:
            vendor = Vendor.query.filter(Vendor.code == vendor_code).first()
            if vendor:
                if vendor.del_flag == 1:
                    return abort(410, error='厂商码已过期')
                else:
                    return vendor
            else:
                abort(410, error='厂商码不存在')
        else:
            abort(410, error='厂商码为空')


api.add_resource(VendorResource, '/api/vendor')
