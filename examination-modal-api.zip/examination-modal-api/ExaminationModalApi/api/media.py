from flask import jsonify
from ExaminationModalApi.examination.solution import pick_solution
from ExaminationModalApi import api_bp, app
from ExaminationModalApi.content_loader.storage import CONTENT_VIDEO, CONTENT_MUSIC_HOMEPAGE, CONTENT_MUSIC
from ExaminationModalApi import cache


@cache.cached(3600*2)
@api_bp.route('/api/media')
def media():
    content_types = (CONTENT_VIDEO, CONTENT_MUSIC_HOMEPAGE)
    rename = {
        CONTENT_MUSIC_HOMEPAGE: CONTENT_MUSIC,
        CONTENT_VIDEO: CONTENT_VIDEO
    }
    symptoms = ['健康', '气虚', '痰湿', '肾虚', '脾虚', '郁滞', '阳虚', '阴虚']
    content = app.content_storage.content
    solutions = dict()
    for content_type in content_types:
        content_name = content.get(content_type, None)
        r_name = rename[content_type]
        solutions[r_name] = []
        if not content_name:
            solutions[r_name] = None
            continue
        for name in symptoms:
            idx_list, s = pick_solution(content_name, name, require_count=100)
            if idx_list:

                for i in s:
                    i['symptom'] = ''
                solutions[r_name].extend(s)

    solutions['asset_prefix'] = app.config['CONTENT_ASSET_URL_PREFIX']

    return jsonify(solutions)
