import re
import hashlib
from flask import current_app
from flask_restful import Resource, reqparse, marshal_with, fields, abort
from sqlalchemy import desc, func

from ExaminationModalApi import bcrypt, db, DEFAULT_PAGINATION_ITEM_NUM, api
from ExaminationModalApi.jwt_login import agency_required, local_agency
from ExaminationModalApi.model.agency import Agency, simple_agency_fields
from ExaminationModalApi.model.daily_report import DailyReport
from ExaminationModalApi.model.admin import Admin
from ExaminationModalApi.model.report import Report
from ExaminationModalApi.model.util import add_photos_url
from ExaminationModalApi.api.user import to_vendor
import time


class AgencyList(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('name', type=str, help='name of the agency')
    parser.add_argument('loginName', type=str, help='login name of the agency', required=True)
    parser.add_argument('password', type=str, help='password of the agency', required=True)
    parser.add_argument('key', type=str, help='key of the agency')
    parser.add_argument('anonymousReport', type=bool, help='if end user mobile phone necessary for examination',
                        required=True)
    parser.add_argument('vendor_code', dest='vendor', type=to_vendor, help='vendor identification code', required=True)

    @marshal_with(simple_agency_fields)
    def post(self):
        args = self.parser.parse_args()
        name = args['name'] or args['loginName']
        # 11位手机号不可以注册
        if re.match(r'^1[345789][0-9]{9}$', name):
            abort(413, error='机构已注册')
        password = bcrypt.generate_password_hash(args['password'], 10)
        vendor = args.get('vendor')
        if vendor.type:
            abort(410, error='厂商码在当前版本不可用')
        if vendor and vendor.del_flag != 1:
            if Agency.query.filter(Agency.login_name == args['loginName']).first():
                abort(413, error='机构已注册')

            agency = Agency(
                key=args['key'] or args['loginName'],
                name=name,
                login_name=args['loginName'],
                password=password.decode('utf-8'),
                anonymous_report=args['anonymousReport'],
                vendor=vendor,
                custom_id=vendor.custom_id,
                type='B' if args['anonymousReport'] else 'A'
            )
            md5_password = hashlib.md5('123456'.encode('utf-8')).hexdigest()
            admin = Admin(adminName=args['loginName'],
                          password=md5_password,
                          roleId=None,
                          realName=name,
                          deleteFlag=vendor.custom.admin_manage_flag,
                          createTime=int(time.time())
                          )
            try:
                db.session.add(agency)
                db.session.add(admin)
                db.session.commit()
            except Exception as e:
                db.session.rollback()
                current_app.logger.error('db commit error: %s' % e)
                abort(413)
            return agency
        else:
            abort(410, error='厂商码不正确或已过期')


api.add_resource(AgencyList, '/api/agencies')


class AgencyRestPassword(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('name', type=str, help='name of the agency', required=True)
    parser.add_argument('new_password', type=str, help='password of the agency', required=True)
    parser.add_argument('vendor_code', dest='vendor', type=to_vendor, help='vendor identification code', required=True)

    @marshal_with(simple_agency_fields)
    def post(self):
        args = self.parser.parse_args()
        if args.get('vendor'):
            agency = Agency.query.filter(Agency.login_name == args['name']).first()
            if agency:
                if agency.vendor != args.get('vendor'):
                    abort(410, error='厂商码不正确或已过期')
                agency.password = bcrypt.generate_password_hash(args['new_password'], 10)
                db.session.commit()
                return agency
            else:
                abort(415, error='机构未注册')

        abort(410, error='厂商码不正确或已过期')


api.add_resource(AgencyRestPassword, '/api/agency/resetPassword')


agency_user_fields = {
    'id': fields.Integer,
    'cellphone': fields.String,
    'last_report_time': fields.String,
    'face_photo_url': fields.String,
    'tongue_photo_url': fields.String
}

agency_user_list = {
    'end': fields.Boolean,
    'data': fields.List(fields.Nested(agency_user_fields))
}


def agency_user_from_report(r, id):
    u = r.owner
    # r = dr.report
    add_photos_url(r)
    return {
        'id': id,
        'cellphone': u.cellphone,
        'last_report_time': r.display_time,
        'face_photo_url': r.face_photo_url,
        'tongue_photo_url': r.tongue_photo_url,
    }


class AgencyUsers(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('pointer', default=0, type=int, help='Pointer of last list fetching')

    @agency_required()
    @marshal_with(agency_user_list)
    def get(self):
        args = self.parser.parse_args()
        pointer = args['pointer']

        # subquery = DailyReport.query.with_entities(
        #     func.max(DailyReport.report_id).label('max_report_id')
        # ).join(
        #     Report
        # ).filter(
        #     Report.agency == agency_user
        # ).group_by(Report.owner_id).order_by(
        #     desc('max_report_id')
        # ).subquery('t1')
        #
        # query = Report.query.join(
        #     subquery,
        #     Report.id == subquery.c.max_report_id
        # ).order_by(Report.id.desc())

        subquery = Report.query.with_entities(
            func.max(Report.id).label('max_report_id')
        ).filter_by(agency=local_agency).group_by('owner_id').subquery('t1')
        query = Report.query.join(subquery, Report.id == subquery.c.max_report_id).order_by(desc(Report.time))
        if pointer:
            query = query.offset(pointer)

        remaining = query.count()

        query = query.limit(current_app.config.get('LIST_FETCH_LIMIT_LEN', DEFAULT_PAGINATION_ITEM_NUM))

        return {
            'end': remaining <= current_app.config.get('LIST_FETCH_LIMIT_LEN', DEFAULT_PAGINATION_ITEM_NUM),
            'data': [agency_user_from_report(r, idx + pointer + 1) for idx, r in enumerate(query.all())]
        }


api.add_resource(AgencyUsers, '/api/agency/users')
