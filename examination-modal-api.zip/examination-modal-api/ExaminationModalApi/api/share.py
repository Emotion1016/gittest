from flask import jsonify, current_app
from flask_restful import abort, marshal

from ExaminationModalApi import api_bp, cache
from ExaminationModalApi.api.report import detail_report_with_thumb
from ExaminationModalApi.model.share import Share


@cache.cached(3600*2)
@api_bp.route('/api/share/<string:key>', methods=['GET', ], endpoint='get_share')
def get_share(key):
    query = Share.query.filter(Share.key == key).first()
    if not query or not query.report:
        abort(404)
    report = query.report
    report.face_photo_url = current_app.bucket.get_thumb_url(report.face_result.photo.oss_id, current_app.config['OSS_THUMB_IMAGE_STYLE'])
    report.tongue_photo_url = current_app.bucket.get_thumb_url(report.tongue_result.photo.oss_id,
                                                      current_app.config['OSS_THUMB_IMAGE_STYLE'])
    # current_app.logger.debug(
    #     'face_photo_url: %s, tongue_photo_url: %s',
    #     report.face_photo_url, report.tongue_photo_url
    # )
    # current_app.logger.debug('loaded: %s', pprint.pformat(dict(marshal(report, detail_report_with_thumb))))
    answer = marshal(report, detail_report_with_thumb)
    # hide the real ID
    answer['id'] = key
    return jsonify(answer)
