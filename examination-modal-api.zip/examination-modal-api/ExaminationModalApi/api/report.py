from flask import current_app
from flask_jwt import jwt_required
from flask_restful import Resource, reqparse, marshal_with, fields, marshal
from sqlalchemy import desc
from werkzeug.exceptions import abort

from ExaminationModalApi import DEFAULT_PAGINATION_ITEM_NUM, api
from ExaminationModalApi.jwt_login import local_agency, local_user, is_agency, end_user_required, login_user
from ExaminationModalApi.model.daily_report import DailyReport
from ExaminationModalApi.model.report import Report, simple_report_fields, \
    simple_shared_report_fields, detail_report_with_thumb, brief_report_fields
from ExaminationModalApi.model.util import add_photos_url

report_list_fields = {
    'end': fields.Boolean(),
    'data': fields.List(fields.Nested(simple_report_fields)),
}

shared_report_list_fields = {
    'end': fields.Boolean(),
    'data': fields.List(fields.Nested(simple_shared_report_fields)),
}

brief_report_list_fields = {
    'data': fields.List(fields.Nested(brief_report_fields))
}


class ReportBrief(Resource):
    @end_user_required()
    @marshal_with(brief_report_list_fields)
    def get(self):
        agency_id = local_agency.id if local_agency else None
        query = local_user.daily_reports.filter(Report.agency_id == agency_id, Report.mark != 2).join(Report)
        return {
            'data': [d.report for d in query.all()]
        }


api.add_resource(ReportBrief, '/api/reportsBrief')


class ReportAll(Resource):
    @end_user_required()
    @marshal_with(brief_report_list_fields)
    def get(self):
        if local_agency.type == 'A':
            query = local_agency.reports.filter(Report.agency == local_agency, Report.owner == local_user,
                                                Report.mark != 2).order_by('time')
        else:
            query = local_agency.reports.order_by('time')
        return {
            'data': query.all()
        }


api.add_resource(ReportAll, '/api/reportsAll')


class ReportList(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('pointer', type=int, help='Pointer of last list fetching')

    def list_reports(self):
        if not is_agency:
            current_app.logger.debug('list report of user %s', local_user)
            return local_user.daily_reports
        elif local_agency.anonymous_report:
            return local_agency.reports
        elif local_user:
            return local_user.daily_reports.join(Report).filter(Report.agency_id == local_agency.id)
        elif login_user:
            return login_user.reports.filter(Report.agency_id == local_agency.id, Report.mark != 2)
        current_app.logger.warning('agent %s trying to access report list without end user', local_agency)
        abort(403)

    def pointer_filter(self, pointer):
        if is_agency and local_agency.anonymous_report:
            return Report.id < pointer
        else:
            return DailyReport.report.id < pointer

    def order_column(self):
        if is_agency and local_agency.anonymous_report:
            return Report.time
        else:
            return DailyReport.date

    def retrieve_data(self, query):
        data = query[:current_app.config.get('LIST_FETCH_LIMIT_LEN', DEFAULT_PAGINATION_ITEM_NUM)]
        if is_agency and local_agency.anonymous_report:
            return data
        else:
            return [d.report for d in data]

    @jwt_required()
    def get(self):
        args = self.parser.parse_args()
        pointer = args.get('pointer')

        query = self.list_reports()
        if pointer:
            query = query.filter(self.pointer_filter(pointer))
        query = query.order_by(desc(self.order_column()))
        result = {
            'end': query.count() <= current_app.config.get('LIST_FETCH_LIMIT_LEN', DEFAULT_PAGINATION_ITEM_NUM),
            'data': list(map(add_photos_url, self.retrieve_data(query)))
        }
        if is_agency:
            return marshal(result, shared_report_list_fields)
        else:
            return marshal(result, report_list_fields)


class ReportDetail(Resource):
    @end_user_required()
    @marshal_with(detail_report_with_thumb)
    def get(self, report_id):
        query = Report.query.filter(Report.owner_id == local_user.id).filter(Report.id == report_id).first()
        if not query:
            abort(404)

        add_photos_url(query)

        return query


api.add_resource(ReportList, '/api/reports')

api.add_resource(ReportDetail, '/api/report/<report_id>')