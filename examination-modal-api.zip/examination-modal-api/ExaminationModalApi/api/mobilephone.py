import uuid
from datetime import datetime, timedelta, date
from random import Random

from flask import jsonify, current_app
from flask_restful import reqparse, fields, marshal, abort
from sqlalchemy import desc, not_

from ExaminationModalApi.model.verify_code import VerificationCode, Scope
from .. import bcrypt, db, api_bp
from ..model.user import User
from ..model.util import calculate_age
from ExaminationModalApi.model.agency_info import AgencyInfo


def to_scope(key):
    return Scope[key]


cellphone_parser = reqparse.RequestParser()
cellphone_parser.add_argument('cellphone', type=str, help='mobile phone number to check', required=True)


get_code_parser = cellphone_parser.copy()
get_code_parser.add_argument('scope', type=to_scope, help='scope of the verification code', default=Scope.register)

verify_code_parser = cellphone_parser.copy()
verify_code_parser.add_argument('code', type=str, help='code to verify', required=True)

existence_fields = {
    'cellphone': fields.String(),
    'registered': fields.Boolean(),
}


# TODO rate limitation
@api_bp.route('/api/mobilephones/exist', methods=['POST'])
def exist():
    args = cellphone_parser.parse_args()
    cellphone = args.get('cellphone')
    if not cellphone:
        abort(400)

    u = User.query.filter(User.cellphone == cellphone).first()
    if u is None or u.gender is None:
        return jsonify(marshal({
        'cellphone': cellphone,
        'registered': False}, existence_fields))

    age = calculate_age(u.birthday)

    return jsonify({
        'cellphone': cellphone,
        'registered': True,
        'name': u.name,
        'brithday': u.birthday,
        'age': age or 0,
        'gender': u.gender.value,
        'height': u.height,
        'weight': u.weight,
        'medical_history': u.medical_history_keys
    })


@api_bp.route('/api/mobilephones/getCode', methods=['POST'])
def get_code():
    args = get_code_parser.parse_args()
    cellphone = args.get('cellphone')
    scope = args.get('scope')

    # if scope == Scope.register and User.query.filter(
    #     User.cellphone == cellphone
    # ).count() or AgencyInfo.query.filter(
    #     AgencyInfo.cellphone == cellphone
    # ).count():
    #     abort(412, error='用户已注册')
        # abort(400)

    last_v = VerificationCode.query.filter(
        VerificationCode.cellphone == cellphone,
        VerificationCode.scope == scope,
        not_(VerificationCode.invalid),
    ).order_by(desc(VerificationCode.created_at)).first()

    if not last_v:
        pass
    elif (datetime.utcnow() - last_v.created_at).total_seconds() < 60:
        abort(400, error='too fast')
    elif not last_v.invalid:
        last_v.invalid = True

    if current_app.config.get('SMS_MOCK_TEST', False):
        code = cellphone[-4:]
    else:
        r = Random()
        code = ''.join([str(r.randint(0, 9)) for i in range(4)])
        current_app.sms.send_sms(
            uuid.uuid1(),
            cellphone,
            current_app.config['SMS_SIGNATURE'],
            current_app.config['SMS_REGISTER_TEMPLATE_CODE'],
            dict(code=code)
        )
    at = datetime.utcnow()
    exp = at + timedelta(seconds=5*60)

    current_app.logger.info('send code %s to cellphone %s', code, cellphone)

    v = VerificationCode(
        cellphone=cellphone,
        code=bcrypt.generate_password_hash(code, 10),
        scope=scope,
        created_at=at,
        valid_till=exp,
        invalid=False,
    )
    db.session.add(v)
    db.session.commit()

    return jsonify({
        'cellphone': cellphone,
        'nextVerify': 60,
    })


# @api_bp.route('/api/mobilephones/verifyCode', methods=['POST'])
# @agency_required()
def verify_code():
    args = verify_code_parser.parse_args()
    cellphone = args.get('cellphone')
    code = args.get('code')
    if not cellphone or not code:
        abort(400)

    v = VerificationCode.query.filter(
        VerificationCode.cellphone == cellphone,
    ).order_by(desc(VerificationCode.created_at)).first()

    code_ok = v and not v.invalid and v.valid_till > datetime.utcnow() and bcrypt.check_password_hash(v.code, code)
    if code_ok:
        v.invalid = True
    db.session.commit()

    ans = jsonify({
        'cellphone': cellphone,
        'ok': code_ok,
    })


    return ans