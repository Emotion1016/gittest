import pprint
import os
from datetime import datetime
from enum import Enum
from functools import wraps
from typing import Optional
from uuid import uuid4

import requests
from flask import request, jsonify, abort, current_app
from flask_restful import marshal
from pydiagnosis import face, tongue

from .. import wechat_media, db, api_bp
from ..util import https_for
from ..model.util import add_photo_url_when_upload
from ..jwt_login import local_user, local_agency, end_user_required, agency_required
from ..model.face_result import FaceResult, basic_face_result_fields_with_url
from ..model.photo import Photo
from ..model.tongue_result import TongueResult, basic_tongue_result_fields_with_url
from ExaminationModalApi.api16.photo import save_analyze_result, PhotoType


ANALYZE_FUNCTIONS = {
    PhotoType.face: face,
    PhotoType.tongue: tongue,
}


def get_wechat_media() -> (str, bytes):
    mid = request.json.get('id')
    if not mid:
        abort(400)
    try:
        media = wechat_media.download(mid)
    except:
        current_app.logger.exception('download media %s failed', mid)
        abort(400)
        return

    if media.status_code != requests.codes.ok:
        current_app.logger.error('download media %s failed, code %s', media.status_code)
        abort(400)

    return media.headers.get('content-type'), media.content


def save_to_oss(content: bytes, content_type: str, title: str, photo_type: PhotoType) -> str:
    oss_id, _ = current_app.bucket.upload_content(
        content, content_type,
        title,
        {
            'photo-type': photo_type.name,
        }
    )

    return oss_id


def move_photo(face_photo, tongue_photo):
    if '_' in face_photo.oss_id or '_' in tongue_photo.oss_id:
        return
    folder, file_name = os.path.split(face_photo.oss_id)
    name_list = os.path.splitext(file_name)
    new_name = '_1'.join(name_list)
    new_oss_id = '/'.join([folder, new_name]) if folder != '' else new_name
    current_app.bucket.move_file(face_photo.oss_id, new_oss_id)
    face_photo.oss_id = new_oss_id
    db.session.commit()

    new_name = '_2'.join(name_list)
    new_oss_id = '/'.join([folder, new_name]) if folder != '' else new_name
    current_app.bucket.move_file(tongue_photo.oss_id, new_oss_id)
    tongue_photo.oss_id = new_oss_id
    db.session.commit()


def analyze(content: bytes, photo_type: PhotoType):
    assert photo_type in (PhotoType.face, PhotoType.tongue), 'internal error, invalid photo type: %r' % (photo_type, )
    result = ANALYZE_FUNCTIONS[photo_type](content)
    ans = result.to_dict()
    return ans


def is_detected(result, photo_type: PhotoType):
    if photo_type == PhotoType.face:
        return getattr(result, 'faceDetectRes', 0) > 0
    else:
        return getattr(result, 'tongueDetectRes', 0) > 0


def handle_wechat_photo(photo_type: PhotoType):
    content_type, content = get_wechat_media()

    oss_id = save_to_oss(
        content,
        content_type,
        'w-%s/%s' % (local_user.id, request.json.get('id')),
        photo_type
    )
    ans = analyze(content, photo_type)

    result = save_analyze_result(ans, local_user.id, None, oss_id, photo_type)

    ans['id'] = result.id

    current_app.logger.info('output: %s', pprint.pformat(ans))

    return jsonify({
        'id': ans['id'],
        'detectRes': is_detected(result, photo_type)
    })


@api_bp.route('/api/photos/face/wechat', methods=['POST'])
@end_user_required()
def analyse_wechat_face():
    return handle_wechat_photo(PhotoType.face)


@api_bp.route('/api/photos/tongue/wechat', methods=['POST'])
@end_user_required()
def analyse_wechat_tongue():
    return handle_wechat_photo(PhotoType.tongue)


ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'bmp'}


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def detect_photo_errors(f):
    @wraps(f)
    def _f(*args, **kwargs):
        if 'photo' not in request.files:
            return jsonify({'error': 'no file submitted'})
        photo = request.files['photo']
        if not photo.filename or not allowed_file(photo.filename):
            return jsonify({'error': 'invalid file type'})
        return f(photo, *args, **kwargs)
    return _f


@agency_required()
@detect_photo_errors
def handle_form_photo(photo, photo_type: PhotoType):
    content = photo.read(-1)
    content_type = 'image/%s' % (photo.filename.rsplit('.', 1)[1].lower(), )

    tm = datetime.now().strftime('%Y%m')
    time_str = datetime.now().strftime('%Y%m%d-%H%M%S')
    file_id = uuid4()

    if local_user:
        title = '%s/%s/%s/%s/%s-%s' % (local_agency.login_name, local_user.cellphone or local_user.id, tm, photo_type.name, time_str, file_id)
    else:
        title = '%s/%s/%s/%s-%s' % (local_agency.login_name, tm, photo_type.name, time_str, file_id)

    oss_id = save_to_oss(
        content,
        content_type,
        title,
        photo_type
    )
    ans = analyze(content, photo_type)

    result = save_analyze_result(ans, local_user.id if local_user else None, local_agency.id if local_agency else None, oss_id, photo_type)

    ans['id'] = result.id

    current_app.logger.info('output: %s', pprint.pformat(ans))
    detail_page = https_for('report_{photo_type}/{id}'.format(photo_type=photo_type.name, id=ans['id']), _frontpage=True)
    return jsonify({
        'id': ans['id'],
        'detectRes': is_detected(result, photo_type),
        'detail_page': detail_page
    })


@api_bp.route('/api/photos/face', methods=['POST'])
def face_diagnosis():
    return handle_form_photo(PhotoType.face)


@api_bp.route('/api/photos/tongue', methods=['POST'])
def tongue_diagnosis():
    return handle_form_photo(PhotoType.tongue)


@api_bp.route('/api/<photo_type>/<photo_id>')
def photo_info(photo_type, photo_id):
    if photo_type == PhotoType.face.name:
        face_result = FaceResult.query.filter_by(id=photo_id).first()
        if face_result:
            add_photo_url_when_upload(face_result)
            result = marshal(face_result, basic_face_result_fields_with_url)
            return jsonify(result)

    elif photo_type == PhotoType.tongue.name:
        tongue_result = TongueResult.query.filter_by(id=photo_id).first()
        if tongue_result:
            add_photo_url_when_upload(tongue_result)
            result = marshal(tongue_result, basic_tongue_result_fields_with_url)
            return jsonify(result)

    abort(400)
