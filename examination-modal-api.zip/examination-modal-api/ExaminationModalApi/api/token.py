from datetime import datetime

from flask import jsonify, current_app
from flask_restful import Resource, reqparse, abort, marshal

from ExaminationModalApi import bcrypt, api, api_bp
from ExaminationModalApi.jwt_login import create_agency_jwt_token, agency_required, local_agency
from ExaminationModalApi.model.agency import Agency, simple_agency_fields
from ExaminationModalApi.util import to_timestamp


class TokenList(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('loginName', type=str, help='ID of the agency performing login', required=True)
    parser.add_argument('password', type=str, help='password of the agency', required=True)

    def post(self):
        args = self.parser.parse_args()
        agency = Agency.query.filter(Agency.login_name == args['loginName'], Agency.type != 'C').first()

        if not agency or not bcrypt.check_password_hash(agency.password, args.get('password')):
            abort(401, ok=False)
            return

        if 1 not in agency.categories:
            abort(401, ok=False)

        iat = datetime.utcnow()
        exp = iat + current_app.config.get('JWT_EXPIRATION_DELTA')
        nbf = iat + current_app.config.get('JWT_NOT_BEFORE_DELTA')
        token = create_agency_jwt_token(iat, exp, nbf, agency)
        return jsonify({
            'agencyInfo': marshal(agency, simple_agency_fields),
            'expiresAt': to_timestamp(exp),
            'issuedAt': to_timestamp(iat),
            'token': token.decode('utf-8'),
        })

    @agency_required()
    def delete(self):
        current_app.logger.debug('agency: %s', local_agency)
        return jsonify({'ok': True, 'agencyInfo': marshal(local_agency, simple_agency_fields)})


api.add_resource(TokenList, '/api/tokens')

verify_parser = reqparse.RequestParser()
verify_parser.add_argument('password', type=str, help='password of the agency', required=True)


@api_bp.route('/api/token/verifyPassword', methods=['POST'])
@agency_required()
def verify_password():
    args = verify_parser.parse_args()
    if bcrypt.check_password_hash(local_agency.password, args['password']):
        ans = { 'ok': True }
    else:
        ans = { 'ok': False }
    return jsonify(ans)


@api_bp.route('/api/settings', methods=['GET'])
def settings():
    setting = {
        'agency_history_report_level': 1,
    }
    return jsonify(setting)

