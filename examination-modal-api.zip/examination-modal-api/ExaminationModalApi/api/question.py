from flask import jsonify, request

from ExaminationModalApi import api_bp

questions = {
  "data": [
    {
      "id": 1,
      "index": 1,
      "label": "您自己觉得容易疲劳或乏力吗？",
      "options": [
        "是",
        "否"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 2,
      "index": 1,
      "label": "您平时容易怕冷、怕热、或手足心热吗？",
      "options": [
        "怕冷(或手脚冰凉)",
        "怕热",
        "手足心热",
        "正常"
      ],
      "exclusiveOption": 3,
      "multiple": True
    },
    {
      "id": 3,
      "index": 2,
      "label": "您平时容易出汗或晚上睡觉易出汗吗？ ",
      "options": [
        "活动汗出",
        "夜间出汗",
        "正常"
      ],
      "exclusiveOption": 2,
      "multiple": True
    },
    {
      "id": 4,
      "index": 3,
      "label": "您平时小便怎么样？",
      "options": [
        "偏黄",
        "清长（色清，量多）",
        "夜尿频多",
        "正常"
      ],
      "exclusiveOption": 3,
      "multiple": True
    },
    {
      "id": 5,
      "index": 4,
      "label": "您平时大便怎么样？",
      "options": [
        "偏干",
        "偏黏",
        "偏稀(或大便溏)",
        "正常"
      ],
      "exclusiveOption": 3,
      "multiple": True
    },
    {
      "id": 6,
      "index": 2,
      "label": "您平时胃口怎么样？",
      "options": [
        "不好",
        "正常"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 7,
      "index": 3,
      "label": "您平时容易口渴或口干吗？",
      "options": [
        "是",
        "否"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 8,
      "index": 5,
      "label": "您平时觉得口中有异样的味道吗？",
      "options": [
        "甜",
        "苦",
        "黏",
        "口淡",
        "正常"
      ],
      "exclusiveOption": 4,
      "multiple": True
    },
    {
      "id": 9,
      "index": 4,
      "label": "您平时容易心烦、情绪低落吗？",
      "options": [
        "是",
        "否"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 10,
      "index": 5,
      "label": "您容易掉头发吗？",
      "options": [
        "是",
        "否"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 11,
      "index": 6,
      "label": "您平时容易失眠吗？",
      "options": [
        "是",
        "否"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 12,
      "index": 6,
      "label": "您平时身体有胀满不适吗？",
      "options": [
        "乳房胀",
        "食后腹胀",
        "胸胁胀满",
        "无"
      ],
      "exclusiveOption": 3,
      "multiple": True
    },
    {
      "id": 13,
      "index": 7,
      "label": "您自己感觉腰膝酸软、腿脚无力吗？",
      "options": [
        "是",
        "否"
      ],
      "exclusiveOption": 1,
      "multiple": False
    }
  ]
}


questions_en = {
  "data": [
    {
      "id": 1,
      "index": 1,
      "label": "Are you easily fatigued?",
      "options": [
        "Yes",
        "No"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 2,
      "index": 1,
      "label": "Are you afraid of the cold, hear or do you feel feverishness in palms and soles? ",
      "options": [
        "Afraid of the cold",
        "Afraid of the heat",
        "Feverishness in palms and soles",
        "Normal"
      ],
      "exclusiveOption": 3,
      "multiple": True
    },
    {
      "id": 3,
      "index": 2,
      "label": "Do you easily sweat in normal times or at night?",
      "options": [
        "Sweat when exercising",
        "Sweat at night",
        "Normal"
      ],
      "exclusiveOption": 2,
      "multiple": True
    },
    {
      "id": 4,
      "index": 3,
      "label": "How about your urine ordinarily?",
      "options": [
        "Yellowish",
        "Clear and abundant",
        "Frequent urination at night",
        "Normal"
      ],
      "exclusiveOption": 3,
      "multiple": True
    },
    {
      "id": 5,
      "index": 4,
      "label": "How about your stool ordinarily?",
      "options": [
        "Dry",
        "Sticky",
        "Thin",
        "Normal"
      ],
      "exclusiveOption": 3,
      "multiple": True
    },
    {
      "id": 6,
      "index": 2,
      "label": "How about your appetite ordinarily?",
      "options": [
        "Bad",
        "Normal"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 7,
      "index": 3,
      "label": "Do you often feel thirsty or dry?",
      "options": [
        "Yes",
        "No"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 8,
      "index": 5,
      "label": "Do you feel strange taste in mouth ordinarily?",
      "options": [
        "Sweet",
        "Bitter",
        "Sticky",
        "Tastelessness",
        "Normal"
      ],
      "exclusiveOption": 4,
      "multiple": True
    },
    {
      "id": 9,
      "index": 4,
      "label": "Are you easily upset and depressed ordinarily?",
      "options": [
        "Yes",
        "No"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 10,
      "index": 5,
      "label": "Is your hair dry or do you often suffer from hair loss?",
      "options": [
        "Yes",
        "No"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 11,
      "index": 6,
      "label": "Do you often suffer from insomnia ordinarily? ",
      "options": [
        "Yes",
        "No"
      ],
      "exclusiveOption": 1,
      "multiple": False
    },
    {
      "id": 12,
      "index": 6,
      "label": "Do you have physical discomfort of fullness ordinarily?",
      "options": [
        "Breast swelling",
        "Distention after eating",
        "Fullness chest and hypochondrium",
        "No"
      ],
      "exclusiveOption": 3,
      "multiple": True
    },
    {
      "id": 13,
      "index": 7,
      "label": "Do you often suffer from soreness and weakness of waist and knees，or weakness of the legs and feet？",
      "options": [
        "Yes",
        "No"
      ],
      "exclusiveOption": 1,
      "multiple": False
    }
  ]
}


@api_bp.route('/api/questions')
def question_list():
    if request.args.get('lang') == 'en':
        return jsonify(questions_en)
    else:
        return jsonify(questions)

