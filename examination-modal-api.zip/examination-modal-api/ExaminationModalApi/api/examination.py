import json
import pprint
from datetime import datetime

from flask import request, current_app
from flask_jwt import jwt_required
from flask_restful import Resource, reqparse, marshal, abort
from sqlalchemy import desc,and_

from ExaminationModalApi import api, db
from ExaminationModalApi.examination import run
from ExaminationModalApi.jwt_login import is_agency, local_agency, local_user, login_user
from ExaminationModalApi.model.daily_report import DailyReport
from ExaminationModalApi.model.face_result import FaceResult, basic_face_result_fields
from ExaminationModalApi.model.question_result import QuestionResult
from ExaminationModalApi.model.report import Report, detail_report_fields, detail_shared_report_fields
from ExaminationModalApi.model.share import Share
from ExaminationModalApi.model.symptom import Symptom
from ExaminationModalApi.model.tongue_result import TongueResult, basic_tongue_result_fields
from ExaminationModalApi.model.user_info_history import UserInfoHistory
from ExaminationModalApi.api.photo import move_photo
from ExaminationModalApi.util import get_today_begin_utc_time, get_today_end_utc_time, get_city_from_ip
from ExaminationModalApi.api16.examination import create_report
from ExaminationModalApi.model.util import get_db_fields, get_first_before_this


class Examination(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('face_result_id', type=int, required=True, help='ID of face analysis result',
                        location=('json',))
    parser.add_argument('tongue_result_id', type=int, required=True, help='ID of tongue analysis result',
                        location=('json',))
    parser.add_argument('answers', type=lambda x: x, action='append', required=True, help='question answers',
                        location=('json',))
    parser.add_argument('client_info', type=str, required=False)

    def get_owner(self):
        if not is_agency:
            return local_user
        elif local_agency.type != 'A':
            return None
        elif local_user:
            return local_user
        else:
            abort(403)

    def get_agency(self):
        if is_agency:
            return local_agency
        else:
            return None

    @jwt_required()
    def post(self):
        args = self.parser.parse_args()
        owner, agency = self.get_owner(), self.get_agency()

        try:
            question_result = QuestionResult(
                owner=owner,
                agency=agency,
                time=datetime.utcnow(),
                question_version_id=1,
                answer=json.dumps(args['answers'])
            )
            db.session.add(question_result)
            db.session.commit()

            tongue_result = TongueResult.query.get_or_404(args['tongue_result_id'])
            face_result = FaceResult.query.get_or_404(args['face_result_id'])
            if face_result.owner is None and tongue_result.owner is None and owner:
                face_result.owner = owner
                tongue_result.owner = owner

            report = create_report(face_result, tongue_result, question_result, pulse_result_id=False,args=args, agency=agency, owner=owner)

            # current_app.logger.info('output: %s', pprint.pformat(result))
            return marshal(report, detail_shared_report_fields)
        except Exception as e:
            db.session.rollback()
            current_app.logger.exception('cannot handle request %r', request.json)
            current_app.logger.exception(e)
            abort(400)


api.add_resource(Examination, '/api/examinations')
