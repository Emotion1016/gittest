from datetime import datetime
from functools import wraps

from flask import jsonify, current_app
from flask_restful import Resource, reqparse, marshal_with, abort, marshal

from ExaminationModalApi import db, bcrypt, api, api_bp
from ExaminationModalApi.jwt_login import create_user_jwt_token, login_user_required, login_user, wechat_user, \
    create_agency_jwt_token
from ExaminationModalApi.model.agency import Agency, simple_agency_fields
from ExaminationModalApi.model.medical_history import medical_history
from ExaminationModalApi.model.user import User, simple_user_fields, simple_user_fields_with_id
from ExaminationModalApi.model.util import Gender
from ExaminationModalApi.model.verify_code import VerificationCode, Scope
from ExaminationModalApi.model.vendor import Vendor
from ExaminationModalApi.model.agency_info import AgencyInfo, agency_info_fields
from ExaminationModalApi.util import to_date, to_timestamp


def to_agency(key):
    if not key:
        return None
    agency = Agency.query.filter(Agency.key == str(key)).first()
    if not agency:
        current_app.logger.warning('invalid agency key %s', key)
    return agency


def to_vendor(key):
    if not key:
        return None
    vendor = Vendor.query.filter(Vendor.code == str(key)).first()
    if not vendor:
        current_app.logger.warning('invalid vendor key %s', key)
    return vendor


def is_from_vendor(key):
    if key:
        return True
    else:
        return False


def to_gender(key):
    return Gender(int(key))


user_create_simple_parse = reqparse.RequestParser()
user_create_simple_parse.add_argument('cellphone', type=str, help='cellphone number', required=True)
user_create_simple_parse.add_argument('name', type=str, help='user name')
user_create_simple_parse.add_argument('birthday', type=to_date, help='user birthday, in format yyyy-mm-dd')
user_create_simple_parse.add_argument('age', type=int, help='user age')
user_create_simple_parse.add_argument('gender', type=to_gender, help='gender, 1-male, 2-female', required=True)
user_create_simple_parse.add_argument('height', type=int, help='height in cm', required=True)
user_create_simple_parse.add_argument('weight', type=int, help='weight in kg', required=True)
user_create_simple_parse.add_argument('medical_history', type=medical_history, help='medical history list', action='append')


user_patch_parser = reqparse.RequestParser()
user_patch_parser.add_argument('name', type=str, help='user name', required=True)
user_patch_parser.add_argument('birthday', type=to_date, help='user birthday, in format yyyy-mm-dd')
user_patch_parser.add_argument('age', type=int, help='user age')
user_patch_parser.add_argument('gender', type=to_gender, help='gender, 1-male, 2-female', required=True)
user_patch_parser.add_argument('height', type=int, help='height in cm', required=True)
user_patch_parser.add_argument('weight', type=int, help='weight in kg', required=True)
user_patch_parser.add_argument('medical_history', type=medical_history, help='medical history list', action='append')


user_create_parser = user_patch_parser.copy()
user_create_parser.add_argument('cellphone', type=str, help='cellphone number', required=True)
user_create_parser.add_argument('code', type=str, help='cellphone verification code', required=True)
user_create_parser.add_argument('password', type=str, help='password', required=True)
user_create_parser.add_argument('agency_key', dest='agency', type=to_agency, help='agency identification key')
user_create_parser.add_argument('vendor_code', dest='vendor', type=to_vendor, help='vendor identification code')
user_create_parser.add_argument('vendor_code', dest='is_from_vendor', type=is_from_vendor, help='vendor identification code')


user_login_parser = reqparse.RequestParser()
user_login_parser.add_argument('cellphone', type=str, help='cellphone number', required=True)
user_login_parser.add_argument('password', type=str, help='password', required=True)


user_change_password_parser = reqparse.RequestParser()
user_change_password_parser.add_argument('old_password', type=str, help='old password', required=True)
user_change_password_parser.add_argument('new_password', type=str, help='new password', required=True)


user_reset_password_parser = reqparse.RequestParser()
user_reset_password_parser.add_argument('cellphone', type=str, help='cellphone number', required=True)
user_reset_password_parser.add_argument('code', type=str, help='cellphone verification code', required=True)
user_reset_password_parser.add_argument('new_password', type=str, help='new password', required=True)


common_login_parse = reqparse.RequestParser()
common_login_parse.add_argument('name', type=str, help='agency login name or cellphone number', required=True)
common_login_parse.add_argument('password', type=str, help='password', required=True)


def user_info_with_token():
    def _decorator(f):
        @wraps(f)
        def _f(*args, **kwargs):
            u = f(*args, **kwargs)
            response = jsonify(marshal(u, simple_user_fields_with_id))

            response.set_cookie(
                'X-ZHIYUN-USER-TOKEN',
                create_user_jwt_token(u),
                secure=(not current_app.config.get('DEBUG', False)),
                httponly=True,
            )
            return response
        return _f
    return _decorator


@api_bp.route('/api/users/login', methods=['POST',])
@user_info_with_token()
def login():
    arguments = user_login_parser.parse_args()
    cellphone = arguments['cellphone']
    password = arguments['password']

    u = User.query.filter(User.cellphone == cellphone).first()
    if u and bcrypt.check_password_hash(u.password, password):
        return u
    else:
        abort(401)


@api_bp.route('/api/commonlogin', methods=['POST',])
def common_login():
    arguments = common_login_parse.parse_args()
    name = arguments['name']
    password = arguments['password']

    iat = datetime.utcnow()
    exp = iat + current_app.config.get('JWT_EXPIRATION_DELTA')
    nbf = iat + current_app.config.get('JWT_NOT_BEFORE_DELTA')

    agency = Agency.query.filter_by(login_name=name).first()
    # if not agency:
    #     a_info = AgencyInfo.query.filter_by(cellphone=name).first()
    #     if a_info:
    #         agency = Agency.query.filter(Agency.agency_info == a_info).first()
    if agency and bcrypt.check_password_hash(agency.password, password):
        token = create_agency_jwt_token(iat, exp, nbf, agency)
        type = 'user' if agency.type == 'C' else 'agency'
        return jsonify({
            'type': type,
            'Info': marshal(agency, simple_agency_fields),
            'expiresAt': to_timestamp(exp),
            'issuedAt': to_timestamp(iat),
            'token': token.decode('utf-8'),
        })
    # user = User.query.filter_by(cellphone=name).first()
    # # remove user.vendor check
    # if user and bcrypt.check_password_hash(user.password, password):
    #     token = create_user_jwt_token(user)
    #     return jsonify({
    #         'type': 'user',
    #         'Info': marshal(user, simple_user_fields_with_id),
    #         'expiresAt': to_timestamp(exp),
    #         'issuedAt': to_timestamp(iat),
    #         'token': token.decode('utf-8'),
    #     })

    abort(401, error='name or password is not true')


@api_bp.route('/api/users/resetPassword', methods=['POST',])
@user_info_with_token()
def reset_password():
    arguments = user_reset_password_parser.parse_args()
    cellphone = arguments['cellphone']
    code = arguments['code']
    password = arguments['new_password']

    # code check
    v, code_ok = VerificationCode.check(
        cellphone, code, Scope.reset_password
    )
    if code_ok:
        v.invalid = True
    else:
        abort(411, error='验证码错误')

    a_info = AgencyInfo.query.filter(AgencyInfo.cellphone == cellphone).first()
    if a_info:
        a = Agency.query.filter(Agency.agency_info == a_info).first()
        a.password = bcrypt.generate_password_hash(password, 10)
        db.session.commit()
        return a
    else:
        abort(414, error='用户未注册')


@api_bp.route('/api/users/logout', methods=['GET',])
@login_user_required()
def logout():
    current_app.logger.debug(login_user)
    response = jsonify({'ok': True})
    response.set_cookie(
        'X-ZHIYUN-USER-TOKEN',
        '',
        expires=0
    )
    return response


@api_bp.route('/api/users/me/password', methods=['POST', ])
@login_user_required()
def change_password():
    arguments = user_change_password_parser.parse_args()
    if login_user:
        if bcrypt.check_password_hash(login_user.password, arguments['old_password']):
            login_user.password = bcrypt.generate_password_hash(arguments['new_password'], 10)
            db.session.commit()
            user_info = marshal(login_user, simple_user_fields)
            return jsonify(user_info)
        else:
            abort(400)
    else:
        abort(401)


@api_bp.route('/api/users/syncAvatar', methods=['GET',])
@login_user_required()
def sync_avatar():
    if not bool(wechat_user):
        abort(400, error='must login via wechat')
    current_app.logger.debug('user register via wechat %s, copy its avatar', wechat_user)
    login_user.avatar = wechat_user.avatar
    db.session.commit()
    return jsonify({'ok': True})


class UserList(Resource):
    parser = user_create_parser

    def post(self):
        arguments = self.parser.parse_args()
        # try_load_user()
        cellphone = arguments['cellphone']
        code = arguments['code']

        # code check
        v, code_ok = VerificationCode.check(
            cellphone, code, Scope.register
        )
        if code_ok:
            v.invalid = True
        else:
            abort(411, error='验证码错误')

        agency = arguments.get('agency')
        current_app.logger.debug('user is registered via agency: %s', agency)

        vendor = arguments.get('vendor')
        current_app.logger.debug('user is registered via vendor: %s', vendor)
        is_from_vendor = arguments.get('is_from_vendor')

        birthday = arguments.get('birthday')
        if not birthday:
            age = arguments.get('age')
            if age or age == 0:
                y = datetime.now().year
                m = datetime.now().month
                d = datetime.now().day
                birthday = '%s-%02d-%02d' % (y-int(age), m, d)

        # 大个人/C机构注册
        if is_from_vendor:

            if vendor is None:
                abort(410, error='厂商码不正确或已过期')

            if vendor.type:
                abort(410, error='厂商码在当前版本不可用')

            if vendor.del_flag == 1:
                abort(410, error='厂商码不正确或已过期')

            if AgencyInfo.query.filter(AgencyInfo.cellphone == cellphone).first():
                abort(412, error='用户已注册')

            if Agency.query.filter(Agency.login_name == arguments['name']).first():
                abort(412, error='用户已注册')

            a = Agency()
            a_info = AgencyInfo()
            a_info.name = arguments['name']
            a_info.birthday = birthday
            a_info.gender = arguments['gender']
            a_info.height = arguments['height']
            a_info.weight = arguments['weight']
            a_info.cellphone = cellphone

            a.name = arguments['name']
            # a.key = arguments['name']
            a.login_name = cellphone
            a.password = bcrypt.generate_password_hash(arguments['password'], 10)
            a.agency_info = a_info
            a.custom = vendor.custom
            a.medical_history = arguments['medical_history'] or []
            if None in a.medical_history:
                a.medical_history.remove(None)
            a.vendor = vendor
            a.create_time = datetime.utcnow()
            a.type = 'C'

            db.session.add(a_info)
            db.session.add(a)
            try:
                db.session.commit()
            except Exception as e:
                current_app.logger.exception('failed to commit user creation %s' % e)
                db.session.rollback()
                abort(400, error='提交失败')
            return marshal(a_info, agency_info_fields)

        else:

            # A机构下用户注册
            if User.query.filter(User.cellphone == cellphone).first():
                abort(412, error='用户已注册')

            u = User()

            u.name = arguments['name']
            u.birthday = birthday
            u.gender = arguments['gender']
            u.height = arguments['height']
            u.weight = arguments['weight']
            u.medical_history = arguments['medical_history'] or []
            u.cellphone = cellphone
            u.password = bcrypt.generate_password_hash(arguments['password'], 10)
            u.agency = agency
            u.vendor = vendor
            u.create_time = datetime.utcnow()

            if bool(wechat_user):
                current_app.logger.debug('user register via wechat %s, copy its avatar', wechat_user)
                if not u.agency:
                    u.agency = wechat_user.agency
                u.avatar = wechat_user.avatar
            db.session.add(u)
            try:
                db.session.commit()
            except Exception as e:
                current_app.logger.exception('failed to commit user creation')
                db.session.rollback()
                abort(400, error='提交失败')
            return marshal(u, simple_user_fields_with_id)


api.add_resource(UserList, '/api/users')


class UserQuickLogin(Resource):
    DEFAULT_PASSWORD = '123456'
    parser = user_create_simple_parse

    def post(self):
        arguments = self.parser.parse_args()
        cellphone = arguments['cellphone']

        birthday = arguments.get('birthday')
        if not birthday:
            age = arguments.get('age')
            if age or age == 0:
                y = datetime.now().year
                m = datetime.now().month
                d = datetime.now().day
                birthday = '%s-%02d-%02d' % (y-int(age), m, d)

        u = User.query.filter(User.cellphone == cellphone).first()
        if arguments['medical_history'] == [None]:
            arguments['medical_history'] = []

        if u:
            u.birthday = birthday
            u.name = arguments['name']
            u.gender = arguments['gender']
            u.height = arguments['height']
            u.weight = arguments['weight']
            u.medical_history = arguments.get('medical_history') or []
        else:
            u = User()
            u.birthday = birthday
            u.name = arguments['name']
            u.gender = arguments['gender']
            u.height = arguments['height']
            u.weight = arguments['weight']
            u.medical_history = arguments.get('medical_history') or []
            u.cellphone = cellphone
            u.password = bcrypt.generate_password_hash(self.DEFAULT_PASSWORD, 10)
            u.create_time = datetime.utcnow()
            db.session.add(u)

        try:
            db.session.commit()
        except Exception as e:
            current_app.logger.exception('failed to commit user creation')
            db.session.rollback()

        iat = datetime.utcnow()
        exp = iat + current_app.config.get('JWT_EXPIRATION_DELTA')
        nbf = iat + current_app.config.get('JWT_NOT_BEFORE_DELTA')
        token = create_user_jwt_token(u)
        return jsonify({
            'type': 'user',
            'Info': marshal(u, simple_user_fields_with_id),
            'expiresAt': to_timestamp(exp),
            'issuedAt': to_timestamp(iat),
            'token': token.decode('utf-8'),
        })


api.add_resource(UserQuickLogin, '/api/user/quick/login')


class Me(Resource):
    patchable_fields = (
        'name', 'birthday', 'gender',
        'height', 'weight',
    )

    @login_user_required()
    @marshal_with(simple_user_fields)
    def get(self):
        return login_user

    @login_user_required()
    @marshal_with(simple_user_fields)
    def patch(self):
        arguments = user_patch_parser.parse_args()
        try:
            for f in self.patchable_fields:
                v = arguments.get(f, None)
                if v is not None:
                    setattr(login_user, f, v)
            if 'medical_history' in arguments:
                login_user.medical_history = arguments['medical_history'] or []
            db.session.commit()
        except Exception:
            current_app.logger.exception('cannot update user %s', login_user)
            db.session.rollback()
            abort(400)

        return login_user


api.add_resource(Me, '/api/users/me')
