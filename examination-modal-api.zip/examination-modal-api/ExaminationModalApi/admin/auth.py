from datetime import datetime
from functools import wraps

import jwt as jwtlib
from flask import current_app, request, jsonify, _request_ctx_stack
from flask_jwt import jwt_required
from flask_restful import marshal, abort
from werkzeug.local import LocalProxy

from ExaminationModalApi.admin import slugs, DEFAULT_SUPER_ADMIN_USERNAME
from ExaminationModalApi.jwt_login import add_ext_login_sources
from ExaminationModalApi.model.admin_user import AdminUser, admin_user_fields

ZHIYUN_ADMIN_TOKEN_NAME = 'X-ZHIYUN-ADMIN-TOKEN'

admin_user = LocalProxy(lambda: getattr(_request_ctx_stack.top, 'admin_user', None))


def create_admin_user_jwt_token(user: AdminUser):
    iat = datetime.utcnow()
    exp = iat + current_app.config.get('JWT_EXPIRATION_DELTA')
    nbf = iat + current_app.config.get('JWT_NOT_BEFORE_DELTA')
    payload = {'exp': exp, 'iat': iat, 'nbf': nbf, "admin_id": user.id}
    secret = current_app.config['JWT_SECRET_KEY']
    algorithm = current_app.config['JWT_ALGORITHM']
    jwt_token = jwtlib.encode(payload, secret, algorithm=algorithm)
    return jwt_token


def load_admin(payload):
    if payload.get('admin_id'):
        u = AdminUser.query.get(payload['admin_id'])
    else:
        u = None
    _request_ctx_stack.top.admin_user = u
    return u


def load_jwt_token():
    return request.cookies.get(ZHIYUN_ADMIN_TOKEN_NAME)


add_ext_login_sources('admin_user', {
    'request_handler': load_jwt_token,
    'identity_handler': load_admin,
})


def admin_info_with_token(fields=admin_user_fields):
    def _decorator(f):
        @wraps(f)
        def _f(*args, **kwargs):
            u = f(*args, **kwargs)
            response = jsonify(marshal(u, fields))

            if u:
                response.set_cookie(
                    ZHIYUN_ADMIN_TOKEN_NAME,
                    create_admin_user_jwt_token(u),
                    secure=(not current_app.config.get('DEBUG', False)),
                    httponly=True,
                )
            else:
                response.set_cookie(
                    ZHIYUN_ADMIN_TOKEN_NAME,
                    '',
                    secure=(not current_app.config.get('DEBUG', False)),
                    httponly=True,
                    expires=0,
                )
            return response
        return _f
    return _decorator


def admin_user_required():
    def _decorator(f):
        @wraps(f)
        def _f(*args, **kwargs):
            if admin_user is None or not bool(admin_user):
                abort(403)
            return f(*args, **kwargs)
        return jwt_required()(_f)
    return _decorator


def super_admin_required():
    def _decorator(f):
        @wraps(f)
        def _f(*args, **kwargs):
            if admin_user.username != current_app.config.get('SUPER_ADMIN_USERNAME', DEFAULT_SUPER_ADMIN_USERNAME):
                abort(403)
            return f(*args, **kwargs)
        return admin_user_required()(_f)
    return _decorator


def access_required(privilege):
    def _decorator(f):
        @wraps(f)
        def _f(*args, **kwargs):
            if admin_user.has_access_privilege(privilege) or \
                    admin_user.has_access_privilege(slugs.PRIVILEGE_SLUG_ALL):
                return f(*args, **kwargs)
            abort(403)
        return admin_user_required()(_f)
    return _decorator


def modify_required(privilege):
    def _decorator(f):
        @wraps(f)
        def _f(*args, **kwargs):
            if admin_user.has_modify_privilege(privilege) or \
                    admin_user.has_modify_privilege(slugs.PRIVILEGE_SLUG_ALL):
                return f(*args, **kwargs)
            abort(403)
        return admin_user_required()(_f)
    return _decorator


def privilege_required(privilege):
    def _decorator(f):
        @wraps(f)
        def _f(*args, **kwargs):
            if admin_user.has_access_privilege(privilege) or \
                    admin_user.has_access_privilege(slugs.PRIVILEGE_SLUG_ALL):
                return f(*args, **kwargs)
            if admin_user.has_modify_privilege(privilege) or \
                    admin_user.has_modify_privilege(slugs.PRIVILEGE_SLUG_ALL):
                return f(*args, **kwargs)
            abort(403)
        return admin_user_required()(_f)
    return _decorator
