from flask import Blueprint
from flask_restful import Api

DEFAULT_SUPER_ADMIN_USERNAME = 'admin'


admin_blueprint = Blueprint('admin', __name__)

admin_api = Api(admin_blueprint)

from . import auth

from .command import admin_user

from .views import admin_user, agency, report
