from flask import current_app
from flask_restful import fields, reqparse
from sqlalchemy import desc, asc

from ExaminationModalApi import DEFAULT_PAGINATION_ITEM_NUM


def paged_fields_of(data_fields):
    """ return a restful fields can be used to marshal flask_sqlalchemy pagination """
    return {
        'end': fields.Boolean,
        'first': fields.Boolean,
        'data': fields.List(fields.Nested(data_fields), attribute='items'),
        'next_num': fields.Integer,
        'page': fields.Integer,
        'pages': fields.Integer,
        'prev_num': fields.Integer,
        'total': fields.Integer
    }


def filter_argument_parser(order_columns):
    parser = reqparse.RequestParser()
    parser.add_argument('filter', type=str, help='Filter to search specific resource')
    parser.add_argument(
        'order_by', type=str, help='Column by which to sort results',
        choices=tuple(order_columns)
    )
    parser.add_argument('descending', type=bool, help='Should results be sorted in descending order')
    return parser


def pagination_argument_parser():
    pagination_parser = reqparse.RequestParser()
    pagination_parser.add_argument('page', type=int, default=0, help='Page to fetch')
    pagination_parser.add_argument(
        'per_page', type=int,
        default=current_app.config.get('LIST_FETCH_LIMIT_LEN', DEFAULT_PAGINATION_ITEM_NUM),
        help='Page to fetch')


def pagination_filter_argument_parser(order_columns):
    parser = filter_argument_parser(order_columns)
    parser.add_argument('page', type=int, default=None, help='Page to fetch')
    parser.add_argument(
        'per_page', type=int,
        default=current_app.config.get('LIST_FETCH_LIMIT_LEN', DEFAULT_PAGINATION_ITEM_NUM),
        help='Page to fetch')

    return parser


def paginate(query, args):
    page = query.paginate(
        page=args.get('page'),
        per_page=args.get('per_page'),
        max_per_page=200
    )
    page.end = not page.has_next
    page.first = not page.has_prev
    return page


def sorted_paginate(query, sort_columns_map, arbitrate_by='id'):
    pagination_parser = pagination_filter_argument_parser(list(sort_columns_map.keys()))
    args = pagination_parser.parse_args()

    func = desc if args.get('descending') else asc
    query = query.order_by(func(sort_columns_map.get(args.get('order_by', 'id'))))
    if arbitrate_by:
        query = query.order_by(func(sort_columns_map[arbitrate_by]))
    page = paginate(query, args)
    return page
