import random
from datetime import datetime

from flask_restful import Resource, marshal_with, abort, reqparse

from ExaminationModalApi import db, bcrypt
from ExaminationModalApi.admin import admin_api
from ExaminationModalApi.admin.auth import access_required, modify_required
from ExaminationModalApi.admin.views.util import paged_fields_of, sorted_paginate
from ExaminationModalApi.model.agency import detail_agency_fields, Agency
from ExaminationModalApi.util import to_date

agency_list_fields = paged_fields_of(detail_agency_fields)


class AgencyList(Resource):
    create_agency_parser = reqparse.RequestParser(trim=True)
    create_agency_parser.add_argument('login_name', type=str, required=True)
    create_agency_parser.add_argument('name', type=str, required=True)
    create_agency_parser.add_argument('password', type=str, required=True)
    create_agency_parser.add_argument('anonymous_report', type=bool, required=True)
    create_agency_parser.add_argument('valid_begin_date', type=to_date, required=True)
    create_agency_parser.add_argument('valid_end_date', type=to_date, required=True)

    sort_columns = {
        'id': Agency.id,
        'name': Agency.name,
        'anonymous_report': Agency.anonymous_report,
        'sales': Agency.sales,
        'create_time': Agency.create_time,
        'update_time': Agency.update_time,
    }

    @access_required('sales')
    @marshal_with(agency_list_fields)
    def get(self):
        query = Agency.query
        return sorted_paginate(query, self.sort_columns)

    @access_required('sales')
    @marshal_with(detail_agency_fields)
    def post(self):
        args = self.create_agency_parser.parse_args(strict=True)
        key_space = 100000
        while True:
            key = 'agency-%s' % (random.randint(1, key_space), )
            if Agency.query.filter(Agency.key == key).count() == 0:
                break
            key_space *= 2
        password = bcrypt.generate_password_hash(args.pop('password'), 10)
        agency = Agency(
            key=key,
            password=password,
            **args
        )
        db.session.add(agency)
        db.session.commit()
        return agency


admin_api.add_resource(AgencyList, '/admin/api/agencies')


class AgencyDetail(Resource):
    update_agency_parser = reqparse.RequestParser()
    update_agency_parser.add_argument('name', type=str)
    update_agency_parser.add_argument('password', type=str)
    # update_agency_parser.add_argument('anonymous_report', type=bool)
    update_agency_parser.add_argument('valid_begin_date', type=to_date)
    update_agency_parser.add_argument('valid_end_date', type=to_date)

    @access_required('sales')
    @marshal_with(detail_agency_fields)
    def get(self, aid):
        """get info of a admin user"""
        u = Agency.query.get(aid)
        if not u:
            abort(404)
        return u

    @modify_required('sales')
    @marshal_with(detail_agency_fields)
    def post(self, aid):
        """get info of a admin user"""
        u = Agency.query.get(aid)
        if not u:
            abort(404)
        args = self.update_agency_parser.parse_args(strict=True)
        for k, v in args.items():
            if v is None:
                continue
            elif k == 'password':
                k = bcrypt.generate_password_hash(args.pop('password'), 10)
            setattr(u, k, v)
            u.update_time = datetime.utcnow()
        db.session.commit()
        return u


admin_api.add_resource(AgencyDetail, '/admin/api/agency/<int:aid>')
