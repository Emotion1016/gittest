from flask_restful import Resource, marshal_with, fields

from ExaminationModalApi.admin import admin_api
from ExaminationModalApi.admin.auth import access_required
from ExaminationModalApi.admin.views.util import paged_fields_of, sorted_paginate
from ExaminationModalApi.model.report import Report, simple_report_fields
from ExaminationModalApi.model.user import User
from ExaminationModalApi.model.user_info_history import UserInfoHistory, user_info_history_fields
from ExaminationModalApi.model.util import add_photos_url, add_question_answers, setattr_with

admin_report_summary_fields = dict(simple_report_fields)
admin_report_summary_fields.update({
    'user_info': fields.Nested(user_info_history_fields, allow_null=True),
    'report_url': fields.String,
    'face_photo_url': fields.String,
    'tongue_photo_url': fields.String,
    'ip': fields.String,
    'ua': fields.String,
    'cellphone': fields.String,
    'answers': fields.List(fields.Nested({
        'answer': fields.List(fields.String),
        'id': fields.String,
    }))
})
admin_report_list_fields = paged_fields_of(admin_report_summary_fields)


class ReportList(Resource):
    sort_columns = {
        'id': Report.id,
        'gender': UserInfoHistory.gender,
        'cellphone': User.cellphone,
        'display_time': Report.time,
        'user_info.name': UserInfoHistory.name,
        'user_info.age': UserInfoHistory.birthday,
        'ip': Report.ip,
        'ua': Report.ua,
        'health_score': Report.health_score,
        'health_status_text': Report.health_score,
    }

    @access_required('report')
    @marshal_with(admin_report_list_fields)
    def get(self):
        query = Report.query.join(User).join(UserInfoHistory, isouter=True)
        page = sorted_paginate(query, self.sort_columns)
        page.items = map(add_photos_url, page.items)
        page.items = map(add_question_answers, page.items)
        page.items = map(
            lambda r: setattr_with(r, 'cellphone', r.owner and r.owner.cellphone),
            page.items
        )
        page.items = list(page.items)
        return page


admin_api.add_resource(ReportList, '/admin/api/reports')
