from flask import jsonify
from flask_restful import reqparse, abort, fields, marshal_with, Resource, marshal
from sqlalchemy import desc, asc
from sqlalchemy.exc import IntegrityError

from ExaminationModalApi import db, bcrypt
from ExaminationModalApi.admin import admin_blueprint, admin_api
from ExaminationModalApi.admin.auth import admin_info_with_token, privilege_required, modify_required, access_required, \
    super_admin_required, admin_user_required, admin_user
from ExaminationModalApi.admin.views.util import paged_fields_of, pagination_filter_argument_parser, paginate
from ExaminationModalApi.model.admin_category import AdminCategory
from ExaminationModalApi.model.admin_user import AdminUser, admin_user_fields

admin_user_simple_list_fields = {
    'updated': fields.List(fields.Nested(admin_user_fields))
}


admin_user_list_fields = paged_fields_of(admin_user_fields)


login_parser = reqparse.RequestParser()
login_parser.add_argument('username', type=str, help='login username', required=True)
login_parser.add_argument('password', type=str, help='password', required=True)


@admin_blueprint.route('/admin/api/login', methods=['POST',])
@admin_info_with_token()
def login():
    arg = login_parser.parse_args()
    u = AdminUser.query.filter(AdminUser.username == arg['username']).first()
    if not u or not bcrypt.check_password_hash(u.password, arg['password']):
        abort(401, error='incorrect username or password')
    return u


@admin_blueprint.route('/admin/api/adminUser/checkPrivilege/<scope>/<slug>')
def check_privilege(scope, slug):
    ok = lambda: jsonify({'ok': True})
    if scope == 'access':
        return access_required(slug)(ok)()
    elif scope == 'modify':
        return modify_required(slug)(ok)()
    elif scope == 'privilege':
        return privilege_required(slug)(ok)()
    abort(400, msg='invalid scope name')


def convert_privilege(slug):
    if not slug:
        return None

    try:
        c = AdminCategory.by_slug(slug)
        if not c:
            raise ValueError('%r is not a valid slug' % (slug, ))
        return c
    except ValueError:
        raise
    except Exception:
        raise ValueError('each privilege item must be an string')


def load_admin_users(username):
    if not username:
        return None

    try:
        c = AdminUser.by_username(username)
        if not c:
            raise ValueError('%r is not a valid slug' % (username,))
        return c
    except ValueError:
        raise
    except Exception:
        raise ValueError('each privilege item must be an string')


privilege_parser = reqparse.RequestParser()
privilege_parser.add_argument('usernames', dest='user', type=load_admin_users, action='append', required=True)
privilege_parser.add_argument('modify', type=convert_privilege, action='append', required=True)
privilege_parser.add_argument('access', type=convert_privilege, action='append', required=True)


@admin_blueprint.route('/admin/api/adminUsers/privilege', methods=['POST',])
@super_admin_required()
def modify_privilege():
    arg = privilege_parser.parse_args()
    modify, access = list(set(arg['modify'])), list(set(arg['access']))
    for u in arg['user']:
        u.modify_privileges = modify
        u.access_privileges = access
    db.session.commit()
    return jsonify(marshal({'updated': arg['user']}, admin_user_simple_list_fields))


class AdminUserList(Resource):
    new_user_parser = reqparse.RequestParser()
    new_user_parser.add_argument('username', type=str, required=True)
    new_user_parser.add_argument('name', type=str, required=True)
    new_user_parser.add_argument('password', type=str, required=True)

    @super_admin_required()
    @marshal_with(admin_user_list_fields)
    def get(self):
        pagination_parser = pagination_filter_argument_parser(['id', 'name', 'username'])
        args = pagination_parser.parse_args()
        query = AdminUser.query
        if args.get('filter'):
            query = query.filter(AdminUser.username.ilike(args['filter']))
        sort_columns = {
            'id': AdminUser.id,
            'name': AdminUser.name,
            'username': AdminUser.username,
        }
        func = desc if args.get('descending') else asc
        query = query.order_by(func(sort_columns.get(args.get('order_by', 'id'), sort_columns['id'])))
        return paginate(query, args)

    @super_admin_required()
    @marshal_with(admin_user_fields)
    def post(self):
        args = self.new_user_parser.parse_args()
        name, username, password = map(args.get, ['name', 'username', 'password'])
        u = None

        if not all([name, username, password]):
            abort(400, error='name, username, password must not be blank')
        else:
            u = AdminUser(
                username=username,
                name=name,
                password=bcrypt.generate_password_hash(password, 10),
                access_privileges=[AdminCategory.by_slug('__ALL__')],
                modify_privileges=[AdminCategory.by_slug('__ALL__')]
            )
            try:
                db.session.add(u)
                db.session.commit()
            except IntegrityError:
                abort(409, error='duplicated')
        return u


admin_api.add_resource(AdminUserList, '/admin/api/adminUsers')


class AdminUserDetail(Resource):
    update_admin_user_parser = reqparse.RequestParser()
    update_admin_user_parser.add_argument('name', type=str)
    update_admin_user_parser.add_argument('password', type=str)

    @super_admin_required()
    @marshal_with(admin_user_fields)
    def get(self, uid):
        """get info of a admin user"""
        u = AdminUser.query.get(uid)
        if not u:
            abort(404)
        return u

    @super_admin_required()
    @marshal_with(admin_user_fields)
    def post(self, uid):
        arg = self.update_admin_user_parser.parse_args()
        u = AdminUser.query.get(uid)
        if not u:
            abort(404)
        if arg.get('name', None) is not None:
            u.name = arg['name']
        if arg.get('password', None) is not None:
            u.password = bcrypt.generate_password_hash(arg['password'], 10)
        db.session.commit()
        return u


admin_api.add_resource(AdminUserDetail, '/admin/api/adminUser/<int:uid>')


class CurrentAdminUserInfo(Resource):
    update_my_password_parser = reqparse.RequestParser()
    update_my_password_parser.add_argument('password', type=str, required=True)
    update_my_password_parser.add_argument('new_password', type=str, required=True)

    @admin_user_required()
    @marshal_with(admin_user_fields)
    def get(self):
        return admin_user

    @admin_user_required()
    @marshal_with(admin_user_fields)
    def post(self):
        arg = self.update_my_password_parser.parse_args()
        password, new_password = arg['password'], arg['new_password']
        if not password or not new_password:
            abort(400, error='password cannot be blank')
        elif not bcrypt.check_password_hash(admin_user.password, password):
            abort(403, error='present password not match')
        else:
            admin_user.password = bcrypt.generate_password_hash(new_password, 10)
            db.session.commit()
        return admin_user


admin_api.add_resource(CurrentAdminUserInfo, '/admin/api/me')
