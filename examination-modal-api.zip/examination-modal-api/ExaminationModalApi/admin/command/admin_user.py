import click

from ExaminationModalApi import app, db, bcrypt
from ExaminationModalApi.model.admin_category import AdminCategory
from ExaminationModalApi.model.admin_user import AdminUser


@app.cli.command(help='add an admin user')
@click.argument('username', type=str)
@click.argument('password', type=str)
@click.argument('name', type=str)
def add_admin(username, password, name):
    a = AdminUser(
        username=username,
        name=name,
        password=bcrypt.generate_password_hash(password, 12)
    )
    db.session.add(a)
    db.session.commit()
    click.echo('Admin %d %s(%s) added' % (a.id, a.username, a.name))


@app.cli.command(help='reset password of an admin user')
@click.argument('username', type=str)
@click.argument('password', type=str)
def reset_password(username, password):
    a = AdminUser.by_username(username)
    if not a:
        click.echo('Admin user %s not found' % (username, ))
        exit(1)

    a.password = bcrypt.generate_password_hash(password, 12)
    db.session.commit()
    click.echo('Admin %d %s(%s) password reset' % (a.id, a.username, a.name))


@app.cli.command(help='grant privilege to an admin user')
@click.argument('username', type=str)
@click.argument('scope', type=str)
@click.argument('privilege', type=str)
def grant_admin(username, scope, privilege):
    if scope not in {'access', 'modify'}:
        click.echo('scope shall be access or modify', err=True)
        exit(1)
    u = AdminUser.query.filter(AdminUser.username == username).first()
    p = AdminCategory.by_slug(privilege)
    if not u:
        click.echo('no such user', err=True)
        exit(1)
    elif not p:
        click.echo('invalid privilege slug', err=True)
        click.echo('valid privilege slugs: %s' % (','.join(pp.slug for pp in AdminCategory.query.all())))
        exit(1)

    if scope == 'access':
        u.access_privileges.append(p)
        click.echo('access privileges of user %s: %s' % (
            u.username, ','.join(pp.slug for pp in set(u.access_privileges))
        ))
    elif scope == 'modify':
        u.modify_privileges.append(p)
        click.echo('modify privileges of user %s: %s' % (
            u.username, ','.join(pp.slug for pp in set(u.modify_privileges))
        ))
    db.session.commit()


@app.cli.command(help='revoke privilege from an admin user')
@click.argument('username', type=str)
@click.argument('scope', type=str)
@click.argument('privilege', type=str)
def revoke_admin(username, scope, privilege):
    if scope not in {'access', 'modify'}:
        click.echo('scope shall be access or modify', err=True)
        exit(1)
    u = AdminUser.query.filter(AdminUser.username == username).first()
    p = AdminCategory.by_slug(privilege)
    if not u:
        click.echo('no such user', err=True)
        exit(1)
    elif not p:
        click.echo('invalid privilege slug', err=True)
        click.echo('valid privilege slugs: %s' % (','.join(pp.slug for pp in AdminCategory.query.all())))
        exit(1)

    if scope == 'access':
        u.access_privileges = list(filter(lambda x: x.id != p.id, u.access_privileges))
        click.echo('access privileges of user %s: %s' % (
            u.username, ','.join(pp.slug for pp in set(u.access_privileges))
        ))
    elif scope == 'modify':
        u.modify_privileges = list(filter(lambda x: x.id != p.id, u.modify_privileges))
        click.echo('modify privileges of user %s: %s' % (
            u.username, ','.join(pp.slug for pp in set(u.modify_privileges))
        ))
    db.session.commit()
