from flask import jsonify
import copy
from flask import request
from ExaminationModalApi import api16_bp, app
from ExaminationModalApi.content_loader.storage import CONTENT_VIDEO, CONTENT_MUSIC_HOMEPAGE, CONTENT_MUSIC
from ExaminationModalApi.jwt_login import agency_required, local_agency


@api16_bp.route('/api16/media')
@agency_required()
def media():
    delete_watermark = request.args.get('delete_watermark')
    content_types = (CONTENT_VIDEO, CONTENT_MUSIC_HOMEPAGE)
    rename = {
        CONTENT_MUSIC_HOMEPAGE: CONTENT_MUSIC,
        CONTENT_VIDEO: CONTENT_VIDEO
    }
    content = app.content_storage.content
    solutions = dict()
    if local_agency:
        code = local_agency.custom.code
    else:
        code = None
    for content_type in content_types:
        each_content = content[content_type]
        r_content_type = rename[content_type]
        for each, vs in each_content.items():
            for v in vs:
                value = copy.deepcopy(v)
                if code in ['SHWYSLSWKJ'] or delete_watermark == '1':
                    if value['asset']:
                        for i in range(len(value['asset'])):
                            value['asset'][i] = value['asset'][i].replace('功法/', '功法无水印/')

                solutions.setdefault(r_content_type, list()).append(value)

    solutions['asset_prefix'] = app.config['CONTENT_ASSET_URL_PREFIX']

    return jsonify(solutions)