# -*- encoding: utf-8 -*-
from ExaminationModalApi import api16, db
from ExaminationModalApi.model.problems import ProblemResult, Problem, problem_fields
from ExaminationModalApi.jwt_login import agency_required, local_agency
from flask_restful import Resource, reqparse, marshal_with


def save_report_problem_result(report, problem_options):
    '''
    :param report: <Report object)>
    :param problem_options: <class 'list'>: [[<ProblemOption 6>], [<ProblemOption 13>], [<ProblemOption 29>]]
    :return:
    '''
    for problem_option in problem_options:
        for pro in problem_option:
            p = ProblemResult(owner=report.owner,
                              agency=report.agency,
                              problem_id=pro.problem_id,
                              problem_option_id=pro.id,
                              report=report
                              )
            db.session.add(p)


parser = reqparse.RequestParser()


class ProblemList(Resource):
    @agency_required()
    @marshal_with(problem_fields)
    def get(self):
        custom = local_agency.custom
        p = Problem.query.filter_by(custom=custom).order_by(Problem.id).all()
        return p


api16.add_resource(ProblemList, '/api16/problems')
