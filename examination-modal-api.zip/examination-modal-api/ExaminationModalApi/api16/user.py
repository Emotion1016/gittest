from datetime import datetime
from functools import wraps

from flask import jsonify, current_app
from flask_restful import Resource, reqparse, marshal_with, abort, marshal

from ExaminationModalApi import db, bcrypt, api16, api16_bp
from ExaminationModalApi.jwt_login import create_user_jwt_token, agency_required, local_agency, local_user
from ExaminationModalApi.model.agency import Agency
from ExaminationModalApi.model.medical_condition import MedicalCondition
from ExaminationModalApi.model.user import User, simple_user_fields, simple_user_fields_with_id, to_gender
from ExaminationModalApi.model.vendor import Vendor
from ExaminationModalApi.model.sign_name import SignName
from ExaminationModalApi.util import to_date
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode


def medical_history(l):
    if not l:
        return None

    try:
        condition = MedicalCondition.query.get(l)
        if not condition:
            raise ValueError('%d is not a valid condition id')

        return condition
    except ValueError:
        raise
    except Exception:
        raise ValueError('each medical_history item must be an integer')


def to_agency(key):
    if not key:
        return None
    agency = Agency.query.filter(Agency.key == str(key)).first()
    if not agency:
        current_app.logger.warning('invalid agency key %s', key)
    return agency


def to_vendor(key):
    if not key:
        return None
    vendor = Vendor.query.filter(Vendor.code == str(key)).first()
    if not vendor:
        current_app.logger.warning('invalid vendor key %s', key)
    return vendor


def is_from_vendor(key):
    if key:
        return True
    else:
        return False


user_create_simple_parse = reqparse.RequestParser()
user_create_simple_parse.add_argument('cellphone', type=str, help='cellphone number', required=True)
user_create_simple_parse.add_argument('name', type=str, help='user name')
user_create_simple_parse.add_argument('birthday', type=to_date, help='user birthday, in format yyyy-mm-dd')
user_create_simple_parse.add_argument('age', type=int, help='user age')
user_create_simple_parse.add_argument('gender', type=to_gender, help='gender, 1-male, 2-female', required=True)
user_create_simple_parse.add_argument('height', type=int, help='height in cm', required=True)
user_create_simple_parse.add_argument('weight', type=int, help='weight in kg', required=True)
user_create_simple_parse.add_argument('medical_history', type=medical_history, help='medical history list', action='append')


user_patch_parser = reqparse.RequestParser()
user_patch_parser.add_argument('name', type=str, help='user name', required=True)
user_patch_parser.add_argument('birthday', type=to_date, help='user birthday, in format yyyy-mm-dd')
user_patch_parser.add_argument('age', type=int, help='user age')
user_patch_parser.add_argument('gender', type=to_gender, help='gender, 1-male, 2-female', required=True)
user_patch_parser.add_argument('height', type=int, help='height in cm', required=True)
user_patch_parser.add_argument('weight', type=int, help='weight in kg', required=True)
user_patch_parser.add_argument('medical_history', type=medical_history, help='medical history list', action='append')


user_create_parser = user_patch_parser.copy()
user_create_parser.add_argument('cellphone', type=str, help='cellphone number', required=True)
user_create_parser.add_argument('code', type=str, help='cellphone verification code', required=True)
user_create_parser.add_argument('password', type=str, help='password', required=True)
user_create_parser.add_argument('agency_key', dest='agency', type=to_agency, help='agency identification key')
user_create_parser.add_argument('vendor_code', dest='vendor', type=to_vendor, help='vendor identification code')
user_create_parser.add_argument('vendor_code', dest='is_from_vendor', type=is_from_vendor, help='vendor identification code')


user_login_parser = reqparse.RequestParser()
user_login_parser.add_argument('cellphone', type=str, help='cellphone number', required=True)
user_login_parser.add_argument('password', type=str, help='password', required=True)


user_change_password_parser = reqparse.RequestParser()
user_change_password_parser.add_argument('old_password', type=str, help='old password', required=True)
user_change_password_parser.add_argument('new_password', type=str, help='new password', required=True)


user_reset_password_parser = reqparse.RequestParser()
user_reset_password_parser.add_argument('cellphone', type=str, help='cellphone number', required=True)
user_reset_password_parser.add_argument('code', type=str, help='cellphone verification code', required=True)
user_reset_password_parser.add_argument('new_password', type=str, help='new password', required=True)


common_login_parse = reqparse.RequestParser()
common_login_parse.add_argument('name', type=str, help='agency login name or cellphone number', required=True)
common_login_parse.add_argument('password', type=str, help='password', required=True)


def user_info_with_token():
    def _decorator(f):
        @wraps(f)
        def _f(*args, **kwargs):
            u = f(*args, **kwargs)
            response = jsonify(marshal(u, simple_user_fields_with_id))

            response.set_cookie(
                'X-ZHIYUN-USER-TOKEN',
                create_user_jwt_token(u),
                secure=(not current_app.config.get('DEBUG', False)),
                httponly=True,
            )
            return response
        return _f
    return _decorator


@api16_bp.route('/api16/users/register', methods=['POST'])
@agency_required()
def user_register():
    cellphone_create_parser = reqparse.RequestParser()
    cellphone_create_parser.add_argument('cellphone', type=str, help='cellphone number', required=True)
    args = cellphone_create_parser.parse_args()
    u = User.query.filter(User.cellphone == args['cellphone']).first()
    if not u:
        u = User(cellphone=args['cellphone'])
        db.session.add(u)
        db.session.commit()

    sign_name = SignName.query.filter(SignName.agency == local_agency, SignName.user == u).first()
    u.signed = bool(sign_name)
    if sign_name:
        u.sign_id = sign_name.id
    return jsonify(marshal(u, simple_user_fields))


@api16_bp.route('/api16/users/user_info', methods=['POST'])
def user_info():
    user_info_parser = reqparse.RequestParser()
    user_info_parser.add_argument('cellphone', type=str, help='cellphone number', required=True)
    user_info_parser.add_argument('gender', type=to_gender, help='gender, 1-male, 2-female')
    user_info_parser.add_argument('age_range', type=str, help='age range')
    user_info_parser.add_argument('stage', type=str, help='user stage')
    user_info_parser.add_argument('weight', type=str, help='user weight')
    user_info_parser.add_argument('height', type=str, help='user height')
    user_info_parser.add_argument('idcard', type=int, help='user idcard')
    user_info_parser.add_argument('name', type=str, help='user name')
    user_info_parser.add_argument('ages', type=int, help='user ages')

    args = user_info_parser.parse_args()
    u = User.query.filter(User.cellphone == args['cellphone']).first()
    if not u:
        my_abort(error=ErrorCode.user_not_exist)

    u.update_info(args)

    db.session.commit()
    return jsonify(marshal(u, simple_user_fields))
