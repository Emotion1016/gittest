import pprint
from datetime import datetime
from enum import Enum
from functools import wraps
from typing import Optional
from uuid import uuid4
import time
import numpy
import json
import math
import cv2
import numpy as np

import requests
from flask import request, jsonify, abort, current_app
from flask_restful import marshal
from pydiagnosis import face, tongue, autoPhoto, autoPhotoTongue
import string
import random

from ExaminationModalApi.model.util import get_db_fields
from .. import wechat_media, db, api16_bp
from ..util import https_for
from ..model.util import add_photo_url_when_upload, get_first_before_this
from ..jwt_login import local_user, local_agency, agency_required
from ..model.face_result import FaceResult, basic_face_result_fields_with_url
from ..model.photo import Photo
from ..model.tongue_result import TongueResult, basic_tongue_result_fields_with_url

from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode
from ExaminationModalApi import redis_conn


class PhotoType(Enum):
    face = 1
    tongue = 2


ANALYZE_FUNCTIONS = {
    PhotoType.face: face,
    PhotoType.tongue: tongue,
}


def get_wechat_media() -> (str, bytes):
    mid = request.json.get('id')
    if not mid:
        abort(400)
    try:
        media = wechat_media.download(mid)
    except:
        current_app.logger.exception('download media %s failed', mid)
        abort(400)
        return

    if media.status_code != requests.codes.ok:
        current_app.logger.error('download media %s failed, code %s', media.status_code)
        abort(400)

    return media.headers.get('content-type'), media.content


def save_to_oss(content: bytes, content_type: str, title: str, photo_type: PhotoType) -> str:
    oss_id, _ = current_app.bucket.upload_content(
        content, content_type,
        title,
        {
            'photo-type': photo_type.name,
        }
    )

    return oss_id


def analyze(content: bytes, photo_type: PhotoType):
    assert photo_type in (PhotoType.face, PhotoType.tongue), 'internal error, invalid photo type: %r' % (photo_type, )
    result = ANALYZE_FUNCTIONS[photo_type](content)
    ans = result.to_dict()
    return ans


def save_analyze_result(analyze_result, user_id: Optional[int], agency_id: Optional[int], oss_id: str, photo_type: PhotoType):
    photo = Photo(
        oss_id=oss_id,
        upload_time=datetime.utcnow(),
    )
    photo.owner_id = user_id
    photo.agency_id = agency_id

    if photo_type == PhotoType.face:
        result = FaceResult.from_dict(analyze_result)
    else:
        result = TongueResult.from_dict(analyze_result)
    result.owner_id = user_id
    result.agency_id = agency_id
    result.photo = photo
    result.time = datetime.utcnow()
    result.algorithm_version_id = 1
    result.client_info = request.headers.get('clientinfo')
    result.channel = request.headers.get('channel')
    result.sn = request.headers.get('sn')
    result.mark = 0

    db.session.add(result)
    db.session.commit()
    return result


def is_detected(result, photo_type: PhotoType):
    if photo_type == PhotoType.face:
        return getattr(result, 'faceDetectRes', 0) > 0
    else:
        return getattr(result, 'tongueDetectRes', 0) > 0


def handle_wechat_photo(photo_type: PhotoType):
    content_type, content = get_wechat_media()

    oss_id = save_to_oss(
        content,
        content_type,
        'w-%s/%s' % (local_user.id, request.json.get('id')),
        photo_type
    )
    ans = analyze(content, photo_type)

    result = save_analyze_result(ans, local_user.id, None, oss_id, photo_type)

    ans['id'] = result.id

    current_app.logger.info('output: %s', pprint.pformat(ans))

    return jsonify({
        'id': ans['id'],
        'detectRes': is_detected(result, photo_type)
    })


ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'bmp'}


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def detect_photo_errors(f):
    @wraps(f)
    def _f(*args, **kwargs):
        if 'photo' not in request.files:
            my_abort(error=ErrorCode.photo_not_found)
        photo = request.files['photo']
        if not photo.filename or not allowed_file(photo.filename):
            my_abort(error=ErrorCode.photo_format_error)
        return f(photo, *args, **kwargs)
    return _f


@detect_photo_errors
def handle_form_photo(photo, photo_type: PhotoType):
    content = photo.read(-1)
    content_type = 'image/%s' % (photo.filename.rsplit('.', 1)[1].lower(), )

    tm = datetime.now().strftime('%Y%m')
    time_str = datetime.now().strftime('%Y%m%d-%H%M%S')
    file_id = uuid4()

    if local_user:
        title = '%s/%s/%s/%s/%s-%s' % (local_agency.login_name, local_user.cellphone or local_user.id, tm, photo_type.name, time_str, file_id)
    else:
        title = '%s/%s/%s/%s-%s' % (local_agency.login_name, tm, photo_type.name, time_str, file_id)
    oss_id = save_to_oss(
        content,
        content_type,
        title,
        photo_type
    )

    ans = analyze(content, photo_type)
    result = save_analyze_result(ans, local_user.id if local_user else None, local_agency.id if local_agency else None, oss_id, photo_type)
    if not is_detected(result, photo_type):
        if photo_type == PhotoType.face:
            my_abort(error=ErrorCode.face_not_detected)
        if photo_type == PhotoType.tongue:
            my_abort(error=ErrorCode.tongue_not_detected)

    ans['id'] = result.id

    current_app.logger.info('output: %s', pprint.pformat(ans))
    if request.headers.get('category') == '2':
        detail_page = https_for('reportTzbs_{photo_type}/{id}'.format(photo_type=photo_type.name, id=ans['id']),
                                _frontpage=True)
    else:
        detail_page = https_for('report_{photo_type}/{id}'.format(photo_type=photo_type.name, id=ans['id']),
                                _frontpage=True)
    result.photo_url = current_app.bucket.get_thumb_url(result.photo.oss_id,
                                                        current_app.config['OSS_THUMB_IMAGE_STYLE'])

    if photo_type.name == 'face':
        data = marshal(result, basic_face_result_fields_with_url)
    else:
        data = marshal(result, basic_tongue_result_fields_with_url)
    data['detail_page'] = detail_page
    return jsonify(data)


@api16_bp.route('/api16/photos/face', methods=['POST'])
@agency_required()
def face_diagnosis():
    return handle_form_photo(PhotoType.face)


@api16_bp.route('/api16/photo')
def get_photo():
    face_result = FaceResult.query.get(request.args.get('id'))
    return str(face_result.id)


@api16_bp.route('/api16/photos/tongue', methods=['POST'])
@agency_required()
def tongue_diagnosis():
    return handle_form_photo(PhotoType.tongue)


@api16_bp.route('/api16/<photo_type>/<photo_id>')
def photo_info(photo_type, photo_id):
    if photo_type == PhotoType.face.name:
        face_result = FaceResult.query.filter_by(id=photo_id).first()
        if face_result:
            add_photo_url_when_upload(face_result)
            result = marshal(face_result, basic_face_result_fields_with_url)
            return jsonify(result)

    elif photo_type == PhotoType.tongue.name:
        tongue_result = TongueResult.query.filter_by(id=photo_id).first()
        if tongue_result:
            add_photo_url_when_upload(tongue_result)
            result = marshal(tongue_result, basic_tongue_result_fields_with_url)
            return jsonify(result)

    abort(400)


def update_stable_status(_id, data, exp_delta_time, exp_p, exp_d, percent):
    '''
    :param _id: redis key
    :param data: input data
    :param exp_delta_time: defect count time
    :param exp_p: variance of x and y
    :param exp_d: variance of h and w
    :param percent: percent of defected picture
    :return:
    '''
    exp_max_count = 30  # 参与计算的最大data个数
    exp_min_count = 2
    # exp_std_p = 2  # x,y 最大标准差
    # exp_std_d = 2  # w,h 最大标准差

    exp_std_p = math.sqrt(exp_p)  # x,y 最大标准差
    exp_std_d = math.sqrt(exp_d)  # w,h 最大标准差

    get_total_count = 0
    time_enough = False

    redis_conn.rpush(_id, json.dumps(data))

    data.update({
        'stable': 0,
        'show': 0
    })
    # 未识别到脸返回False
    if data['x_point'] == 0:
        return data

    # 参与计算的data
    tmp = redis_conn.lrange(_id, -exp_max_count, -1)

    now = time.time()
    values = []

    # 数据过滤
    for value_byte in tmp:
        value = json.loads(value_byte.decode('utf-8'))
        if now - value.get('time', 0) < exp_delta_time:
            get_total_count += 1
            if value['x_point'] != 0:
                values.append(value)
        elif now - value.get('time', 0) < exp_delta_time + 1:
            time_enough = True

    # 显不显示
    show = 0
    if len(values) == 1:
        show = 1
    elif len(values) > 1:
        std_x = numpy.std([i['x_point'] for i in values[-2:]])
        std_y = numpy.std([i['y_point'] for i in values[-2:]])
        std_w = numpy.std([i['width'] for i in values[-2:]])
        std_h = numpy.std([i['height'] for i in values[-2:]])

        if max(std_x, std_y, std_h, std_w) < 30:
            show = 1

    if data['status'] == 3 or data['status'] == 4:
        show = 0

    data['show'] = show

    # 参与计算的比例不低于占比(50%)
    if len(values) / get_total_count < percent:
        return data

    # 参与计算的最小个数
    if len(values) < exp_min_count:
        return data

    # 参与计算的时间是否足够
    if not time_enough:
        return data

    # 开始计算标准差
    std_x = numpy.std([i['x_point'] for i in values])
    std_y = numpy.std([i['y_point'] for i in values])
    std_w = numpy.std([i['width'] for i in values])
    std_h = numpy.std([i['height'] for i in values])
    # print(len(values), get_total_count, std_x, std_y, std_w, std_h)

    # 标准差比较
    if std_x < exp_std_p and std_y < exp_std_p:
        fixed = 1
    else:
        fixed = 0

    if std_w < exp_std_d and std_h < exp_std_d:
        stable = 1
    else:
        stable = 0

    data['stable'] = fixed and stable
    return data


@api16_bp.route('/api16/photos/get_access_token', methods=['POST'])
def get_access_token():
    random_pool = string.ascii_letters + string.digits
    access_token = ''.join(random.sample(random_pool, 20))
    data = {'diagnosis': {}, 'height': 0, 'y_point': 0, 'x_point': 0, 'width': 0, 'status': 0}
    redis_conn.rpush(access_token, json.dumps(data))  # 初始化列表
    redis_conn.expire(access_token, 60 * 10)  # 过期时间10分钟
    return jsonify({'access_token': access_token})


@api16_bp.route('/api16/photos/auto_face', methods=['POST'])
@detect_photo_errors
def auto_photo(photo):
    content = photo.read(-1)

    if len(content) > 100 * 1024:
        my_abort(error=ErrorCode.picture_too_large)

    _id = request.form.get('access_token')
    if not redis_conn.ttl(_id):
        my_abort(error=ErrorCode.access_token_error)
    ans = autoPhoto(content)
    data = ans.to_dict()
    data['time'] = time.time()

    if request.headers.get('clientinfo') == '3.2.0':
        nparr = np.fromstring(content, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        shape = img.shape

        a = int(500 / 1920 * shape[0])
        b = int(500 / 1080 * shape[1])
        dev = (shape[1] / 2, int(960 / 1920 * shape[0]))

        if not check_in_range(data['x_point'], data['y_point'], data['width'], data['height'], a, b, dev):
            data['status'] = 4

    update_stable_status(_id=_id, data=data, exp_delta_time=1, exp_p=2.75, exp_d=6.66, percent=0.7)
    return jsonify(data)


@api16_bp.route('/api16/photos/auto_tongue', methods=['POST'])
@detect_photo_errors
def auto_photo_tongue(photo):
    content = photo.read(-1)

    if len(content) > 100 * 1024:
        my_abort(error=ErrorCode.picture_too_large)

    _id = request.form.get('access_token')
    if not redis_conn.ttl(_id):
        my_abort(error=ErrorCode.access_token_error)

    ans = autoPhotoTongue(content)
    data = ans.to_dict()
    data['time'] = time.time()

    nparr = np.fromstring(content, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    shape = img.shape
    a = int(380 / 1920 * shape[0])
    b = int(380 / 1080 * shape[1])
    dev = (shape[1] / 2, int(1060 / 1920 * shape[0]))
    # status 0: 正好, 1: 太远但显示, 2: 太近, 3 太远不显示, 4 未检测到
    if request.headers.get('clientinfo') == '3.2.0' and \
            not check_in_range(data['x_point'], data['y_point'], data['width'], data['height'], a, b, dev):
        data['status'] = 4
    elif data['x_point'] == 0:
        data['status'] = 4
    elif data['width'] > 40:
        data['status'] = 0
    else:
        data['status'] = 1
    update_stable_status(_id=_id, data=data, exp_delta_time=0.5, exp_p=5.62, exp_d=3.76, percent=0.5)
    return jsonify(data)


def check_in_range(x, y, w, h, a, b, dev):
    """
    :param x: 矩形左上角x坐标
    :param y: 矩形左上角y坐标
    :param w: 矩形宽
    :param h: 矩形高
    :param a: 椭圆半长
    :param b: 椭圆半高
    :param dev: 椭圆中心点
    :return: True/False
    """
    points = [(x, y), (x + w, y), (x, y + h), (x + w, y + h)]
    for i, j in points:
        i -= dev[0]
        j -= dev[1]
        in_range = (i / b) ** 2 + (j / a) ** 2 < 1
        if not in_range:
            return False

    return True
