from flask import current_app, jsonify, request as reqs
from flask_jwt import jwt_required
from flask_restful import Resource, reqparse, marshal_with, fields, marshal

from ExaminationModalApi import DEFAULT_PAGINATION_ITEM_NUM, api16, api16_bp, db, app
from ExaminationModalApi.jwt_login import local_agency, local_user, local_agency_type, end_user_required, \
    login_user, agency_required
from ExaminationModalApi.model.pulse import Pulse
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode
import requests
import json
import datetime
import urllib3
from urllib3.exceptions import InsecureRequestWarning

urllib3.disable_warnings(InsecureRequestWarning)
domain = app.config.get('MAI_DOMAIN')
channel = app.config.get('MAI_CHANNEL')
secret = app.config.get('MAI_SECRET')


@api16_bp.route("/api16/submitpulse", methods=['POST'])
@agency_required()
def submit_pulse():
    agency_id = local_agency.id if local_agency else None
    user_id = local_user.id if local_user else None
    info = reqs.json
    mai = info.get("mai", "")
    exts = info.get("ext", "")
    blood_age = info.get("blood_age", "")
    blood_dia = info.get("blood_dia", "")
    blood_sys = info.get("blood_sys", "")
    if not all([mai, exts, blood_age or blood_age == 0, blood_dia or blood_dia == 0, blood_sys or blood_sys == 0]):
        my_abort(error=ErrorCode.pulse_data_error)
    token = get_token()
    mai_json = json.dumps(mai)
    req = requests.post(url=domain + "/save", headers={
        "Authorization": "Bearer " + token,
        "CONTENT-TYPE": "application/json"
    }, data=mai_json, verify=False)
    app.logger.debug("first req:" + req.text)
    pulseid = int(req.json().get("id"))
    if not pulseid:
        my_abort(error=ErrorCode.pulse_first_error)

    ext = {
        "channel": channel,
        "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "id": pulseid,
        "blood_age": blood_age,
        "blood_dia": blood_dia,
        "blood_sys": blood_sys,
        "exts": exts
    }

    ext_json = json.dumps(ext)
    req2 = requests.post(url=domain + "/exts", headers={
        "Authorization": "Bearer " + token,
        "CONTENT-TYPE": "application/json"
    }, data=ext_json, verify=False, )
    app.logger.debug("second req:" + req2.text)
    if req2.json().get("status"):
        req3 = requests.get(url=domain + "/exts", headers={
            "Authorization": "Bearer " + token,
            "CONTENT-TYPE": "application/json"
        }, params={
            "id": pulseid,
            "channel": channel
        }, verify=False, )
        if req3.json().get("url"):
            pulse = Pulse()
            try:
                pulse.save_result(pulse, req3.json(), agency_id, user_id)
            except Exception as e:
                app.logger.debug(e)
                my_abort(error=ErrorCode.pulse_database_error)
            return jsonify({"id": pulse.id})
    my_abort(error=ErrorCode.pulse_error)


def get_token():
    req = requests.get(domain + "/token", params={
        "channel": channel,
        "secret": secret
    }, verify=False)
    try:
        data = req.json()
        token = data.get("token")
    except:
        return my_abort(error=ErrorCode.pulse_error)
    return token
