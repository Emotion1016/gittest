from datetime import datetime

from flask import jsonify, current_app, request
from flask_restful import Resource, reqparse, marshal

from ExaminationModalApi import bcrypt, api16, api16_bp
from ExaminationModalApi.jwt_login import create_agency_jwt_token, agency_required, local_agency
from ExaminationModalApi.model.agency import Agency, simple_agency_fields
from ExaminationModalApi.model.agency_info import AgencyInfo
from ExaminationModalApi.model.sign_name import SignName
from ExaminationModalApi.util import to_timestamp
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode
import re


class TokenList(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('loginName', type=str, help='ID of the agency performing login', required=True)
    parser.add_argument('password', type=str, help='password of the agency', required=True)

    def post(self):
        args = self.parser.parse_args()
        agency = Agency.query.filter(Agency.login_name == args['loginName']).first()

        if not agency:
            my_abort(error=ErrorCode.agency_not_exists)
        if not bcrypt.check_password_hash(agency.password, args.get('password')):
            my_abort(error=ErrorCode.password_check_error)
        if agency.del_flag:
            my_abort(error=ErrorCode.agency_deleted)

        version = request.headers.get('clientinfo')

        if version and int(str(version)[0]) >= 3:
            ...
        # 老版本系统
        else:
            if 1 not in agency.categories:
                my_abort(error=ErrorCode.agency_permission_denied)

        if agency.type == 'C' and SignName.query.filter(SignName.agency == agency).first():
            agency.signed = True
        else:
            agency.signed = False

        iat = datetime.utcnow()
        exp = iat + current_app.config.get('JWT_EXPIRATION_DELTA')
        nbf = iat + current_app.config.get('JWT_NOT_BEFORE_DELTA')
        token = create_agency_jwt_token(iat, exp, nbf, agency)
        return jsonify({
            'agency': marshal(agency, simple_agency_fields),
            'expiresAt': to_timestamp(exp),
            'issuedAt': to_timestamp(iat),
            'token': token.decode('utf-8'),
        })


api16.add_resource(TokenList, '/api16/tokens')

verify_parser = reqparse.RequestParser()
verify_parser.add_argument('password', type=str, help='password of the agency', required=True)


@api16_bp.route('/api16/token/verifyPassword', methods=['POST'])
@agency_required()
def verify_password():
    args = verify_parser.parse_args()
    if bcrypt.check_password_hash(local_agency.password, args['password']):
        ans = { 'ok': True }
    else:
        ans = { 'ok': False }
    return jsonify(ans)
