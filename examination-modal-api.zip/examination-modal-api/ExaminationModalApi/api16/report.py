from flask import current_app, jsonify
from flask_jwt import jwt_required
from flask_restful import Resource, reqparse, marshal_with, fields, marshal
from sqlalchemy import desc
from werkzeug.exceptions import abort
import re

from ExaminationModalApi import DEFAULT_PAGINATION_ITEM_NUM, api16, api16_bp, db
from ExaminationModalApi.jwt_login import local_agency, local_user, local_agency_type, end_user_required, \
    login_user, agency_required
from ExaminationModalApi.model.report import Report, simple_report_fields, \
    simple_shared_report_fields, detail_report_with_thumb, brief_report_fields, report_page_fields
from ExaminationModalApi.model.util import add_photos_url
from ExaminationModalApi.model.share import Share
from ExaminationModalApi.model.user import User
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode


report_list_fields = {
    'end': fields.Boolean(),
    'data': fields.List(fields.Nested(simple_report_fields)),
}

shared_report_list_fields = {
    'end': fields.Boolean(),
    'data': fields.List(fields.Nested(simple_shared_report_fields)),
}


# class ReportBrief(Resource):
#     @end_user_required()
#     @marshal_with(brief_report_fields)
#     def get(self):
#         query = DailyReport.query.filter(DailyReport.agency == local_agency)
#         if local_user:
#             query = query.filter(DailyReport.owner == local_user)
#         return [d.report for d in query.all()]
#
#
# api16.add_resource(ReportBrief, '/api16/reportsBrief')


class ReportBrief(Resource):
    @end_user_required()
    @marshal_with(brief_report_fields)
    def get(self):
        query = Report.query.filter(Report.agency == local_agency, Report.mark != 2, Report.del_flag != 1)
        if local_user:
            query = query.filter(Report.owner == local_user)
        query = query.order_by(Report.time)
        return query.all()


api16.add_resource(ReportBrief, '/api16/reportsBrief')


class ReportList(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('page', type=int, help='Page of report list')
    parser.add_argument('per_page', type=int, help='per page', default=6)

    @staticmethod
    def list_reports():
        query = Report.query.filter(Report.agency == local_agency, Report.mark != 2, Report.del_flag != 1)
        return query

    @staticmethod
    def order_column():
        return Report.time

    @agency_required()
    @marshal_with(report_page_fields)
    def get(self):
        args = self.parser.parse_args()
        page = args.get('page')
        query = self.list_reports()
        paginate = query.order_by(desc(self.order_column())).\
            paginate(page=page, per_page=args['per_page'])
        for report in paginate.items:
            report.face_photo_url = current_app.bucket.get_thumb_url(report.face_result.photo.oss_id,
                                                                     current_app.config['OSS_THUMB_MINI_IMAGE_STYLE'])
            report.tongue_photo_url = current_app.bucket.get_thumb_url(report.tongue_result.photo.oss_id,
                                                                       current_app.config['OSS_THUMB_MINI_IMAGE_STYLE'])

        return paginate


class ReportDetail(Resource):
    @end_user_required()
    @marshal_with(detail_report_with_thumb)
    def get(self, report_id):
        query = Report.query.filter(
            Report.owner_id == local_user.id,
            Report.id == report_id,
            Report.del_flag != 1).first()
        if not query:
            my_abort(error=ErrorCode.not_found)

        add_photos_url(query)

        return query

    @agency_required()
    def delete(self, report_id):
        query = Report.query.get(report_id)
        if not query:
            my_abort(error=ErrorCode.not_found)
        if query.agency_id != local_agency.id:
            my_abort(error=ErrorCode.access_error)

        query.del_flag = 1
        db.session.commit()

        return my_abort(error=ErrorCode.success)


api16.add_resource(ReportList, '/api16/reports')

api16.add_resource(ReportDetail, '/api16/report/<report_id>')


change_cellphone_parser = reqparse.RequestParser()
change_cellphone_parser.add_argument('key', type=str, required=True, help='report key')
change_cellphone_parser.add_argument('cellphone', type=str, required=True, help='new cellphone')


@api16_bp.route('/api16/report_change_user', methods=['POST'])
@agency_required()
def report_change_user():
    args = change_cellphone_parser.parse_args()
    share = Share.query.filter_by(key=args['key']).first()
    if not share:
        my_abort(error=ErrorCode.not_known)

    report = share.report
    if not report.agency == local_agency:
        my_abort(error=ErrorCode.access_error)

    if not re.match(r'^1[3456789][0-9]{9}$', args['cellphone']):
        my_abort(error=ErrorCode.cellphone_illegal)

    user = User.query.filter_by(cellphone=args['cellphone']).first()
    if not user:
        user = User(cellphone=args['cellphone'])
        db.session.add(user)

    report.owner = user
    db.session.commit()

    return jsonify({'status': 'ok'})

