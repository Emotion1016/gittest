# -*- encoding: utf-8 -*-
from flask import jsonify, request
from flask_restful import Resource, marshal
from ExaminationModalApi.model.advertise import Advertise, AdvertiseType, advertise_fields, advertise_default
from ExaminationModalApi.jwt_login import agency_required, local_agency
from ExaminationModalApi import api16


class AdvertiseList(Resource):
    @agency_required()
    def get(self):
        data = dict()
        category = request.headers.get('category') or '1'
        default = advertise_default.get(category)
        query = Advertise.query.filter(Advertise.agency_id == local_agency.id,
                                       Advertise.is_show == 1,
                                       Advertise.category == int(category))
        for i in range(1, 5):
            each = query.filter(Advertise.type == AdvertiseType(i)).\
                order_by(Advertise.index_id).all()
            if each:
                each_data = marshal(each, advertise_fields)
            else:
                each_data = marshal(default.get(AdvertiseType(i).name, []), advertise_fields)
            data[AdvertiseType(i).name] = each_data

        return jsonify(data)


api16.add_resource(AdvertiseList, '/api16/advertise')

