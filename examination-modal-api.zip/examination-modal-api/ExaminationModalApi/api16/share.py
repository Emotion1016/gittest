import random

from flask import jsonify, current_app
from flask_restful import abort, marshal

from ExaminationModalApi import api16_bp, cache
from ExaminationModalApi.api16.report import detail_report_with_thumb
from ExaminationModalApi.model.product import SymptomDefine, ProductCategorySymptom, ProductCategory, ProductSymptom, \
    Product, ProductLocation, product_fields
from ExaminationModalApi.model.products import CustomizationProduct, CustomizationProductCategory, \
    ServiceDiagnoseResult, category_fields
from ExaminationModalApi.model.report import Report
from ExaminationModalApi.model.share import Share
from ExaminationModalApi.model.sign_name import SignName
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode


@api16_bp.route('/api16/share/<string:key>', methods=['GET', ], endpoint='get_share')
def get_share(key):
    query = Share.query.filter(Share.key == key).first()
    if not query or not query.report:
        abort(404)
    report = query.report
    if report.del_flag == 1:
        abort(404)
    report.face_photo_url = current_app.bucket.get_thumb_url(report.face_result.photo.oss_id,
                                                             current_app.config['OSS_THUMB_IMAGE_STYLE'])
    report.tongue_photo_url = current_app.bucket.get_thumb_url(report.tongue_result.photo.oss_id,
                                                               current_app.config['OSS_THUMB_IMAGE_STYLE'])

    sign_name = SignName.query.filter(SignName.agency_id == report.agency_id,
                                      SignName.user_id == report.owner_id).first()
    if not sign_name:
        sign_name = SignName.query.filter(SignName.report_id == report.id).first()
    report.sign_name_url = current_app.bucket.get_thumb_url(sign_name.oss_id, current_app.config[
        'OSS_THUMB_IMAGE_STYLE']) if sign_name else None
    report.product = get_product(report.id)
    # current_app.logger.debug(
    #     'face_photo_url: %s, tongue_photo_url: %s',
    #     report.face_photo_url, report.tongue_photo_url
    # )
    # current_app.logger.debug('loaded: %s', pprint.pformat(dict(marshal(report, detail_report_with_thumb))))
    answer = marshal(report, detail_report_with_thumb)
    # hide the real ID
    answer['id'] = key
    return jsonify(answer)


def get_product(report_id):
    report = Report.query.get(report_id)
    if not report:
        my_abort(error=ErrorCode.not_found)
    symptoms = report.symptoms

    name = symptoms[0].name if symptoms else '健康'
    symptom = ServiceDiagnoseResult.query.filter(ServiceDiagnoseResult.name == name).first()
    if symptom:
        products = CustomizationProductCategory.query. \
            join(CustomizationProduct, CustomizationProduct.category_id == CustomizationProductCategory.id). \
            filter(CustomizationProduct.symptoms.any(id=symptom.id),
                   CustomizationProductCategory.agencies.any(id=report.agency.id)).all()
        data = [i for i in products]
    else:
        data = []
    return marshal(data, category_fields)
