from flask_restful import reqparse
import json
from flask import jsonify

from ExaminationModalApi import api16_bp, db
from ExaminationModalApi.jwt_login import agency_required, local_agency


@api16_bp.route('/api16/settings', methods=['POST'])
@agency_required()
def settings():
    parse = reqparse.RequestParser()
    parse.add_argument('is_print', type=int, help='print or not')

    args = parse.parse_args()
    if args.get('is_print') is not None:
        setting = local_agency.setting_dict
        setting['is_print'] = args.get('is_print')
        local_agency.setting = json.dumps(setting)

        db.session.commit()

    return jsonify(local_agency.setting_dict)