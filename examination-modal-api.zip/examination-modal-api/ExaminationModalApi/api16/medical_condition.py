# -*- encoding: utf-8 -*-
from ExaminationModalApi import api16, api16_bp, cache
from ExaminationModalApi.model.medical_condition import MedicalCondition, medical_condition_fields
from ExaminationModalApi.jwt_login import local_agency, local_user, agency_required

from flask_restful import Resource, reqparse, marshal, marshal_with


class MedicalConditionList(Resource):
    @agency_required()
    @cache.cached(3600*2)
    @marshal_with(medical_condition_fields)
    def get(self):
        m = MedicalCondition.query.filter(MedicalCondition.del_flag == 0).all()
        return m


api16.add_resource(MedicalConditionList, '/api16/medical_conditions')


def medical_history(l):
    if not l:
        return None

    try:
        condition = MedicalCondition.query.get(l)
        if not condition:
            raise ValueError('%d is not a valid condition id')

        return condition
    except ValueError:
        raise
    except Exception:
        raise ValueError('each medical_history item must be an integer')



