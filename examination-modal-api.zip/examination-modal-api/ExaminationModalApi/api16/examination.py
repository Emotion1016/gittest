import json
import pprint
from datetime import datetime

from flask import request, current_app
from flask_restful import Resource, reqparse, marshal, abort, marshal_with
from sqlalchemy import desc, and_

from ExaminationModalApi import api16, db
from ExaminationModalApi.examination import run
from ExaminationModalApi.jwt_login import local_agency_type, local_agency, local_user, login_user, agency_required, \
    login_user_required
from ExaminationModalApi.model.daily_report import DailyReport
from ExaminationModalApi.model.face_result import FaceResult, basic_face_result_fields
from ExaminationModalApi.model.question_result import QuestionResult, question_fields
from ExaminationModalApi.model.sign_name import SignName
from ExaminationModalApi.model.report import Report, create_report_parser, detail_shared_report_fields
from ExaminationModalApi.model.share import Share
from ExaminationModalApi.model.symptom import Symptom
from ExaminationModalApi.model.tongue_result import TongueResult, basic_tongue_result_fields
from ExaminationModalApi.model.user_info_history import UserInfoHistory
from ExaminationModalApi.util import get_today_begin_utc_time, get_today_end_utc_time, get_city_from_ip
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode
from ExaminationModalApi.api16.problems import save_report_problem_result
from ExaminationModalApi.model.util import get_first_before_this


def get_ip(ip):
    city = get_city_from_ip(ip)
    if not city:
        r = Report.query.filter(Report.ip == ip, Report.city != '').order_by(desc(Report.id)).first()
        if r:
            return r.city
        else:
            return None
    else:
        return city


class Examination(Resource):

    @staticmethod
    def get_owner():
        return local_user if local_user else None

    @staticmethod
    def get_agency():
        return local_agency if local_agency else None

    @login_user_required()
    @marshal_with(detail_shared_report_fields)
    def post(self):
        args = create_report_parser.parse_args()
        owner, agency = self.get_owner(), self.get_agency()
        try:
            tongue_result = TongueResult.query.get_or_404(args['tongue_result_id'])
            face_result = FaceResult.query.get_or_404(args['face_result_id'])
            question_result = QuestionResult.query.get_or_404(args['question_result_id'])
            pulse_result_id = args["pulse_result_id"]
            exist_report = Report.query.filter(Report.tongue_result == tongue_result,
                                               Report.face_result == face_result,
                                               Report.question_result == question_result,
                                               Report.mark != 2).first()
            if exist_report:
                return exist_report

            report = create_report(face_result, tongue_result, question_result, pulse_result_id, args, agency, owner)

            return report
        except Exception as e:
            db.session.rollback()
            current_app.logger.exception('cannot handle request %r, %s' % (request.json, e))
            my_abort(error=ErrorCode.not_known)


api16.add_resource(Examination, '/api16/examinations')


def create_report(face_result, tongue_result, question_result, pulse_result_id, args, agency, owner):
    params = dict()
    params.update(marshal(question_result, question_fields))
    params.update(marshal(face_result, basic_face_result_fields))
    params.update(marshal(tongue_result, basic_tongue_result_fields))

    # current_app.logger.debug('loaded params: %s', pprint.pformat(params))
    new_info = args.get('user_info')
    if new_info and int(new_info.get("gender")) == 2:
        result = run(params, _type=3)
    else:
        result = run(params, _type=1)

    if new_info:
        new_info['medical_history'] = list(set(args['med_recommend'])) if args.get('med_recommend') else []
    if bool(agency) and bool(owner):
        if new_info:
            owner.update_info(new_info)

    user_info = UserInfoHistory.from_user(owner, new_info, agency.agency_info)

    city = get_ip(request.remote_addr)
    symptom_status = json.dumps(result['symptom_status'])
    mark = 0

    report = Report(
        owner=owner,
        agency=agency,
        face_result=face_result,
        tongue_result=tongue_result,
        question_result=question_result,
        modal_version_id=1,
        time=result['report_time'],
        health_score=result['total_score'],
        ip=str(request.remote_addr),
        city=city,
        client_info=args['client_info'],
        sn=request.headers.get('sn'),
        channel=args.get('channel'),
        symptom_status=symptom_status,
        solution_json=json.dumps(result['solutions']['keys']),
        ua=request.user_agent.string if request.user_agent else '',
        custom_id=agency.custom_id if agency else None,
        mark=mark
    )
    if pulse_result_id:
        report.pulse_result_id = pulse_result_id
    report.medical_history = list(set(args['med_recommend'])) if args.get('med_recommend') else []
    if local_user:
        local_user.medical_history = args.get('med_recommend') or []
    report.user_info = user_info
    db.session.add(report)
    if args.get('sign_name_id'):
        sign_name = SignName.query.get(args.get('sign_name_id'))
        sign_name.report_id = report.id
    if args.get('problem_options'):
        save_report_problem_result(report, args['problem_options'])

    if report.agency.type in ['A', 'C']:
        daily_report = DailyReport.query.filter(
            DailyReport.owner == report.owner, DailyReport.agency == report.agency
        ).filter(
            DailyReport.date == report.china_time.date()
        ).first()
        if daily_report:
            daily_report.report = report
        else:
            daily_report = DailyReport(
                date=report.china_time.date(),
                report=report,
                owner=report.owner,
                agency=report.agency,
            )
            db.session.add(daily_report)

    for s in result['symptoms']:
        db.session.add(Symptom(report=report, name=s['name'], score=s['score']))

    try:
        db.session.commit()
        share = Share.create_and_commit(report, db)
    except Exception as e:
        db.session.rollback()
        current_app.logger.exception('db commit error: %s' % e)
        current_app.logger.exception(str(args))

    return report

