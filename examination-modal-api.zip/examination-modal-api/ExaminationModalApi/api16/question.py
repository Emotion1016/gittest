from flask import jsonify, request
from flask_restful import reqparse, marshal
from datetime import datetime
import json

from ExaminationModalApi import api16_bp, db
from ExaminationModalApi.jwt_login import agency_required, local_agency, local_user
from ExaminationModalApi.model.question_result import QuestionResult, question_fields

questions = {
    "data": [
        {
            "id": 1,
            "index": 1,
            "label": "您平时容易怕冷、怕热、或手脚心热、口渴口干吗？",
            "options": [
                "怕冷 (或手脚冰凉)",
                "怕热",
                "手脚心热 口渴口干",
                "正常"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 2,
            "index": 2,
            "label": "您平时容易疲劳，出汗或晚上睡觉易出汗吗？",
            "options": [
                "容易疲劳",
                "稍动汗出",
                "夜间出汗",
                "正常"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 3,
            "index": 3,
            "label": "您平时小便怎么样？ ",
            "options": [
                "偏黄",
                "清长（色清，量多）",
                "夜尿频多",
                "正常"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 4,
            "index": 4,
            "label": "您平时大便怎么样？",
            "options": [
                "偏干",
                "偏黏",
                "偏稀(或大便溏)",
                "正常"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 5,
            "index": 5,
            "label": "您平时觉得口中有异样的味道吗？",
            "options": [
                "甜",
                "苦",
                "黏",
                "口淡",
                "正常"
            ],
            "exclusiveOption": 4,
            "multiple": True
        },
        {
            "id": 6,
            "index": 1,
            "label": "您平时容易心烦、情绪低落、睡眠不好吗？",
            "options": [
                "是",
                "否"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 7,
            "index": 6,
            "label": "您平时身体有胀满不适吗？",
            "options": [
                "乳房胀",
                "饭后腹胀",
                "两肋胀满",
                "无"
            ],
            "exclusiveOption": 1,
            "multiple": True
        },
        {
            "id": 8,
            "index": 2,
            "label": "您自己感觉腰膝酸软、腿脚无力、掉发严重吗？",
            "options": [
                "是",
                "否"
            ],
            "exclusiveOption": 1,
            "multiple": False
        }
    ]
}

questions_female = {
    "data": [
        {
            "id": 1,
            "index": 1,
            "label": "您自己觉得容易疲劳或乏力吗？",
            "options": [
                "是",
                "否"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 2,
            "index": 1,
            "label": "您平时容易怕冷、怕热、或手足心热吗？",
            "options": [
                "怕冷(或手脚冰凉)",
                "怕热",
                "手足心热",
                "正常"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 3,
            "index": 2,
            "label": "您平时容易出汗或晚上睡觉易出汗吗？ ",
            "options": [
                "活动汗出",
                "夜间出汗",
                "正常"
            ],
            "exclusiveOption": 2,
            "multiple": True
        },
        {
            "id": 4,
            "index": 3,
            "label": "您平时小便怎么样？",
            "options": [
                "偏黄",
                "清长（色清，量多）",
                "夜尿频多",
                "正常"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 5,
            "index": 4,
            "label": "您平时大便怎么样？",
            "options": [
                "偏干",
                "偏黏",
                "偏稀(或大便溏)",
                "正常"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 6,
            "index": 2,
            "label": "您平时胃口怎么样？",
            "options": [
                "不好",
                "正常"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 7,
            "index": 3,
            "label": "您平时容易口渴或口干吗？",
            "options": [
                "是",
                "否"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 8,
            "index": 5,
            "label": "您平时觉得口中有异样的味道吗？",
            "options": [
                "甜",
                "苦",
                "黏",
                "口淡",
                "正常"
            ],
            "exclusiveOption": 4,
            "multiple": True
        },
        {
            "id": 9,
            "index": 4,
            "label": "您平时容易心烦、情绪低落吗？",
            "options": [
                "是",
                "否"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 10,
            "index": 5,
            "label": "您容易掉头发吗？",
            "options": [
                "是",
                "否"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 11,
            "index": 6,
            "label": "您平时容易失眠吗？",
            "options": [
                "是",
                "否"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 12,
            "index": 6,
            "label": "您平时身体有胀满不适吗？",
            "options": [
                "乳房胀",
                "食后腹胀",
                "胸胁胀满",
                "无"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 13,
            "index": 7,
            "label": "您自己感觉腰膝酸软、腿脚无力吗？",
            "options": [
                "是",
                "否"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },

    ]
}


questions_en = {
    "data": [
        {
            "id": 1,
            "index": 1,
            "label": "Are you easily fatigued?",
            "options": [
                "Yes",
                "No"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 2,
            "index": 1,
            "label": "Are you afraid of the cold, hear or do you feel feverishness in palms and soles? ",
            "options": [
                "Afraid of the cold",
                "Afraid of the heat",
                "Feverishness in palms and soles",
                "Normal"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 3,
            "index": 2,
            "label": "Do you easily sweat in normal times or at night?",
            "options": [
                "Sweat when exercising",
                "Sweat at night",
                "Normal"
            ],
            "exclusiveOption": 2,
            "multiple": True
        },
        {
            "id": 4,
            "index": 3,
            "label": "How about your urine ordinarily?",
            "options": [
                "Yellowish",
                "Clear and abundant",
                "Frequent urination at night",
                "Normal"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 5,
            "index": 4,
            "label": "How about your stool ordinarily?",
            "options": [
                "Dry",
                "Sticky",
                "Thin",
                "Normal"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 6,
            "index": 2,
            "label": "How about your appetite ordinarily?",
            "options": [
                "Bad",
                "Normal"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 7,
            "index": 3,
            "label": "Do you often feel thirsty or dry?",
            "options": [
                "Yes",
                "No"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 8,
            "index": 5,
            "label": "Do you feel strange taste in mouth ordinarily?",
            "options": [
                "Sweet",
                "Bitter",
                "Sticky",
                "Tastelessness",
                "Normal"
            ],
            "exclusiveOption": 4,
            "multiple": True
        },
        {
            "id": 9,
            "index": 4,
            "label": "Are you easily upset and depressed ordinarily?",
            "options": [
                "Yes",
                "No"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 10,
            "index": 5,
            "label": "Is your hair dry or do you often suffer from hair loss?",
            "options": [
                "Yes",
                "No"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 11,
            "index": 6,
            "label": "Do you often suffer from insomnia ordinarily? ",
            "options": [
                "Yes",
                "No"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 12,
            "index": 6,
            "label": "Do you have physical discomfort of fullness ordinarily?",
            "options": [
                "Breast swelling",
                "Distention after eating",
                "Fullness chest and hypochondrium",
                "No"
            ],
            "exclusiveOption": 3,
            "multiple": True
        },
        {
            "id": 13,
            "index": 7,
            "label": "Do you often suffer from soreness and weakness of waist and knees，or weakness of the legs and feet？",
            "options": [
                "Yes",
                "No"
            ],
            "exclusiveOption": 1,
            "multiple": False
        }
    ]
}

additional_questions = {
    "female": [
        {
            "id": 14,
            "index": 1,
            "label": "您来月经前乳房胀满吗？",
            "options": [
                "是",
                "否"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 15,
            "index": 2,
            "label": "您的月经量如何？",
            "options": [
                "过少",
                "较少",
                "较多",
                "过多"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 16,
            "index": 3,
            "label": "您的月经颜色如何？",
            "options": [
                "颜色淡",
                "颜色鲜红",
                "经血中有血块"
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 17,
            "index": 4,
            "label": "您的月经颜色如何？",
            "options": [
                "月经淋漓不尽",
                "来月经时腰酸腰痛",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
    ]
}


parser = reqparse.RequestParser()


@api16_bp.route('/api16/questions', methods=['GET'])
@agency_required()
def question_list():
    gender = request.args.get('gender')
    if request.args.get('lang') == 'en':
        return jsonify(questions_en['data'])
    elif int(gender) == 2:
        return jsonify(questions_female['data'])
    else:
        return jsonify(questions['data'])


@api16_bp.route('/api16/additional_questions', methods=['GET'])
@agency_required()
def additional_question_list():
    gender = request.args.get('gender')
    return jsonify(additional_questions[gender or 'female'])


@api16_bp.route('/api16/question', methods=['POST'])
@agency_required()
def question():
    parser.add_argument('answers', type=lambda x: x, action='append', required=True, help='question answers',
                        location=('json',))
    args = parser.parse_args()
    answer = json.dumps(args['answers'])
    question_result = QuestionResult(
        owner=local_user if local_user else None,
        agency=local_agency,
        time=datetime.utcnow(),
        question_version_id=1,
        answer=answer
    )
    db.session.add(question_result)
    db.session.commit()
    return jsonify(marshal(question_result, question_fields))