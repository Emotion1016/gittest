from flask import jsonify
from flask_restful import fields, marshal

from ExaminationModalApi import api16_bp
from ExaminationModalApi.jwt_login import end_user_required, local_user, local_agency, local_agency_type
from ExaminationModalApi.model.daily_report import DailyReport
from ExaminationModalApi.model.report import simple_report_fields, Report
from ExaminationModalApi.views.error_handlers import ErrorCode, my_abort

event_report_fields = {
    'best': fields.Nested(simple_report_fields),
    'first': fields.Nested(simple_report_fields),
    'latest': fields.Nested(simple_report_fields),
    'worst': fields.Nested(simple_report_fields),
}


@api16_bp.route('/api16/statistics/events', methods=['GET'])
@end_user_required()
def health_event():
    query = None
    if local_agency_type == 'C':
        query = Report.query.filter(
            Report.agency_id == local_agency.id
        )
    elif local_agency_type == 'A' and local_user:
        query = Report.query.filter(
            Report.agency_id == local_agency.id,
            Report.owner_id == local_user.id
        )
    else:
        my_abort(error=ErrorCode.user_not_exist)
    data = {
        'first': query.order_by(Report.time).first(),
        'latest': query.order_by(Report.time.desc()).first(),
        'best': query.order_by(
            Report.health_score.desc()
        ).order_by(Report.time.desc()).first(),
        'worst': query.order_by(
            Report.health_score
        ).order_by(Report.time.desc()).first(),
    }
    return jsonify(marshal(data, event_report_fields))
