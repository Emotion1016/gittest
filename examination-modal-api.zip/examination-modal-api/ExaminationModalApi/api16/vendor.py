# -*- encoding: utf-8 -*-
from flask_restful import Resource, abort, reqparse, marshal_with
from flask import jsonify
from ExaminationModalApi.model.vendor import Vendor, vendor_field
from ExaminationModalApi import api16, api16_bp

from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode


class VendorResource(Resource):
    @marshal_with(vendor_field)
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('vendor_code', help='vendor code', required=True)
        args = parser.parse_args()
        vendor_code = args.get('vendor_code')
        if vendor_code:
            vendor = Vendor.query.filter(Vendor.code == vendor_code, Vendor.type != '').first()
            if vendor:
                if vendor.del_flag == 1:
                    my_abort(error=ErrorCode.vendor_not_exist)
                else:
                    return vendor
            else:
                my_abort(error=ErrorCode.vendor_not_exist)
        else:
            my_abort(error=ErrorCode.vendor_not_exist)


api16.add_resource(VendorResource, '/api16/vendor')


import time
@api16_bp.route('/api16/test')
def test():
    time.sleep(3)
    my_abort(error=ErrorCode.not_known)