# -*- encoding: utf-8 -*-
from ExaminationModalApi import api16_bp, app, db
from ExaminationModalApi.model.sign_name import SignName, basic_sign_name_fields
from ExaminationModalApi.api16.photo import detect_photo_errors, save_to_oss
from ExaminationModalApi.jwt_login import login_user_required, local_user, local_agency

from flask_restful import marshal
from datetime import datetime
from uuid import uuid4
from flask import jsonify


@api16_bp.route('/api16/user/upload_sign_name', methods=['POST'])
@login_user_required()
@detect_photo_errors
def upload_sign_name(photo):
    content = photo.read(-1)
    content_type = 'image/%s' % (photo.filename.rsplit('.', 1)[1].lower(), )

    time_str = datetime.now().strftime('%Y%m%d-%H%M%S')
    file_id = uuid4()
    if local_user:
        name = '%s/%s/%s/%s-%s' % (local_agency.login_name, local_user.cellphone or local_user.id, 'sign_name', time_str, file_id)
    else:
        name = '%s/%s/%s/%s' % (local_agency.login_name, 'sign_name', time_str, file_id)

    oss_id, _ = app.bucket.upload_content(
        content, content_type,
        name,
    )
    sign_name = SignName(
        oss_id=oss_id,
        agency=local_agency,
        user=local_user or None,
    )
    db.session.add(sign_name)
    db.session.commit()
    return jsonify(marshal(sign_name, basic_sign_name_fields))


