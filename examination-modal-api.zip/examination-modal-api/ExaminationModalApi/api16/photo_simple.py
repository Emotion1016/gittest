import pprint
from datetime import datetime
from functools import wraps
from uuid import uuid4

from flask import request, jsonify
from .. import api16_bp
from ..jwt_login import local_user, local_agency, agency_required

from ExaminationModalApi.api16.photo import PhotoType, save_to_oss, analyze, save_analyze_result, detect_photo_errors


@detect_photo_errors
def handle_form_photo(photo, photo_type: PhotoType):
    content = photo.read(-1)
    content_type = 'image/%s' % (photo.filename.rsplit('.', 1)[1].lower(), )

    time_str = datetime.now().strftime('%Y%m%d-%H%M%S')
    file_id = uuid4()

    if local_user:
        title = 'a-%s/%s/%s/%s-%s' % (local_agency.login_name, local_user.cellphone or local_user.id, photo_type.name, time_str, file_id)
    else:
        title = 'a-%s/%s/%s-%s' % (local_agency.login_name, photo_type.name, time_str, file_id)
    oss_id = save_to_oss(
        content,
        content_type,
        title,
        photo_type
    )

    ans = analyze(content, photo_type)
    result = save_analyze_result(ans, local_user.id if local_user else None, local_agency.id if local_agency else None, oss_id, photo_type)

    return jsonify(ans)


@api16_bp.route('/api16/photos/face_simple', methods=['POST'])
@agency_required()
def face_simple_diagnosis():
    return handle_form_photo(PhotoType.face)


@api16_bp.route('/api16/photos/tongue_simple', methods=['POST'])
@agency_required()
def tongue_simple_diagnosis():
    return handle_form_photo(PhotoType.tongue)

