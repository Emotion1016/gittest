# -*- encoding: utf-8 -*-
from flask import request, jsonify

from ExaminationModalApi import cache
from ExaminationModalApi import api16_bp
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode
from ExaminationModalApi.jwt_login import agency_required, local_agency

introduce_file = {
    '相宜本草': 'xybc_introduce.txt',
    '祉云': '祉云介绍.txt',
    '上海伍月石榴生物科技有限公司': '上海伍月石榴生物科技有限公司.txt',
    '': '',
}


@api16_bp.route('/api16/notice/introduce')
@agency_required()
def introduce():
    name = local_agency.custom.name
    file_path = introduce_file.get(name, '祉云介绍.txt')
    if not file_path:
        my_abort(error=ErrorCode.not_known)
    with open('ExaminationModalApi/static/' + file_path) as f:
        content = f.read()

    return jsonify({'content': content})


@api16_bp.route('/api16/notice/vendor_code')
def notice_vendor_code():
    content = '为保障您的权利，我们为您配备了一个厂家码，您可在设备包装内找到厂家码，请合理保管此号码。'
    return jsonify({'content': content})


@api16_bp.route('/api16/notice/no_vendor_code')
def notice_no_vendor_code():
    title = '我没有厂家码'
    content = '<p><span style="color: rgb(0, 0, 0);">尊敬的用户：</span></p><p><span style="color: rgb(0, 0, 0);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;为了更好的服务于用户，本次系统升级优化后为每位用户配备了厂家码，厂家码仅对您的账号具有保护意义，不影响老用户的正常登录与使用。</span></p><p><span style="color: rgb(0, 0, 0);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在2018年3月1日-2018年11月15日期间购买本司设备或使用V1.5及以前版本的机构用户，如果机构下的个人用户检测前需登录注册的，您账号配备的厂家码为：<span style="color:#FF0000;">ajigou</span>；如果机构下的个人用户检测前无需登录注册的，您账号配备的厂家码为：<span style="color:#FF0000;">bjigou</span>。在此期间购买本司设备的个人用户，您账号配备的厂家码为：<span style="color:#FF0000;">geren</span>。</span></p><p><span style="color: rgb(0, 0, 0);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;如果此期间购买设备的用户正在使用忘记密码，即可输入以上厂家码。</span></p><p><span style="color: rgb(0, 0, 0);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在2018年11月15日之后购入设备或使用V1.6及以后版本的机构用户，厂家码可在包装内的单页或说明书内找到厂家码。</span></p><p><span style="color: rgb(0, 0, 0);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;感谢您的支持！祝您身体健康！</span></p><p><span style="color: rgb(0, 0, 0);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;如有问题，请联系相关销售人员。</span></p><p><br/></p>'
    bottom = '如有问题，请联系相关销售人员'

    return jsonify({'title': title, 'content': content, 'bottom': bottom})


@api16_bp.route('/api16/notice/knowledge_basis')
# @agency_required()
def knowledge_basis():
    title = '知识库依据'
    content = [
        '[1]李灿东,吴承玉.中医诊断学[M].北京:中国中医药出版社,2018.',
        '[2]万学红,卢雪峰.诊断学[M].北京:人民卫生出版社,2018.',
        '[3]周仲瑛.中医内科学[M].北京:中国中医药出版社,2017.',
        '[4]葛均波,徐永健,王辰.内科学[M].北京:人民卫生出版社,2018.',
        '[5]谢梦洲,朱天民.中医药膳学[M].北京:中国中医药出版社,2016.',
        '[6]李其中.中医体质养生指南[M].上海:复旦大学出版社,2013.',
        '[7]匡调元.辨质论治通识读本——中国式个性化诊疗[M].北京:中国中医药出版社,2016.'
    ]
    bottom = '图像数据库、算法研究来源于国家级、市级等10项课题资助'

    return jsonify({'title': title, 'content': content, 'bottom': bottom})


@api16_bp.route('/api16/notice/health_status_explain')
# @agency_required()
def health_status_explain():
    title = '健康状态辨识总提纲解释说明'
    content = [
        '中医在“未病先防，既病防变，瘥后防复”方面有着独特价值和先进性。中医学在人体健康或疾病本质状态的认识上，早已形成了较为完整的系统认'
        '识论和方法学。它是从整体的状态把握人体健康或疾病的本质，从状态上调理与治疗。',
        '舌、面诊是中医诊病辨证的重要方法。《灵枢》云:“十二经脉，三百六十五络，其血气皆上于面而走空窍。”《辨舌指南•绪言》云：“舌为心之外'
        '候，苔乃胃之明征，察舌可占正之盛衰，验苔以识邪之出入。”说明通过观察舌、面诊的外在征象可以了解人体的健康状态和病情变化。',
        '本系统通过采集您的面象、舌象，结合10余个问题，实时监测您的身体健康状态，并给出健康报告和个性化的起居养生、饮食药膳、穴位按压、中'
        '医功法、音乐养生等健康保健方案。'
               ]
    bottom = None

    return jsonify({'title': title, 'content': content, 'bottom': bottom})


@api16_bp.route('/api16/notice/informed_consent')
@agency_required()
def informed_consent():
    if local_agency.custom.code == 'SHWYSLSWKJ':
        file_path = '伍月石榴知情同意书.txt'
    elif local_agency.custom.code == 'SXSZYYY':
        file_path = '陕西省中医医院知情同意书.txt'
    elif local_agency.custom.code == 'SHBAZE':
        file_path = '拜姿知情同意书.txt'
    else:
        file_path = '知情同意书.txt'
    if not file_path:
        my_abort(error=ErrorCode.not_known)
    with open('ExaminationModalApi/static/' + file_path) as f:
        content = f.read()

    return jsonify({'content': content})
