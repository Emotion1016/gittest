import re
import hashlib
from flask import current_app, jsonify
from flask_restful import Resource, reqparse, marshal_with, fields, marshal
from sqlalchemy import desc, func
from datetime import datetime
import time

from ExaminationModalApi import bcrypt, db, DEFAULT_PAGINATION_ITEM_NUM, api16, api16_bp
from ExaminationModalApi.jwt_login import agency_required, local_agency
from ExaminationModalApi.model.agency import Agency, simple_agency_fields
from ExaminationModalApi.model.admin import Admin
from ExaminationModalApi.model.agency_info import AgencyInfo
from ExaminationModalApi.model.user import to_gender
from ExaminationModalApi.model.util import add_photos_url
from ExaminationModalApi.api16.user import to_vendor

from ExaminationModalApi.views.error_handlers import ErrorCode, my_abort


def get_birthday_from_age(age):
    birthday = None
    if age:
        y = datetime.now().year
        m = datetime.now().month
        d = datetime.now().day
        birthday = '%s-%02d-%02d' % (y - int(age), m, d)
    return birthday


def create_agency_info(agency_info):
    cellphone = agency_info['cellphone']
    age = agency_info.get('age')
    birthday = get_birthday_from_age(age)
    if AgencyInfo.query.filter_by(cellphone=cellphone).first():
        return 1, ErrorCode.cellphone_registered
    a = AgencyInfo(
        cellphone=cellphone,
        name=agency_info.get('name'),
        birthday=birthday,
        gender=agency_info.get('gender'),
        height=agency_info.get('height'),
        weight=agency_info.get('weight'),
        stage=agency_info.get('stage')
    )
    return 0, a


@api16_bp.route('/api16/update_agency_info', methods=['POST'])
@agency_required()
def update_agency_info():
    parser = reqparse.RequestParser()
    parser.add_argument('cellphone', type=str, help='cellphone')
    parser.add_argument('name', type=str, help='name of the agency C')
    parser.add_argument('height', type=int, help='height')
    parser.add_argument('weight', type=int, help='weight')
    parser.add_argument('age', type=int, help='age')
    parser.add_argument('gender', type=to_gender, help='gender, 1-male, 2-female', required=True)
    parser.add_argument('stage', type=str, help='stage')
    args = parser.parse_args()
    args['birthday'] = get_birthday_from_age(args.get('age'))
    args.pop('age', None)

    if local_agency.type == 'C':
        agency_info = local_agency.agency_info
        for k, v in args.items():
            if v is not None:
                setattr(agency_info, k, v)
        db.session.commit()
    return jsonify(marshal(local_agency, simple_agency_fields))


class AgencyList(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('name', type=str, help='name of the agency')
    parser.add_argument('loginName', type=str, help='login name of the agency', required=True)
    parser.add_argument('password', type=str, help='password of the agency', required=True)
    parser.add_argument('key', type=str, help='key of the agency')
    parser.add_argument('vendor_code', dest='vendor', type=to_vendor, help='vendor identification code', required=True)
    parser.add_argument('agency_info', type=dict, help='user info', required=False)
    parser.add_argument('channel', type=str, help='channel from')

    @marshal_with(simple_agency_fields)
    def post(self):
        args = self.parser.parse_args()
        name = args['name'] or args['loginName']
        # 11位手机号不可以注册
        if re.match(r'^1[345789][0-9]{9}$', name):
            my_abort(error=ErrorCode.agency_exists)
        password = bcrypt.generate_password_hash(args['password'], 10)
        vendor = args.get('vendor')

        if not vendor or vendor.code in ['ajigou', 'bjigou', 'geren']:
            my_abort(error=ErrorCode.vendor_not_exist)

        if vendor.del_flag:
            my_abort(error=ErrorCode.vendor_not_exist)

        if Agency.query.filter(Agency.login_name == args['loginName']).first():
            my_abort(error=ErrorCode.agency_exists)

        if Admin.query.filter(Admin.adminName == args['loginName']).first():
            my_abort(error=ErrorCode.agency_exists)

        agency_info = None
        if vendor.type == 'C':
            e, agency_info = create_agency_info(args['agency_info'])
            if e:
                my_abort(error=agency_info)
            else:
                db.session.add(agency_info)

        agency = Agency(
            # key=args['key'] or args['loginName'],
            name=name,
            login_name=args['loginName'],
            channel=args.get('channel'),
            password=password.decode('utf-8'),
            type=vendor.type,
            anonymous_report=False if vendor.type == 'A' else True,
            vendor=vendor,
            agency_info=agency_info,
            custom_id=vendor.custom_id,
            roleId=None
        )

        md5_password = hashlib.md5(args['password'].encode('utf-8')).hexdigest()
        admin = Admin(adminName=args['loginName'],
                      password=md5_password,
                      roleId=None,
                      realName=name,
                      deleteFlag=vendor.custom.admin_manage_flag == 0,
                      createTime=int(time.time())
                      )

        try:
            db.session.add(agency)
            db.session.add(admin)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            current_app.logger.error('db commit error: %s' % e)
            my_abort(error=ErrorCode.not_known)
        return agency


api16.add_resource(AgencyList, '/api16/agencies')


class AgencyForgetPassword(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('name', type=str, help='name of the agency', required=True)
    parser.add_argument('new_password', type=str, help='password of the agency', required=True)
    parser.add_argument('vendor_code', dest='vendor', type=to_vendor, help='vendor identification code', required=True)

    @marshal_with(simple_agency_fields)
    def post(self):
        args = self.parser.parse_args()
        if args.get('vendor'):
            agency = Agency.query.filter(Agency.login_name == args['name']).first()
            if agency:
                if agency.vendor != args.get('vendor'):
                    my_abort(error=ErrorCode.vendor_not_match)
                agency.password = bcrypt.generate_password_hash(args['new_password'], 10)
                db.session.commit()
                return agency
            else:
                my_abort(error=ErrorCode.agency_not_exists)

        my_abort(error=ErrorCode.vendor_not_exist)


api16.add_resource(AgencyForgetPassword, '/api16/agency/forget_password')


class AgencyRestPassword(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('name', type=str, help='name of the agency', required=True)
    parser.add_argument('new_password', type=str, help='new password of the agency', required=True)
    parser.add_argument('old_password', type=str, help='old password of the agency', required=True)

    @marshal_with(simple_agency_fields)
    def post(self):
        args = self.parser.parse_args()
        agency = Agency.query.filter(Agency.login_name == args['name']).first()
        if agency:
            if not bcrypt.check_password_hash(agency.password, args['old_password']):
                my_abort(error=ErrorCode.old_password_error)
            agency.password = bcrypt.generate_password_hash(args['new_password'], 10)
            db.session.commit()
            return agency
        else:
            my_abort(error=ErrorCode.agency_not_exists)


api16.add_resource(AgencyRestPassword, '/api16/agency/reset_password')


agency_user_fields = {
    'id': fields.Integer,
    'cellphone': fields.String,
    'last_report_time': fields.String,
    'face_photo_url': fields.String,
    'tongue_photo_url': fields.String
}

agency_user_list = {
    'end': fields.Boolean,
    'data': fields.List(fields.Nested(agency_user_fields))
}


def agency_user_from_report(r, id):
    u = r.owner
    # r = dr.report
    add_photos_url(r)
    return {
        'id': id,
        'cellphone': u.cellphone,
        'last_report_time': r.display_time,
        'face_photo_url': r.face_photo_url,
        'tongue_photo_url': r.tongue_photo_url,
    }


@api16_bp.route('/api16/agency/check_password', methods=['POST'])
@agency_required()
def check_password():
    parser = reqparse.RequestParser()
    parser.add_argument('password', help='password for agency', required=True)
    args = parser.parse_args()
    if bcrypt.check_password_hash(local_agency.password, args.get('password')):
        return jsonify({'status': 'success'})
    else:
        my_abort(error=ErrorCode.password_check_error)