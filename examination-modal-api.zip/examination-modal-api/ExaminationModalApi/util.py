import sys
import requests
from datetime import datetime, date, timedelta
from urllib.parse import urlunparse, urlencode

from flask import url_for, current_app, request
from pytz import utc
import cv2
import numpy as np


def to_timestamp(dt: datetime):
    if not dt.tzinfo:
        dt = dt.replace(tzinfo=utc)
    return int((dt - datetime(1970, 1, 1, tzinfo=utc)).total_seconds())


def https_for(endpoint, **options):
    options['_scheme'] = 'https'
    options['_external'] = True
    return url_for(endpoint, **options)


def front_page_url_handler(error: Exception, endpoint: str, values: dict):
    url = None
    if values.get('_frontpage'):
        query = {k: v for k, v in values.items() if not k.startswith('_')}
        url = urlunparse((
            values.get('_scheme', 'https'),
            current_app.config['SERVER_NAMES'].get(request.blueprint, current_app.config['SERVER_NAME']),
            '/',
            '',
            urlencode(query, doseq=True),
            endpoint if endpoint.startswith('/') else ('/' + endpoint),
        ))

    if url is None:
        # External lookup did not have a URL.
        # Re-raise the BuildError, in context of original traceback.
        exc_type, exc_value, tb = sys.exc_info()
        if exc_value is error:
            raise exc_type(exc_value).with_traceback(tb)
        else:
            raise error
    return url


def to_date(s):
    try:
        y, m, d = map(lambda x: int(x, 10), s.split('-'))
        assert y >= 1900
        return date(y, m, d)
    except Exception:
        raise ValueError('birthday must be in format yyyy-mm-dd')


def get_today_begin_utc_time():
    now = datetime.now()
    start = datetime.strptime('%s-%s-%s' % (now.year, now.month, now.day), '%Y-%m-%d')
    start_utc = start - timedelta(hours=8)
    return start_utc


def get_today_end_utc_time():
    now = datetime.now()
    start = datetime.strptime('%s-%s-%s' % (now.year, now.month, now.day), '%Y-%m-%d')
    start_utc = start + timedelta(hours=16)
    return start_utc


def get_city_from_ip(ip):
    try:
        url = 'http://ip.taobao.com/service/getIpInfo.php?ip=%s' % ip
        req = requests.get(url, timeout=1)
        return req.json()['data']['city']
    except Exception as e:
        current_app.logger.debug('get city info fail: %s' % e)
        return ''
