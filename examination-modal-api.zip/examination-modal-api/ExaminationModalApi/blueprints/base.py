from flask import Blueprint


class ExtendedBlueprint(Blueprint):
    _register_done_callback = None

    def register(self, app, options, first_registration=False):
        super(ExtendedBlueprint, self).register(app, options, first_registration)

        if self._register_done_callback:
            self._register_done_callback(app, options, first_registration)

    def register_done_callback(self):
        def _decorator(f):
            self._register_done_callback = f
            return f
        return _decorator
