import pprint

from flask import request, jsonify, abort, Blueprint, current_app
from pydiagnosis import face, tongue

from ExaminationModalApi.api.photo import detect_photo_errors
from ExaminationModalApi.examination import run

test_tool_blueprint = Blueprint('test_tool', __name__)


@test_tool_blueprint.route('/api/test-tool/examinations', methods=['POST'])
def test_examinations():
    current_app.logger.debug('input: %s', pprint.pformat(request.json))
    result = run(request.json, _type=1)
    current_app.logger.debug('examination result: %s', pprint.pformat(result))
    return jsonify(result)


@test_tool_blueprint.route('/api/test-tool/examinations_physical', methods=['POST'])
def test_examinations_physical():
    ans = request.json
    if int(ans['answers'][-1]['id']) == 28:
        gender = ans['answers'].pop()
    else:
        gender = None

    new_answer = []
    if gender and gender.get('answer') == 'A': # 男
        ids = [24, 26]
    else:
        ids = [25, 27]
    for i in ans['answers']:
        if int(i['id']) not in ids:
            new_answer.append(i)
    ans['answers'] = new_answer
    result = run(ans, _type=2)

    return jsonify(result)


@test_tool_blueprint.route('/api/test-tool/photo/<photo_type>', methods=['POST'])
@detect_photo_errors
def test_photo(photo, photo_type):
    if photo_type == 'face':
        result = face(photo.read(-1)).to_dict()
    elif photo_type == 'tongue':
        result = tongue(photo.read(-1)).to_dict()
    else:
        abort(400)
        return ''
    current_app.logger.debug('%s analyze result: %s', photo_type, pprint.pformat(result))
    return jsonify(result)
