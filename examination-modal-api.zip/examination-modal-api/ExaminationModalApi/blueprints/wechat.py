#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pprint
from datetime import datetime

from flask import request, jsonify, redirect, abort, current_app
from sqlalchemy import desc
from wechatpy import WeChatOAuth, parse_message
from wechatpy.events import SubscribeScanEvent
from wechatpy.exceptions import InvalidSignatureException
from wechatpy.utils import check_signature

from ExaminationModalApi import jsapi, wechat_client, db
from ExaminationModalApi.blueprints.base import ExtendedBlueprint
from ExaminationModalApi.jwt_login import load_wechat_user, create_wechat_jwt_token
from ExaminationModalApi.model.qrcode import QRCode
from ExaminationModalApi.model.user import User
from ExaminationModalApi.model.util import Gender
from ExaminationModalApi.model.wechat_account import WeChatAccount
from ExaminationModalApi.util import https_for

WECHAT_EVENT_HANDLERS = {}


def wechat_event_handler(event):
    def _decorator(f):
        assert event not in WECHAT_EVENT_HANDLERS, 'event %s has been registered to %r' % (
        event, WECHAT_EVENT_HANDLERS[event])
        WECHAT_EVENT_HANDLERS[event] = f
        return f

    return _decorator


wechat_blueprint = ExtendedBlueprint('wechat', __name__)


@wechat_event_handler(SubscribeScanEvent.event)
def handle_subscribe_scan(event: SubscribeScanEvent):
    qrcode = QRCode.query.filter(QRCode.scene_id == event.scene_id).order_by(desc(QRCode.updated_at)).first()
    agency = qrcode and qrcode.agency
    channel = qrcode and qrcode.channel

    try:
        user = wechat_client.user.get(event.source)
        current_app.logger.debug('user %s scanned qrcode of agency %s channel %s', user, agency, channel)
    except Exception:
        current_app.logger.exception('cannot retrieve info of user %s', event.source)
        return ''

    create_wechat_user_in_db(user, agency=agency, channel=channel)

    return ''


def get_next_arg():
    n = request.args.get('next', '')
    if n not in ['', 'history', 'me', ]:
        n = ''
    return n


def get_wechat_oauth_client():
    wechat_oauth = WeChatOAuth(
        current_app.config['APPID'],
        current_app.config['SECRET'],
        # current_app.config['WECHAT_SIGNIN_REDIRECT_URL'] + '?next=' + get_next_arg(),
        https_for('wechat.token', next=get_next_arg()),
        scope='snsapi_userinfo',
        state=current_app.config['WECHAT_OAUTH_STATE']
    )
    current_app.logger.debug('final page: %s', https_for(get_next_arg(), _frontpage=True))
    return wechat_oauth


@wechat_blueprint.route('/api/wechat/check', methods=['GET', ])
def check():
    signature = request.args.get('signature')
    timestamp = request.args.get('timestamp')
    echostr = request.args.get('echostr')
    nonce = request.args.get('nonce')

    token = current_app.config['TOKEN']
    try:
        check_signature(token, signature, timestamp, nonce)
        current_app.logger.info('wechat signature check passed')
        return echostr
    except InvalidSignatureException:
        current_app.logger.warn('wechat signature check failed')
        return 'bad signature'


@wechat_blueprint.route('/api/wechat/check', methods=['POST', ])
def wechat_msg():
    token = current_app.config['TOKEN']

    signature = request.args.get('signature')
    timestamp = request.args.get('timestamp')
    nonce = request.args.get('nonce')

    try:
        check_signature(token, signature, timestamp, nonce)
    except InvalidSignatureException:
        current_app.logger.warn('wechat signature check failed')
        abort(403)

    try:
        msg = parse_message(request.data)
    except Exception:
        current_app.logger.exception('cannot parse message from data %r', request.data[:100])
        return ''

    cb = WECHAT_EVENT_HANDLERS.get(msg.event, None)
    if callable(cb):
        return cb(msg)
    else:
        return ''


@wechat_blueprint.route('/api/wechat/signature')
def signature():
    url = request.args.get('url')
    noncestr = request.args.get('noncestr')
    timestamp = request.args.get('timestamp')
    try:
        ticket = jsapi.get_jsapi_ticket()
        return jsonify({'signature': jsapi.get_jsapi_signature(noncestr, ticket, timestamp, url)})
    except Exception as ex:
        return jsonify({'error': str(ex)})


@wechat_blueprint.route('/api/wechat_sign_in', endpoint='wechat_sign_in')
def sign_in():
    wechat_oauth = get_wechat_oauth_client()
    return redirect(wechat_oauth.authorize_url)


@wechat_blueprint.route('/api/token')
def token():
    current_app.logger.debug('in wechat oauth token: %r', request.args)

    state, code = request.args.get('state', None), request.args.get('code', None)
    if not state or not code or state != current_app.config['WECHAT_OAUTH_STATE']:
        current_app.logger.error('invalid state (%s) or code (%s)', state, code)
        abort(400)
    wechat_oauth = get_wechat_oauth_client()
    try:
        wechat_oauth.fetch_access_token(code)
    except:
        current_app.logger.exception('cannot fetch wechat access token')
        abort(400)

    try:
        user = wechat_oauth.get_user_info()
    except:
        current_app.logger.exception('cannot fetch wechat user info')
        abort(400)
        return None

    current_app.logger.debug('user login: %r', user)
    create_wechat_user_in_db(user)

    jwt_token = create_wechat_jwt_token(user['openid'], user['nickname'])

    # response = redirect(current_app.config['WECHAT_AUTHORIZED_REDIRECT_URL'] + '#/' + get_next_arg())
    response = redirect(
        https_for(get_next_arg(), _frontpage=True),
    )
    response.set_cookie(
        'jwt',
        jwt_token,
        secure=True,
        httponly=True,
    )
    return response


def create_wechat_user_in_db(user, agency=None, channel=None):
    genders = {
        1: Gender.male,
        2: Gender.female,
    }
    u = load_wechat_user(user.get('openid'))
    if not u:
        current_app.logger.debug(
            'create user from wehcat account %s, agency %s, channel %s',
            user, agency, channel,
        )
        u = User(
            name=user['nickname'],
            avatar=user['headimgurl'],
            gender=genders.get(user['sex'], None),
            create_time=datetime.utcnow(),
            agency=agency,
            channel=channel,
        )
        a = WeChatAccount(
            openid=user['openid'],
            unionid=user.get('unionid', None),
            user=u,
        )
        db.session.add(u)
        db.session.add(a)
        db.session.commit()
    return u


@wechat_blueprint.register_done_callback()
def register_wechat_menu(app, options, first_registration):
    with app.app_context():
        menu_data = {"button": [
            {"type": "view", "name": u"个人中心", "url": https_for('wechat.wechat_sign_in', next='me')},
            {"type": "view", "name": u"智能诊疗", "url": https_for('wechat.wechat_sign_in')},
            {"type": "view", "name": u"历史报告", "url": https_for('wechat.wechat_sign_in', next='history')}
        ]}
    app.logger.debug('WeChat menu of current application: %s', pprint.pformat(menu_data))

    if not app.config.get('WECHAT_REGISTER_MENU', True):
        app.logger.warn('WeChat menu not registered, may not reflect correct links!')
        return

    try:
        wechat_client.menu.create(menu_data)
    except:
        app.logger.exception('cannot set wechat menu, aborting')
        from sys import exit as sysexit
        sysexit(1)
