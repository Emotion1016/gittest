# -*- encoding: utf-8 -*-
from datetime import datetime, timedelta
import time

from flask import current_app
from flask_jwt import jwt_required
from flask_restful import Resource, reqparse, marshal_with, fields, marshal
from sqlalchemy import desc
from werkzeug.exceptions import abort

from ExaminationModalApi import openapi
from ExaminationModalApi.jwt_login import local_agency, is_agency
from ExaminationModalApi.model.report import Report, simple_report_fields, simple_user_fields, ScoreFormat
from ExaminationModalApi.model.symptom import symptom_fields
from ExaminationModalApi.model.user import User
from ExaminationModalApi.model.agency import Agency

openapi_one_report_fields = {
    'id': fields.Integer,
    'display_id': fields.String,
    'report_url': fields.String,
    # 'api_url': fields.String,
    'sn': fields.String,
    'health_score': ScoreFormat,
    'time': fields.String(attribute='format_time'),
    'symptoms': fields.List(fields.Nested(symptom_fields)),
    'health_status_index': fields.Integer,
    'health_status_text': fields.String,
    'face_photo_url': fields.String,
    'tongue_photo_url': fields.String,
    'owner': fields.Nested(simple_user_fields, allow_null=True),
}
shared_one_report_list_fields = {
    'has_prev': fields.Boolean(),
    'has_next': fields.Boolean(),
    'next_num': fields.Integer,
    'page': fields.Integer,
    'pages': fields.Integer,
    'items': fields.List(fields.Nested(openapi_one_report_fields)),
}


def str_to_time(s):
    d = datetime.strptime(s, '%Y-%m-%d %H:%M:%S')
    return d


class OpenReportOneList(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('start_time', type=str_to_time, help='start time, format: %Y-%m-%d %H:%M:%S')
    parser.add_argument('end_time', type=str_to_time, help='start time, format: %Y-%m-%d %H:%M:%S')
    parser.add_argument('reverse', type=int, help='reverse', default=0)
    parser.add_argument('page', type=int, help='page', default=1)
    parser.add_argument('per_page', type=int, help='per_page', default=10)
    parser.add_argument('phone', type=str, help="phone number", required=True)

    def list_reports(self):
        if not is_agency:
            current_app.logger.debug('current agency %s ' % local_agency)
            abort(403)
        elif local_agency:
            all_query = Report.query.filter(Report.custom == local_agency.custom)
            return all_query
        abort(403)

    def filter(self, query, start_time, end_time, phone):
        if start_time:
            query = query.filter(Report.time >= start_time - timedelta(hours=8))
        if end_time:
            query = query.filter(Report.time <= end_time - timedelta(hours=8))
        if not phone:
            abort(403)
        m_user = User.query.filter(User.cellphone == phone).first()
        user_id = m_user.id if m_user else -1
        query = query.filter(Report.owner_id == user_id)
        return query

    def order_column(self, reverse):
        return desc(Report.time) if reverse else Report.time

    @jwt_required()
    @marshal_with(shared_one_report_list_fields, )
    def get(self):
        args = self.parser.parse_args()
        per_page = args.get('per_page')
        start_time = args.get('start_time')
        end_time = args.get('end_time')
        reverse = args.get('reverse')
        page = args.get('page')
        phone = args.get('phone')

        query = self.list_reports()

        query = self.filter(query, start_time, end_time, phone)
        query = query.order_by(self.order_column(reverse=reverse))

        pagination = query.paginate(page, per_page=per_page)
        for report in pagination.items:
            report.face_photo_url = current_app.bucket \
                .get_thumb_url(report.face_result.photo.oss_id, current_app.config['OSS_THUMB_IMAGE_STYLE'],
                               lifetime=12 * 30 * 24 * 3600)
            report.tongue_photo_url = current_app.bucket \
                .get_thumb_url(report.tongue_result.photo.oss_id, current_app.config['OSS_THUMB_IMAGE_STYLE'],
                               lifetime=12 * 30 * 24 * 3600)

        return pagination


openapi.add_resource(OpenReportOneList, '/report')
