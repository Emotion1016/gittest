# -*- encoding: utf-8 -*-
from datetime import datetime, timedelta
import time

from flask import current_app
from flask_jwt import jwt_required
from flask_restful import Resource, reqparse, marshal_with, fields, marshal
from sqlalchemy import desc
from werkzeug.exceptions import abort

from ExaminationModalApi import openapi
from ExaminationModalApi.jwt_login import local_agency, is_agency
from ExaminationModalApi.model.report import Report, simple_report_fields, simple_user_fields, ScoreFormat
from ExaminationModalApi.model.symptom import symptom_fields
from ExaminationModalApi.model.vendor import Vendor
from ExaminationModalApi.model.agency import Agency


openapi_report_fields = {
    'id': fields.Integer,
    'display_id': fields.String,
    'report_url': fields.String,
    'api_url': fields.String,
    'sn': fields.String,
    'health_score': ScoreFormat,
    'time': fields.String(attribute='format_time'),
    'symptoms': fields.List(fields.Nested(symptom_fields)),
    'health_status_index': fields.Integer,
    'health_status_text': fields.String,
    'face_photo_url': fields.String,
    'tongue_photo_url': fields.String,
    'owner': fields.Nested(simple_user_fields, allow_null=True),
}
shared_report_list_fields = {
    'has_prev': fields.Boolean(),
    'has_next': fields.Boolean(),
    'next_num': fields.Integer,
    'page': fields.Integer,
    'pages': fields.Integer,
    'items': fields.List(fields.Nested(openapi_report_fields)),
}


def str_to_time(s):
    d = datetime.strptime(s, '%Y-%m-%d %H:%M:%S')
    return d


class OpenReportList(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('start_time', type=str_to_time, help='start time, format: %Y-%m-%d %H:%M:%S')
    parser.add_argument('end_time', type=str_to_time, help='start time, format: %Y-%m-%d %H:%M:%S')
    parser.add_argument('reverse', type=int, help='reverse', default=0)
    parser.add_argument('page', type=int, help='page', default=1)
    parser.add_argument('vendor_code', type=str, help='vendor code')
    parser.add_argument('pointer', type=int, help='Pointer of last list fetching')

    def list_reports(self, vendor):
        if vendor:
            return Report.query.join(Agency, Agency.id == Report.agency_id).filter(Agency.vendor == vendor)

        if not is_agency:
            current_app.logger.debug('current agency %s ' % local_agency)
            abort(403)
        elif local_agency:
            return local_agency.reports
        abort(403)

    def filter(self, query, start_time, end_time):
        if start_time:
            query = query.filter(Report.time >= start_time - timedelta(hours=8))
        if end_time:
            query = query.filter(Report.time <= end_time - timedelta(hours=8))
        return query

    def order_column(self, reverse):
        return desc(Report.id) if reverse else Report.id

    @jwt_required()
    @marshal_with(shared_report_list_fields,)
    def get(self):
        MAX_LENGTH = 100
        args = self.parser.parse_args()
        start_time = args.get('start_time')
        end_time = args.get('end_time')
        reverse = args.get('reverse')
        vendor_code = args.get('vendor_code')
        vendor = Vendor.query.filter(Vendor.code == vendor_code).first()
        page = args.get('page')

        query = self.list_reports(vendor)
        if args.get('pointer'):
            query = query.filter(Report.id > args.get('pointer'))
            query = query.order_by(self.order_column(reverse=False))
        else:
            query = self.filter(query, start_time, end_time)
            query = query.order_by(self.order_column(reverse=reverse))

        pagination = query.paginate(page, per_page=MAX_LENGTH)
        for report in pagination.items:
            report.face_photo_url = current_app.bucket\
                .get_thumb_url(report.face_result.photo.oss_id, current_app.config['OSS_THUMB_IMAGE_STYLE'],
                               lifetime=12 * 30 * 24 * 3600)
            report.tongue_photo_url = current_app.bucket\
                .get_thumb_url(report.tongue_result.photo.oss_id, current_app.config['OSS_THUMB_IMAGE_STYLE'],
                               lifetime=12 * 30 * 24 * 3600)

        return pagination


openapi.add_resource(OpenReportList, '/reports')