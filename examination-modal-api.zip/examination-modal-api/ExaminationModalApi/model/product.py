# -*- encoding: utf-8 -*-
from ExaminationModalApi import db, app
from flask_restful import fields
from sqlalchemy import text
from datetime import datetime


class SymptomDefine(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(10))


class ProductCategory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(100))

    custom_id = db.Column(db.Integer, db.ForeignKey('custom.id'))
    custom = db.relationship('Custom')

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'))
    agency = db.relationship('Agency')

    create_time = db.Column(db.DateTime, default=datetime.now)


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    image = db.Column(db.String(1000))
    description = db.Column(db.Text)
    price = db.Column(db.Float())

    product_category_id = db.Column(db.Integer, db.ForeignKey('product_category.id'))
    product_category = db.relationship('ProductCategory', backref=db.backref('products'))

    custom_id = db.Column(db.Integer, db.ForeignKey('custom.id'))
    custom = db.relationship('Custom')

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'))
    agency = db.relationship('Agency')

    create_time = db.Column(db.DateTime, default=datetime.now)

    @property
    def category(self):
        return self.product_category.category

    @property
    def full_url(self):
        if not self.image:
            return None
        if self.image.startswith('http'):
            return self.image
        else:
            return app.config['ZHIYUN_ADMIN_URL'] + self.image


class ProductCategorySymptom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_category_id = db.Column(db.Integer, db.ForeignKey('product_category.id'))
    product_category = db.relationship('ProductCategory')

    symptom_id = db.Column(db.Integer, db.ForeignKey('symptom_define.id'))
    symptom = db.relationship('SymptomDefine')

    index_id = db.Column(db.Integer)


class ProductSymptom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    product = db.relationship('Product')

    symptom_id = db.Column(db.Integer, db.ForeignKey('symptom_define.id'))
    symptom = db.relationship('SymptomDefine')

    # is_show = db.Column(db.Boolean, server_default=text('0'))


class ProductLocation(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    location_id = db.Column(db.Integer, db.ForeignKey('product_category_symptom.id'))
    location = db.relationship('ProductCategorySymptom')

    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    product = db.relationship('Product')


product_fields = {
    'name': fields.String,
    'image': fields.String(attribute='full_url'),
    'description': fields.String,
    'price': fields.Float,
    'category': fields.String
}