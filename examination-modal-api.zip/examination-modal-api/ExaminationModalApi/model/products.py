from sqlalchemy import func
from flask_restful import fields
from ExaminationModalApi import db, app

association_table = db.Table('customization_product_diagnose_relation',
                             db.Column('id', db.Integer, primary_key=True, index=True),
                             db.Column('product_id', db.Integer,
                                       db.ForeignKey('customization_product.id', ondelete='CASCADE',
                                                     onupdate='CASCADE'), index=True),
                             db.Column('diagnose_result_id', db.Integer,
                                       db.ForeignKey('service_diagnose_result.id', ondelete='CASCADE',
                                                     onupdate='CASCADE'), index=True)
                             )

association_table2 = db.Table('customization_category_agency_rel',
                              db.Column('id', db.Integer, primary_key=True, index=True),
                              db.Column('category_id', db.Integer,
                                        db.ForeignKey('customization_product_category.id', ondelete='CASCADE',
                                                      onupdate='CASCADE'), index=True),
                              db.Column('agency_id', db.Integer,
                                        db.ForeignKey('agency.id', ondelete='CASCADE',
                                                      onupdate='CASCADE'), index=True)
                              )


class CustomizationProductCategory(db.Model):
    __tablename__ = 'customization_product_category'

    id = db.Column(db.Integer, primary_key=True, index=True)
    name = db.Column(db.String(64))
    # 删除标记， 0 表示 上架， 1表示 下架， 2 表示删除
    is_delete = db.Column(db.Integer, default=0)
    creator = db.Column(db.String(64))
    modifier = db.Column(db.String(64))
    created = db.Column(db.DateTime, server_default=func.now())
    updated = db.Column(db.DateTime, server_default=func.now(), onupdate=func.now())
    agencies = db.relationship("Agency", secondary=association_table2)


class CustomizationProduct(db.Model):
    __tablename__ = 'customization_product'

    id = db.Column(db.Integer, primary_key=True, index=True)
    name = db.Column(db.String(64))
    img_url = db.Column(db.String(255))
    price = db.Column(db.Float(10))
    place = db.Column(db.String(64))
    desc = db.Column(db.String(255))
    brand = db.Column(db.String(64))
    manufacturer = db.Column(db.String(64))
    certificate = db.Column(db.String(128))
    sold_out_explain = db.Column(db.String(255))
    is_delete = db.Column(db.Boolean, default=False)
    creator = db.Column(db.String(64))
    modifier = db.Column(db.String(64))
    created = db.Column(db.DateTime, server_default=func.now())
    updated = db.Column(db.DateTime, server_default=func.now(), onupdate=func.now())
    category_id = db.Column(db.ForeignKey('customization_product_category.id', ondelete='CASCADE', onupdate='CASCADE'),
                            index=True)
    categorys = db.relationship('CustomizationProductCategory', backref=db.backref('products'))
    symptoms = db.relationship("ServiceDiagnoseResult", secondary=association_table, back_populates="products")

    @property
    def full_url(self):
        if not self.img_url:
            return None
        if self.img_url.startswith('http'):
            return self.img_url
        else:
            return app.config['CONTENT_ASSET_URL_PREFIX'] + self.img_url


class CustomizationProductPhoto(db.Model):
    __tablename__ = 'customization_product_photo'

    id = db.Column(db.Integer, primary_key=True, index=True)
    oss_id = db.Column(db.String(255))
    product_id = db.Column(db.ForeignKey('customization_product.id', ondelete='CASCADE', onupdate='CASCADE'),
                           index=True)
    product = db.relationship('CustomizationProduct', backref=db.backref('photos'))

    is_delete = db.Column(db.Boolean, default=False)

    @property
    def img_url(self):
        if not self.oss_id:
            return None
        if self.oss_id.startswith('http'):
            return self.oss_id
        else:
            return app.config['CONTENT_ASSET_URL_PREFIX'] + self.oss_id


class ServiceDiagnoseResult(db.Model):
    __tablename__ = 'service_diagnose_result'

    id = db.Column(db.Integer, primary_key=True, index=True)
    name = db.Column(db.String(64))
    sign = db.Column(db.Integer)  # 1健康状态 2体质辨识
    is_delete = db.Column(db.Boolean, default=False)
    creator = db.Column(db.String(64))
    modifier = db.Column(db.String(64))
    created = db.Column(db.DateTime, server_default=func.now())
    updated = db.Column(db.DateTime, server_default=func.now(), onupdate=func.now())
    products = db.relationship("CustomizationProduct", secondary=association_table, back_populates="symptoms")


photo_fields = {
    'id': fields.Integer,
    'img_url': fields.String,
}

products_fields = {
    'name': fields.String,
    'image': fields.String(attribute='full_url'),
    'description': fields.String(attribute='desc'),
    'price': fields.Float,
    'photos': fields.Nested(photo_fields, allow_null=True),
}

category_fields = {
    'name': fields.String,
    'products': fields.Nested(products_fields, allow_null=True),
}
