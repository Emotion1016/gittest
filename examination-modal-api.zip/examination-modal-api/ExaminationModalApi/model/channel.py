from ExaminationModalApi import db


class Channel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), index=True, unique=True)
    name = db.Column(db.Unicode(100))
    utm_source = db.Column(db.String(100))
    utm_medium = db.Column(db.String(100))
    utm_campaign = db.Column(db.String(100))
    utm_content = db.Column(db.String(100))
    utm_term = db.Column(db.String(100))
