from urllib.parse import quote_plus

from sqlalchemy.exc import IntegrityError

from ExaminationModalApi import db, app
from ExaminationModalApi.model.util import url_safe_token
from ExaminationModalApi.util import https_for

SHARE_KEY_PREFIX = 'SR'


class Share(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), index=True, unique=True)
    report_id = db.Column(db.Integer, db.ForeignKey('report.id'), nullable=False)
    report = db.relationship('Report', backref=db.backref('shares', lazy='dynamic'))

    @property
    def url(self):
        try:
            if self.report.custom.code == "HUASHI" or self.report.custom.code == "SHCONBA" or self.report.custom.code == "SHGUODA":
                return https_for('history/' + quote_plus(self.key), _frontpage=True, csr="HUASHI")
            return https_for('history/' + quote_plus(self.key), _frontpage=True, csr=self.report.custom.code)
        except:
            return https_for('history/' + quote_plus(self.key), _frontpage=True, csr=self.report.custom.code)

    @classmethod
    def create(cls, report, key=None) -> 'Share':
        key = key or url_safe_token(app.config.get('AUTO_SHARE_KEY_LENGTH', 10))
        if not key.startswith(SHARE_KEY_PREFIX):
            key = SHARE_KEY_PREFIX + key
        s = cls()
        s.key = key
        s.report = report
        return s

    @classmethod
    def create_and_commit(cls, report, db, key=None, retries=3):
        """ WILL lead to database commit! """
        retry = 0
        s = None
        while retry < retries:
            s = Share.create(report, key)
            db.session.add(s)
            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()
                retry += 1
                s = None
            else:
                break
        return s
