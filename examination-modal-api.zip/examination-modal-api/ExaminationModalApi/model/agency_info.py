# -*- encoding: utf-8 -*-
from flask_restful import fields

from ExaminationModalApi import db
from ExaminationModalApi.model.util import Gender, calculate_age


class AgencyInfo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Unicode(128))
    cellphone = db.Column(db.String(32))
    birthday = db.Column(db.Date())
    gender = db.Column(db.Enum(Gender))
    height = db.Column(db.Integer())
    weight = db.Column(db.Integer())
    stage = db.Column(db.String(32))

    @property
    def age(self):
        return calculate_age(self.birthday)

    @property
    def gender_value(self):
        return self.gender.value


agency_info_fields = {
    'id': fields.Integer,
    'name': fields.String,
    'cellphone': fields.String,
    'birthday': fields.String,
    'age': fields.Integer,
    'gender': fields.Integer(attribute='gender_value'),
    'height': fields.Integer,
    'weight': fields.Integer,
    'stage': fields.String,
}