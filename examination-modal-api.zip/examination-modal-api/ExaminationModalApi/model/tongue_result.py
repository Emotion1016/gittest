from flask_restful import fields
from urllib.parse import quote_plus
from sqlalchemy import text

from ExaminationModalApi import db, app
from .util import from_dict, BelongsToUserMixin, BelongsToAgencyMixin
from ExaminationModalApi.content_loader.storage import CONTENT_TONGUE_RESULT
from ExaminationModalApi.util import https_for

content = app.content_storage.content
tongue_info = content[CONTENT_TONGUE_RESULT]


class TongueResult(db.Model, BelongsToUserMixin, BelongsToAgencyMixin):
    id = db.Column(db.Integer, primary_key=True)

    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    owner = db.relationship('User', uselist=False)

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'), nullable=True)
    agency = db.relationship('Agency', uselist=False)

    photo_id = db.Column(db.Integer, db.ForeignKey('photo.id'), nullable=False)
    photo = db.relationship('Photo', uselist=False)

    time = db.Column(db.DateTime(timezone=False))

    algorithm_version_id = db.Column(db.Integer, db.ForeignKey('version.id'), nullable=False)
    algorithm_version = db.relationship('Version')

    diagnosis_raw = db.Column(db.Integer())
    crack = db.Column(db.Integer())

    nature_L = db.Column(db.Integer())
    nature_a = db.Column(db.Integer())
    nature_b = db.Column(db.Integer())

    coat_L = db.Column(db.Integer())
    coat_a = db.Column(db.Integer())
    coat_b = db.Column(db.Integer())

    tongueDetectRes = db.Column(db.Integer())
    tongueCrack = db.Column(db.Integer())
    tongueFatThin = db.Column(db.Integer())
    tongueCoatThickness = db.Column(db.Integer())
    tongueCoatColor = db.Column(db.Integer())
    tongueNatureColor = db.Column(db.Integer())

    face_recognize_tag = db.Column(db.Integer(), nullable=True, index=True)
    mark = db.Column(db.Integer, default=0, server_default=text('0'))

    channel = db.Column(db.String(100))
    client_info = db.Column(db.String(1000))
    sn = db.Column(db.String(100))

    from_dict = classmethod(from_dict)

    @property
    def report_tongue_url(self):
        return https_for('report_tongue/' + quote_plus(str(self.id)), _frontpage=True, csr=self.agency.custom.code)

    @property
    def tongue_nature_color_name(self):
        return ['舌暗红', '舌淡白', '舌淡红', '舌红', '舌深红（舌紫）'][self.tongueNatureColor] \
            if self.tongueNatureColor is not None else None

    @property
    def tongue_shape_name(self):
        if self.tongueFatThin is None or self.tongueCrack is None:
            return None
        # 舌胖瘦正常 [正常,舌胖]  [无裂纹,有裂纹]
        if self.tongueFatThin == 0:
            if self.tongueCrack == 0:
                return '正常'
            elif self.tongueCrack == 1:
                return '有裂纹'
        elif self.tongueFatThin == 1:
            s = ['无裂纹', '有裂纹'][self.tongueCrack]
            return '舌胖、 ' + s
        return None

    @property
    def tongue_coat_thickness_name(self):
        return ['薄苔', '厚苔'][self.tongueCoatThickness] if self.tongueCoatThickness is not None else None

    @property
    def tongue_coat_color_name(self):
        return ['苔白', '苔黄'][self.tongueCoatColor] if self.tongueCoatColor is not None else None

    @property
    def tongue_nature_color_info(self):
        name = ['舌暗红', '舌淡白', '舌淡红', '舌红', '舌深红（舌紫）'][self.tongueNatureColor] \
            if self.tongueNatureColor is not None else None
        info = tongue_info.get(name, None)
        return info[0] if info else None

    @property
    def tongue_fat_thin_info(self):
        name = ['正常', '舌胖'][self.tongueFatThin] if self.tongueFatThin is not None else None
        info = tongue_info.get(name, None)
        return info[0] if info else None

    @property
    def tongue_crack_info(self):
        name = ['无裂纹', '有裂纹'][self.tongueCrack] if self.tongueCrack is not None else None
        info = tongue_info.get(name, None)
        return info[0] if info else None

    @property
    def tongue_coat_thickness_info(self):
        name = ['薄苔', '厚苔'][self.tongueCoatThickness] if self.tongueCoatThickness is not None else None
        info = tongue_info.get(name, None)
        return info[0] if info else None

    @property
    def tongue_coat_color_info(self):
        name = ['苔白', '苔黄'][self.tongueCoatColor] if self.tongueCoatColor is not None else None
        info = tongue_info.get(name, None)
        return info[0] if info else None

    @property
    def lab_define(self):
        return 'Lab颜色模型基于人对颜色的感觉。Lab中的数值描述正常视力的人能够看到的所有颜色。因为Lab描述的是颜色的显示方式，而不是设备(如显示器、桌面打印机或数码相机)生成颜色所需的特定色料的数量，所以Lab被视为与设备无关的颜色模型。颜色 色彩管理系统使用Lab作为色标，以将颜色从一个色彩空间转换到另一个色彩空间。Lab色彩模型是由亮度(L)和有关色彩的a, b三个要素组成。L表示亮度(Luminosity)，a表示从洋红色至绿色的范围，b表示从黄色至蓝色的范围。所有的颜色就以这三个值交互变化所组成。'


basic_tongue_result_fields = {
    'id': fields.Integer,
    'report_tongue_url': fields.String,
    'detectRes': fields.Integer(attribute='tongueDetectRes'),
    'tongueDetectRes': fields.Integer,
    'tongueCrack': fields.Integer,
    'tongueFatThin': fields.Integer,
    'tongueCoatThickness': fields.Integer,
    'tongueCoatColor': fields.Integer,
    'tongueNatureColor': fields.Integer,
    'nature_L': fields.Integer,
    'nature_a': fields.Integer,
    'nature_b': fields.Integer,
    'coat_L': fields.Integer,
    'coat_a': fields.Integer,
    'coat_b': fields.Integer,
    'crack': fields.Integer,
    'tongue_nature_color_info': fields.Raw,
    'tongue_fat_thin_info': fields.Raw,
    'tongue_crack_info': fields.Raw,
    'tongue_coat_thickness_info': fields.Raw,
    'tongue_coat_color_info': fields.Raw,
    'lab_define': fields.String
}

basic_tongue_result_fields_with_url = dict(basic_tongue_result_fields)
basic_tongue_result_fields_with_url.update({
    'photo_url': fields.String
})
