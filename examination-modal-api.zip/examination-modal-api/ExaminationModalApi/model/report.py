import pytz
from flask_restful import fields, reqparse
from sqlalchemy import desc, text
import json
from datetime import timedelta

from ExaminationModalApi import db, app
from ExaminationModalApi.examination.score import locate_term, HEALTH_STATUS_SICK, HEALTH_STATUS_SUB_HEALTHY, \
    HEALTH_STATUS_HEALTHY, HEALTH_STATUS_NAMES
from ExaminationModalApi.content_loader.storage import ALL_CONTENT_TYPES
from ExaminationModalApi.examination.solution import load_solutions
from ExaminationModalApi.model.face_result import basic_face_result_fields
from ExaminationModalApi.model.share import Share
from ExaminationModalApi.model.symptom import symptom_fields
from ExaminationModalApi.model.tongue_result import basic_tongue_result_fields
from ExaminationModalApi.model.user_info_history import user_info_history_fields
from ExaminationModalApi.model.user import simple_user_fields
from ExaminationModalApi.model.util import page_fields
from ExaminationModalApi.model.agency_info import agency_info_fields
from ExaminationModalApi.model.medical_history import medical_history
from ExaminationModalApi.model.problems import to_problem_options
from ExaminationModalApi.content_loader.storage import CONTENT_HEALTH_RISK, CONTENT_SYMPTOM_DEFINITION, \
    CONTENT_PRESCRIPTION

content = app.content_storage.content
additional_data = dict()
additional_data[CONTENT_HEALTH_RISK] = content.get(CONTENT_HEALTH_RISK)
additional_data[CONTENT_SYMPTOM_DEFINITION] = content.get(CONTENT_SYMPTOM_DEFINITION)
JINGUI = [i for i in content[CONTENT_PRESCRIPTION]['肾虚'] if i['name'] == '金匮肾气丸'][0]
LIUWEI = [i for i in content[CONTENT_PRESCRIPTION]['肾虚'] if i['name'] == '六味地黄丸'][0]


def fix_solution(symptoms, data):
    def remove_jingui(d):
        return [i for i in d if i['name'] != '金匮肾气丸']

    def remove_liuwei(d):
        return [i for i in d if i['name'] != '六味地黄丸']

    if len(symptoms) > 0 and symptoms[0] == '肾虚':
        d = data['prescription']['肾虚']
        if len(symptoms) == 1:
            # 如果仅肾虚且无其他症状，则首推金匮肾气丸
            d = remove_jingui(d)
            d.insert(0, JINGUI)
        else:
            if symptoms[1] == '阴虚':
                # 如果肾虚最高且阴虚第二，则首推六味地黄丸
                d = remove_liuwei(d)
                d.insert(0, LIUWEI)
            elif symptoms[1] in ['阳虚', '气虚']:
                # 如果肾虚最高且阳虚第二或气虚第二，则首推金匮肾气丸
                d = remove_jingui(d)
                d.insert(0, JINGUI)
            else:
                ...
        data['prescription']['肾虚'] = d[:3]
    return data


class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    owner = db.relationship('User', uselist=False, backref=db.backref('reports', lazy='dynamic'))

    face_result_id = db.Column(db.Integer, db.ForeignKey('face_result.id'), nullable=False)
    face_result = db.relationship('FaceResult')

    tongue_result_id = db.Column(db.Integer, db.ForeignKey('tongue_result.id'), nullable=False)
    tongue_result = db.relationship('TongueResult')

    pulse_result_id = db.Column(db.Integer, db.ForeignKey('pulse.id'))
    pulse_result = db.relationship('Pulse')

    question_result_id = db.Column(db.Integer, db.ForeignKey('question_result.id'), nullable=False)
    question_result = db.relationship('QuestionResult', backref=db.backref('reports', lazy='dynamic'))

    modal_version_id = db.Column(db.Integer, db.ForeignKey('version.id'), nullable=False)
    modal_version = db.relationship('Version')

    time = db.Column(db.DateTime(timezone=False))

    health_score = db.Column(db.Float())
    solution_seed = db.Column(db.String(1000))
    solution_json = db.Column(db.Text)
    symptom_status = db.Column(db.Text)
    ip = db.Column(db.String(50))

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'), nullable=True)
    agency = db.relationship('Agency', backref=db.backref('reports', lazy='dynamic'))

    ua = db.Column(db.UnicodeText())

    user_info_id = db.Column(db.Integer, db.ForeignKey('user_info_history.id'), nullable=True)
    user_info = db.relationship('UserInfoHistory', uselist=False, backref=db.backref('reports', lazy=True))

    city = db.Column(db.String(50), nullable=True)
    channel = db.Column(db.String(100))
    client_info = db.Column(db.String(1000), nullable=True)
    sn = db.Column(db.String(100))

    mark = db.Column(db.Integer, default=0, server_default=text('0'))
    medical_history = db.relationship('MedicalCondition', secondary='medical_history')

    custom_id = db.Column(db.Integer, db.ForeignKey('custom.id'))
    custom = db.relationship('Custom')

    del_flag = db.Column(db.Boolean, server_default=text('0'), default=0)

    @property
    def solutions(self):
        data = load_solutions(
            [{'name': s.name} for s in self.symptoms],
            self.solution_seed_dict,
        )
        return fix_solution([i.name for i in self.symptoms], data)

    @property
    def solution_seed_dict(self):
        if self.solution_json:
            return json.loads(self.solution_json)

        if self.solution_seed:
            data = dict()
            key_list = self.solution_seed.split(',')
            i = 0
            symptoms = [i.name for i in self.symptoms]
            if not symptoms:
                symptoms.append('健康')

            for content_type in ALL_CONTENT_TYPES:
                for symptom in self.symptoms:
                    if i < len(key_list):
                        data.setdefault(content_type, dict())[symptom] = [int(j) for j in key_list[i].split('|')]
                        i += 1
                    else:
                        break
            return data
        return None

    @property
    def symptom_status_dict(self):
        return json.loads(self.symptom_status) if self.symptom_status else None

    @property
    def display_id(self):
        return self.time.strftime('%y%m') + '{id:06d}'.format(id=self.id)

    @property
    def utc_time(self):
        return self.time.replace(tzinfo=pytz.utc)

    @property
    def china_time(self):
        return self.utc_time.astimezone(pytz.timezone('Asia/Shanghai'))

    @property
    def format_time(self):
        return (self.time + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M')

    @property
    def display_time(self):
        return locate_term(self.china_time)

    @property
    def health_status_index(self):
        if self.health_score < 60:
            return HEALTH_STATUS_SICK
        elif 60 <= self.health_score < 90:
            return HEALTH_STATUS_SUB_HEALTHY
        else:
            return HEALTH_STATUS_HEALTHY

    @property
    def health_status_text(self):
        return HEALTH_STATUS_NAMES[self.health_status_index]

    @property
    def report_url(self):
        """ public shared URL for QR code generating """
        share = self.shares.order_by(desc(Share.id)).limit(1).first()
        if not share or not share.key:
            return ''
        return share.url

    @property
    def key(self):
        """ public shared URL for QR code generating """
        share = self.shares.order_by(desc(Share.id)).limit(1).first()
        if not share or not share.key:
            return ''
        return share.key

    @property
    def api_url(self):
        return '/api/share/' + self.key

    @property
    def agency_info(self):
        return self.agency.agency_info if self.agency else None

    @property
    def is_print(self):
        return self.agency.setting_dict.get('is_print', 1) if self.agency and self.agency.setting_dict else 1

    @property
    def additional_info(self):
        return additional_data

    @property
    def pulse_url(self):
        return self.pulse_result.url

    @property
    def has_pulse(self):
        return True if self.pulse_result else False


class ScoreFormat(fields.Raw):
    def format(self, value):
        return float('%0.1f' % value)


brief_report_fields = {
    'time': fields.String(attribute='format_time'),
    'display_time': fields.String,
    'report_url': fields.String,
    'sn': fields.String,
    'health_score': fields.Float,
    'health_status_index': fields.Integer,
    'health_status_text': fields.String,
}

simple_report_fields = {
    'id': fields.Integer,
    'display_id': fields.String,
    'health_score': ScoreFormat,
    'time': fields.String(attribute='format_time'),
    'display_time': fields.String,
    'symptoms': fields.List(fields.Nested(symptom_fields)),
    'health_status_index': fields.Integer,
    'health_status_text': fields.String,
    'face_photo_url': fields.String,
    'tongue_photo_url': fields.String,
}

simple_shared_report_fields = dict(simple_report_fields)
simple_shared_report_fields.update({
    'report_url': fields.String,
})

report_page_fields = dict(page_fields)
report_page_fields.update({
    'items': fields.List(fields.Nested(simple_shared_report_fields)),
})

detail_report_fields = dict(simple_report_fields)
detail_report_fields.update({
    'owner': fields.Nested(simple_user_fields, allow_null=True),
    'face_result': fields.Nested(basic_face_result_fields),
    'tongue_result': fields.Nested(basic_tongue_result_fields),
    'solutions': fields.Raw,
    'symptom_status': fields.Raw(attribute='symptom_status_dict'),
    'agency_info': fields.Nested(agency_info_fields),
    'user_info': fields.Nested(user_info_history_fields, allow_null=True),
    'sign_name_url': fields.String,
    'is_print': fields.Integer
})

detail_shared_report_fields = dict(detail_report_fields)
detail_shared_report_fields.update({
    'report_url': fields.String,
})

detail_report_with_thumb = dict(detail_shared_report_fields)

detail_report_with_thumb.update({
    'face_photo_url': fields.String,
    'tongue_photo_url': fields.String,
    'product': fields.Raw,
    'additional_info': fields.Raw,
    'has_pulse': fields.Boolean,
    'pulse_url': fields.String
})


def int_or_none(key):
    if str(key).isdigit():
        return int(key)
    else:
        return None


create_report_parser = reqparse.RequestParser()
create_report_parser.add_argument('face_result_id', type=int, required=True, help='ID of face analysis result',
                                  location=('json',))
create_report_parser.add_argument('tongue_result_id', type=int, required=True, help='ID of tongue analysis result',
                                  location=('json',))
create_report_parser.add_argument('question_result_id', type=int, required=True, help='ID of answer analysis result')
create_report_parser.add_argument('med_recommend', type=medical_history, action='append', required=False,
                                  help='med_recommend info',
                                  location=('json',))
create_report_parser.add_argument('problem_options', type=to_problem_options, action='append', help='problem options')
create_report_parser.add_argument('client_info', type=str, required=False)
create_report_parser.add_argument('user_info', type=dict, required=False)
create_report_parser.add_argument('channel', type=str, required=False)
create_report_parser.add_argument('sign_name_id', type=int_or_none, required=False)
create_report_parser.add_argument('pulse_result_id', type=int_or_none, required=False, help='ID of pulse analysis result',
                                  location=('json',))
