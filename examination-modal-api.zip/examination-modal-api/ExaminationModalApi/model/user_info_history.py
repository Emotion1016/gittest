from flask_restful import fields

from ExaminationModalApi import db
from ExaminationModalApi.model.user import User, to_gender
from ExaminationModalApi.model.util import Gender, calculate_age

MEDICAL_HISTORY_SEPARATOR = '|'


class UserInfoHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Unicode(128))
    birthday = db.Column(db.Date())
    gender = db.Column(db.Enum(Gender))
    height = db.Column(db.Integer())
    weight = db.Column(db.Integer())

    age_range = db.Column(db.String(32))
    stage = db.Column(db.String(32))

    medical_history = db.Column(db.Unicode(200))

    idcard = db.Column(db.String(32))
    ages = db.Column(db.Integer())
    @property
    def display_birthday(self):
        if self.birthday:
            return self.birthday.isoformat()
        return None

    @property
    def gender_value(self):
        return self.gender.value

    @property
    def age(self):
        return calculate_age(self.birthday)

    @property
    def medical_history_list(self):
        return self.medical_history.split(MEDICAL_HISTORY_SEPARATOR) if self.medical_history else list()

    @classmethod
    def from_user(cls, u: User = None, d: dict = None, agency_info=None):
        ans = cls()
        if u:
            ans.name = u.name
            ans.birthday = u.birthday
            ans.gender = u.gender
            ans.height = u.height
            ans.weight = u.weight
            ans.age_range = u.age_range
            ans.stage = u.stage
            ans.medical_history = MEDICAL_HISTORY_SEPARATOR.join(cond.name for cond in u.medical_history)
            ans.idcard = u.idcard
            ans.ages = u.ages
        if d:
            ans.height = d.get('height')
            ans.weight = d.get('weight')
            ans.age_range = d.get('age_range')
            ans.stage = d.get('stage')
            ans.gender = to_gender(d.get('gender')) if d.get('gender') else None
            ans.medical_history = MEDICAL_HISTORY_SEPARATOR.join(cond.name for cond in d.get('medical_history', []))
            ans.idcard = d.get('idcard') if d.get('idcard') else None
            ans.ages = d.get('ages') if d.get('ages') else None
            ans.name = d.get('name') if d.get('name') else None
        if agency_info:
            ans.name = agency_info.name
            ans.birthday = agency_info.birthday
            ans.gender = agency_info.gender
            ans.height = agency_info.height
            ans.weight = agency_info.weight
            ans.stage = agency_info.stage
            # ans.medical_history = MEDICAL_HISTORY_SEPARATOR.join(cond.name for cond in u.medical_history)

        return ans


user_info_history_fields = {
    'name': fields.String,
    'birthday': fields.String(attribute='display_birthday'),
    'gender': fields.Integer(attribute='gender_value'),
    'height': fields.Integer,
    'weight': fields.Integer,
    'medical_history': fields.List(fields.String, attribute='medical_history_list'),
    'age': fields.Integer,
}
