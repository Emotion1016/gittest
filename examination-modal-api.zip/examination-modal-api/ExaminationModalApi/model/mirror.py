from ExaminationModalApi import db
from sqlalchemy import text

from flask_restful import reqparse, fields


class Mirror(db.Model):
    __bind_key__ = 'public'
    id = db.Column(db.Integer, primary_key=True)
    agencyname = db.Column(db.String(100))  # 机构名
    deviceid = db.Column(db.String(100), index=True, unique=True, nullable=False)  # 设备唯一id
    model = db.Column(db.String(100))  # 型号
    version = db.Column(db.String(100))  # 包名版本号
    create_time = db.Column(db.TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'))
    adminname = db.Column(db.String(100))
    latitude = db.Column(db.Float)  # 定位 纬度
    longtitude = db.Column(db.Float) # 经度
    status = db.Column(db.Integer)  # 0未审核，1通过，2拒绝
    db_name = db.Column(db.String(100), default=db.engine.url.database)  # 数据库名称
    vendor_code = db.Column(db.String(100))
    custom_name = db.Column(db.String(100))
    accept_type = db.Column(db.Integer)  # 激活方式0单个1批量2审核3其它
    online = db.Column(db.Boolean)


class Remark(db.Model):
    __bind_key__ = 'public'
    id = db.Column(db.Integer, primary_key=True)
    adminname = db.Column(db.String(100), nullable=False)
    time = db.Column(db.TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'))
    mirror_id = db.Column(db.Integer, nullable=False)


create_mirror_parser = reqparse.RequestParser()
create_mirror_parser.add_argument('Sn', dest='deviceid', location=('headers',), required=True)
create_mirror_parser.add_argument('Channel', dest='model', location=('headers',), required=True)
create_mirror_parser.add_argument('Clientinfo', dest='version', location=('headers',), required=True)
create_mirror_parser.add_argument('longtitude', required=True)
create_mirror_parser.add_argument('latitude', required=True)


basic_mirror_fields = {
    'latitude': fields.Float,
    'longtitude': fields.Float,
}
