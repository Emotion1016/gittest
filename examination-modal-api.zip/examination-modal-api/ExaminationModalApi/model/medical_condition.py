from ExaminationModalApi import db
from flask_restful import fields
from sqlalchemy import text


class MedicalCondition(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Unicode(100))
    del_flag = db.Column(db.Boolean, server_default=text('0'))


medical_condition_fields = {
    'id': fields.Integer,
    'name': fields.String
}

