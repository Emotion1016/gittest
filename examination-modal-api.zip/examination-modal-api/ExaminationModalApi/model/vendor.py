from ExaminationModalApi import db
from flask_restful import fields
from ExaminationModalApi.model.util import Status
from sqlalchemy import text


class Vendor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(100), unique=True)
    owner_name = db.Column(db.String(100))
    create_admin = db.Column(db.Integer)
    type = db.Column(db.String(1), nullable=False)
    del_flag = db.Column(db.Boolean, default=0, server_default=text('0'))
    create_time = db.Column(db.DateTime)

    custom_id = db.Column(db.Integer, db.ForeignKey('custom.id'))
    custom = db.relationship('Custom')

    categories = db.Column(db.String(10))


vendor_field = {
    'code': fields.String(),
    'owner_name': fields.String(),
    'create_admin': fields.Integer(),
    'type': fields.String(),
    'create_time': fields.DateTime
}


class Custom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True)
    login_name = db.Column(db.String(50), unique=True)
    code = db.Column(db.String(50), unique=True)
    description = db.Column(db.String(100))
    agencyRoleId = db.Column(db.Integer)
    roleId = db.Column(db.Integer)
    del_flag = db.Column(db.Boolean, default=False, server_default=text('0'))
    admin_manage_flag = db.Column(db.Boolean)
    create_by = db.Column(db.Integer)
    create_time = db.Column(db.DateTime)

