from datetime import datetime

from flask_restful import fields
from sqlalchemy import text

from ExaminationModalApi import db
from ExaminationModalApi.util import https_for
from ExaminationModalApi.model.agency_info import agency_info_fields
from ExaminationModalApi.model.vendor import vendor_field
import json


class Agency(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100))
    name = db.Column(db.Unicode(100), nullable=False)
    login_name = db.Column(db.String(100), index=True, nullable=False, unique=True)
    password = db.Column(db.String(100), nullable=False)
    anonymous_report = db.Column(db.Boolean())
    type = db.Column(db.String(1), nullable=False)
    sales = db.Column(db.UnicodeText(50))
    create_time = db.Column(db.DateTime(timezone=False), default=datetime.utcnow)
    update_time = db.Column(db.DateTime(timezone=False), default=datetime.utcnow)
    token_time = db.Column(db.DateTime(timezone=False), default=datetime.utcnow)
    valid_begin_date = db.Column(db.Date())
    valid_end_date = db.Column(db.Date())
    del_flag = db.Column(db.Boolean, default=0, server_default=text('0'))

    vendor_id = db.Column(db.Integer, db.ForeignKey('vendor.id'), nullable=True)
    vendor = db.relationship('Vendor', uselist=False, backref=db.backref('agency', lazy='dynamic'))

    agency_info_id = db.Column(db.Integer, db.ForeignKey('agency_info.id'))
    agency_info = db.relationship('AgencyInfo')

    parent_id = db.Column(db.Integer)
    custom_id = db.Column(db.Integer, db.ForeignKey('custom.id'))
    custom = db.relationship('Custom')

    medical_history = db.relationship('MedicalCondition', secondary='medical_history')

    channel = db.Column(db.String(100))
    roleId = db.Column(db.Integer)

    setting = db.Column(db.String(1000))

    @property
    def cellphone(self):
        if not self.agency_info:
            return None
        else:
            return self.agency_info.cellphone

    @property
    def medical_history_keys(self):
        return [x.id for x in self.medical_history]

    @property
    def format_token_time(self):
        return self.token_time.strftime('%Y-%m-%d %H:%M:%S') if self.token_time else None

    @property
    def registration_url(self):
        return https_for('register', agencyKey=self.key, _frontpage=True)

    @property
    def valid_begin_datetime(self):
        return datetime(self.valid_begin_date.year, self.valid_begin_date.month, self.valid_begin_date.day)

    @property
    def valid_end_datetime(self):
        return datetime(self.valid_end_date.year, self.valid_end_date.month, self.valid_end_date.day)

    @property
    def setting_dict(self):
        return json.loads(self.setting) if self.setting else {}

    @property
    def categories(self):
        if self.vendor and self.vendor.categories:
            l = self.vendor.categories.split('|')
            return list(map(lambda x: int(x), l))
        else:
            return [1]

    @property
    def has_pulse(self):
        if self.vendor and self.vendor.categories:
            if "4" in self.vendor.categories:
                return True
            return False
        else:
            return False

    @property
    def has_idcard(self):
        if self.custom and self.custom.code:
            if self.custom.code == "SHTM":
                return True
            return False
        else:
            return False


simple_agency_fields = {
    'loginName': fields.String(attribute='login_name'),
    'cellphone': fields.String(),
    'name': fields.String,
    'key': fields.String,
    # 'registration_url': fields.String(),
    'anonymousReport': fields.Boolean(attribute='anonymous_report'),
    'type': fields.String,
    'agency_info': fields.Nested(agency_info_fields, allow_null=True),
    'signed': fields.Boolean,
    'setting': fields.Raw(attribute='setting_dict'),
    'categories': fields.Raw,
    'has_pulse': fields.Boolean,
    'has_idcard': fields.Boolean
}

detail_agency_fields = simple_agency_fields.copy()
detail_agency_fields.update({
    'id': fields.Integer(),
    'sales': fields.String(),
    'create_time': fields.DateTime(),
    'update_time': fields.DateTime(),
    'valid_begin_date': fields.DateTime(attribute='valid_begin_datetime'),
    'valid_end_date': fields.DateTime(attribute='valid_end_datetime'),
})

