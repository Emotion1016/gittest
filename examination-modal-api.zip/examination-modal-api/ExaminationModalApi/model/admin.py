# -*- encoding: utf-8 -*-
from ExaminationModalApi import db


class Admin(db.Model):
    __tablename__ = 'admin'
    adminId = db.Column(db.Integer, primary_key=True, nullable=False)
    adminName = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(32), nullable=False)
    roleId = db.Column(db.Integer)
    headUrl = db.Column(db.String(200), nullable=False, default='')
    realName = db.Column(db.String(200), nullable=False, default='')
    userSex = db.Column(db.Integer, default=0)
    userBirthday = db.Column(db.BigInteger, default=0)
    mobile = db.Column(db.String(20), nullable=False, default='')
    email = db.Column(db.String(100), nullable=False, default='')
    isAdmin = db.Column(db.Integer, nullable=False, default=0)
    deleteFlag = db.Column(db.Integer, nullable=False, default=0)
    createTime = db.Column(db.BigInteger, nullable=False, default=0)


class LinkAdmin(db.Model):
    __tablename__ = 'linkadmin'
    linkId = db.Column(db.Integer, primary_key=True)
    linkName = db.Column(db.String(30), nullable=False, default='')
    linkUrl = db.Column(db.String(200), nullable=False, default='')
    keyWord = db.Column(db.String(20), nullable=False, default='')
    parentId = db.Column(db.Integer, default=0)
    ifChild = db.Column(db.Integer, default=0)
    displayOrder = db.Column(db.Integer, default=0)
    deleteFlag = db.Column(db.Integer, default=0)
    fa = db.Column(db.String(255))
    createAdmin = db.Column(db.Integer)
    createTime = db.Column(db.DateTime)


class Role(db.Model):
    __tablename__ = 'role'
    roleId = db.Column(db.Integer, primary_key=True)
    roleName = db.Column(db.String(30), nullable=False, default='')
    roleBrief = db.Column(db.String(100), nullable=False, default='')
    type = db.Column(db.Integer)
    adminPermission = db.Column(db.Text)
    createAdmin = db.Column(db.Integer)
    createTime = db.Column(db.DateTime)
