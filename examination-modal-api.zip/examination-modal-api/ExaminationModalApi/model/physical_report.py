import pytz
from typing import Optional
from flask_restful import fields, reqparse
from sqlalchemy import desc, text
import json
from urllib.parse import quote_plus

from datetime import timedelta

from ExaminationModalApi.util import https_for
from ExaminationModalApi.model.util import url_safe_token
from ExaminationModalApi import db, app
from ExaminationModalApi.examination.solution import load_solutions
from ExaminationModalApi.model.face_result import basic_face_result_fields
from ExaminationModalApi.model.symptom import symptom_fields
from ExaminationModalApi.model.tongue_result import basic_tongue_result_fields
from ExaminationModalApi.model.user_info_history import user_info_history_fields
from ExaminationModalApi.model.user import simple_user_fields
from ExaminationModalApi.model.util import page_fields
from ExaminationModalApi.model.agency_info import agency_info_fields
from ExaminationModalApi.model.medical_history import medical_history
from ExaminationModalApi.model.problems import to_problem_options

SHARE_KEY_PREFIX = 'SR'


def create_key() -> str:
    key = url_safe_token(app.config.get('AUTO_SHARE_KEY_LENGTH', 10))
    if not key.startswith(SHARE_KEY_PREFIX):
        key = SHARE_KEY_PREFIX + key
    return key


class PhysicalReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    owner = db.relationship('User', uselist=False, backref=db.backref('physical_reports', lazy='dynamic'))

    face_result_id = db.Column(db.Integer, db.ForeignKey('face_result.id'), nullable=False)
    face_result = db.relationship('FaceResult')

    tongue_result_id = db.Column(db.Integer, db.ForeignKey('tongue_result.id'), nullable=False)
    tongue_result = db.relationship('TongueResult')

    pulse_result_id = db.Column(db.Integer, db.ForeignKey('pulse.id'))
    pulse_result = db.relationship('Pulse')

    question_result_id = db.Column(db.Integer, db.ForeignKey('question_result.id'), nullable=False)
    question_result = db.relationship('QuestionResult', backref=db.backref('physical_reports', lazy='dynamic'))

    time = db.Column(db.DateTime(timezone=False))

    solution_json = db.Column(db.Text)
    symptom_status = db.Column(db.Text)
    ip = db.Column(db.String(50))

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'), nullable=True)
    agency = db.relationship('Agency', backref=db.backref('physical_reports', lazy='dynamic'))

    ua = db.Column(db.UnicodeText())

    user_info_id = db.Column(db.Integer, db.ForeignKey('user_info_history.id'), nullable=True)
    user_info = db.relationship('UserInfoHistory', uselist=False, backref=db.backref('physical_reports', lazy=True))

    city = db.Column(db.String(50), nullable=True)
    channel = db.Column(db.String(100))
    client_info = db.Column(db.String(1000), nullable=True)
    sn = db.Column(db.String(100))

    mark = db.Column(db.Integer, default=0, server_default=text('0'))
    medical_history = db.relationship('MedicalCondition', secondary='medical_history')

    custom_id = db.Column(db.Integer, db.ForeignKey('custom.id'))
    custom = db.relationship('Custom')

    key = db.Column(db.String(100), default=create_key, index=True, unique=True)

    del_flag = db.Column(db.Boolean, default=0, server_default=text('0'))

    @property
    def solutions(self):
        return load_solutions(
            [{'name': s.name} for s in self.symptoms],
            self.solution_seed_dict,
            type=2
        )

    @property
    def solution_seed_dict(self):
        if self.solution_json:
            return json.loads(self.solution_json)

        return None

    @property
    def symptom_status_dict(self):
        return json.loads(self.symptom_status) if self.symptom_status else None

    @property
    def display_id(self):
        return self.time.strftime('%y%m') + '{id:06d}'.format(id=self.id)

    @property
    def utc_time(self):
        return self.time.replace(tzinfo=pytz.utc)

    @property
    def format_time(self):
        return (self.time + timedelta(hours=8)).strftime('%Y-%m-%d %H:%M')

    @property
    def report_url(self):
        return https_for('report/' + quote_plus(self.key), _frontpage=True, category=2, csr=self.custom.code)

    @property
    def api_url(self):
        return '/api30/share/' + self.key

    @property
    def agency_info(self):
        return self.agency.agency_info if self.agency else None

    @property
    def is_print(self):
        return self.agency.setting_dict.get('is_print', 1) if self.agency and self.agency.setting_dict else 1

    @property
    def result(self):
        if len(self.symptoms) == 1:
            return self.symptoms[0].name
        elif len(self.symptoms) == 2:
            if self.symptoms[0].name == u'平和质':
                return '平和质有%s倾向' % self.symptoms[1].name
            else:
                return '%s兼%s' % (self.symptoms[0].name, self.symptoms[1].name)
        else:
            return ''

    @property
    def pulse_url(self):
        return self.pulse_result.url

    @property
    def has_pulse(self):
        return True if self.pulse_result else False


simple_report_fields = {
    'id': fields.Integer,
    'display_id': fields.String,
    'time': fields.String(attribute='format_time'),
    'symptoms': fields.List(fields.Nested(symptom_fields)),
    'result': fields.String,
    'face_photo_url': fields.String,
    'tongue_photo_url': fields.String,
    'report_url': fields.String,
    'sn': fields.String,
}


physical_report_page_fields = dict(page_fields)
physical_report_page_fields.update({
    'items': fields.List(fields.Nested(simple_report_fields)),
})

detail_physical_report_fields = dict(simple_report_fields)
detail_physical_report_fields.update({
    'owner': fields.Nested(simple_user_fields, allow_null=True),
    'face_result': fields.Nested(basic_face_result_fields),
    'tongue_result': fields.Nested(basic_tongue_result_fields),
    'product': fields.Raw,
    'solutions': fields.Raw,
    'symptom_status': fields.Raw(attribute='symptom_status_dict'),
    'agency_info': fields.Nested(agency_info_fields),
    'user_info': fields.Nested(user_info_history_fields, allow_null=True),
    'sign_name_url': fields.String,
    'is_print': fields.Integer,
    'has_pulse': fields.Boolean,
    'pulse_url': fields.String
})


def int_or_none(key):
    if str(key).isdigit():
        return int(key)
    else:
        return None


create_physical_report_parser = reqparse.RequestParser()
create_physical_report_parser.add_argument('face_result_id', type=int, required=True, help='ID of face analysis result',
                                           location=('json',))
create_physical_report_parser.add_argument('tongue_result_id', type=int, required=True, help='ID of tongue analysis result',
                                           location=('json',))
create_physical_report_parser.add_argument('question_result_id', type=int, required=True, help='ID of answer analysis result')
create_physical_report_parser.add_argument('med_recommend', type=medical_history, action='append', required=False, help='med_recommend info',
                                           location=('json',))
create_physical_report_parser.add_argument('problem_options', type=to_problem_options, action='append', help='problem options')
create_physical_report_parser.add_argument('client_info', type=str, required=False)
create_physical_report_parser.add_argument('user_info', type=dict, required=False)
create_physical_report_parser.add_argument('channel', type=str, required=False)
create_physical_report_parser.add_argument('sign_name_id', type=int_or_none, required=False)
create_physical_report_parser.add_argument('pulse_result_id', type=int_or_none, required=False, help='ID of pulse analysis result',
                                  location=('json',))