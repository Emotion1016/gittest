from datetime import datetime
from typing import Optional

from wechatpy.client.api import WeChatQRCode

from ExaminationModalApi import db, app, qrcode_client


class QRCode(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    scene_id = db.Column(db.Integer, nullable=True, index=True)

    channel_id = db.Column(db.Integer, db.ForeignKey('channel.id'), nullable=True)
    channel = db.relationship('Channel', backref=db.backref('qrcodes', lazy='dynamic'))

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'), nullable=True)
    agency = db.relationship('Agency', backref=db.backref('qrcodes', lazy='dynamic'))

    created_at = db.Column(db.DateTime(timezone=False))
    updated_at = db.Column(db.DateTime(timezone=False))

    ticket = db.Column(db.Text(512), nullable=True)
    url = db.Column(db.Text(255), nullable=True)

    extra = db.Column(db.Text(255), nullable=True)

    @property
    def image_url(self):
        try:
            return WeChatQRCode.get_url(self.ticket)
        except Exception:
            app.logger.exception('cannot get qrcode url from ticket %r', self.ticket)
            return ''

    @classmethod
    def create(cls, scene_id, agency_id=None, channel_id=None) -> Optional['QRCode']:
        params = {
            'action_name': 'QR_LIMIT_SCENE',
            'action_info': {
                'scene': {'scene_id': scene_id},
            }
        }
        try:
            res = qrcode_client.create(params)
            qrcode = cls()
            qrcode.scene_id = scene_id
            qrcode.ticket = res.get('ticket')
            qrcode.url = res.get('url')
            qrcode.agency_id = agency_id
            qrcode.channel_id = channel_id
            qrcode.created_at = qrcode.updated_at = datetime.utcnow()
        except Exception:
            app.logger.exception('cannot create qrcode for scene id %s', scene_id)
            return None
        return qrcode
