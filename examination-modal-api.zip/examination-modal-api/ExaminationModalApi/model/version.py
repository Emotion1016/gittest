from ExaminationModalApi import db
from enum import Enum


class Usage(Enum):
    face_algorithm = 0
    tongue_algorithm = 1
    question = 2
    modal = 3


class Version(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    major = db.Column(db.Integer)
    minor = db.Column(db.Integer)
    build = db.Column(db.Integer)
    usage = db.Column(db.Enum(Usage))
    description = db.Column(db.UnicodeText())
