# -*- encoding: utf-8 -*-
from ExaminationModalApi import db
from datetime import datetime
from flask_restful import fields


class SignName(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    oss_id = db.Column(db.String(1000))
    upload_time = db.Column(db.DateTime(), default=datetime.now)

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'))
    agency = db.relationship('Agency')

    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    user = db.relationship('User')

    report_id = db.Column(db.Integer)
    physical_report_id = db.Column(db.Integer)


basic_sign_name_fields = {
    'id': fields.Integer,
    'oss_id': fields.String,
    'agency_id': fields.Integer,
    'user_id': fields.Integer,
}
