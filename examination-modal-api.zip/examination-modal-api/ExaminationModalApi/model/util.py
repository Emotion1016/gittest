import base64
import copy
import enum
import json
import os
from typing import Dict, Type, Any, Optional
from datetime import date
from flask import current_app
from flask_restful import fields

from ExaminationModalApi import db
from ExaminationModalApi.util import get_today_begin_utc_time


def from_dict(cls: Type, d: Dict, flatten: Optional[bool]=True):
    o = cls()
    assign_from_dict(o, d, flatten)
    return o


def assign_from_dict(o: Any, d: Dict, flatten: Optional[bool]=True):
    for k, v in d.items():
        if flatten and isinstance(v, dict):
            assign_from_dict(o, v, flatten)
        else:
            setattr(o, k, v)


def url_safe_token(nbytes):
    tok = os.urandom(nbytes)
    return base64.urlsafe_b64encode(tok).rstrip(b'=').decode('ascii')


def calculate_age(birthday):
    if not birthday:
        return None
    today = date.today()
    age = today.year - birthday.year

    if today.month < birthday.month or (today.month == birthday.month and today.day < birthday.day):
        age -= 1

    return age


class BelongsToUserMixin(object):
    def belongs_to_user(self, u):
        if self.owner:
            return self.owner == u
        else:
            #owner 为空时候不管
            return True

class BelongsToAgencyMixin(object):
    def belongs_to_agency(self, a):
        return self.agency and self.agency == a


class Gender(enum.Enum):
    male = 1
    female = 2


class Status(enum.Enum):
    normal = 1
    block = 2


def add_photos_url(query):
    query.face_photo_url, should_commit1 = query.face_result.photo.get_thumb_url(
        db.session, current_app.bucket,
        current_app.config['OSS_THUMB_IMAGE_STYLE']
    )
    query.tongue_photo_url, should_commit2 = query.tongue_result.photo.get_thumb_url(
        db.session, current_app.bucket,
        current_app.config['OSS_THUMB_IMAGE_STYLE']
    )

    if should_commit1 or should_commit2:
        db.session.commit()

    return query


def add_photo_url_when_upload(query):
    query.photo_url, should_commit1 = query.photo.get_thumb_url(
        db.session, current_app.bucket,
        current_app.config['OSS_THUMB_IMAGE_STYLE']
    )
    return query


def add_question_answers(query):
    query.answers = query.question_result.answer

    try:
        query.answers = json.loads(query.answers)
    except:
        current_app.logger.exception('cannot parse answer %s', query.answers)
        query.answers = None

    return query


def setattr_with(obj, attr, value):
    setattr(obj, attr, value)
    return obj


page_fields = {
    'has_next': fields.Boolean,
    'has_prev': fields.Boolean,
    'next_num': fields.Integer,
    'page': fields.Integer,
    'pages': fields.Integer,
    'per_page': fields.Integer,
    'prev_num': fields.Integer,
}


def get_db_fields(table):
    fields = copy.deepcopy(db.metadata.tables[table].c._data._list)
    fields.remove('id')
    return fields


def get_first_before_this(cls, result):
    start_time = get_today_begin_utc_time()
    f = cls.query.filter(cls.time > start_time, cls.time < result.time,
                         cls.owner_id == result.owner_id, cls.owner_id != None)

    if hasattr(cls, 'mark'):
        f = f.filter(cls.mark != 2)

    if hasattr(cls, 'diagnosis_raw'):
        f = f.filter(cls.diagnosis_raw != 0)

    if hasattr(cls, 'answer'):
        f = f.filter(cls.answer == result.answer)

    return f.first()