from ExaminationModalApi import db


class AdminCategory(db.Model):
    __bind_key__ = 'admin'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Unicode(15))
    slug = db.Column(db.String(20), unique=True, index=True)

    @classmethod
    def by_slug(cls, slug):
        return cls.query.filter(cls.slug == slug).first()