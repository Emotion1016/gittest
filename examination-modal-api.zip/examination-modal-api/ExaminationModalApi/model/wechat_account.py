from ExaminationModalApi import db


class WeChatAccount(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    openid = db.Column(db.String(100), index=True, unique=True, nullable=False)
    unionid = db.Column(db.String(100), index=True, unique=True, nullable=True)
    user_id = db.Column(db.Integer(), db.ForeignKey('user.id'))
    user = db.relationship('User', uselist=False, lazy=False, backref=db.backref('wechat', uselist=False))
