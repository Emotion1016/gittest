from flask_restful import fields
from sqlalchemy import desc

from ExaminationModalApi import db


name_map = {'气虚': 'Qi deficiency',
            '阳虚': 'Yang deficiency',
            '阴虚': 'Yin deficiency',
            '痰湿': 'Phlegm and Dampness',
            '郁滞': 'Stagnation and Stasis',
            '脾虚': 'Deficiency of spleen',
            '肾虚': 'Deficiency of kidney',
            '健康': 'Healthy'}


class Symptom(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    report_id = db.Column(db.Integer, db.ForeignKey('report.id'))
    physical_report_id = db.Column(db.Integer, db.ForeignKey('physical_report.id'))
    name = db.Column(db.Unicode(10))
    score = db.Column(db.Float())
    reason = db.Column(db.String(300))

    @property
    def enname(self):
        if not self.name:
            return ''
        return name_map.get(self.name)


# afterward definition, so that table class can be referenced (in order_by)
Symptom.report = db.relationship(
    'Report',
    backref=db.backref(
        'symptoms',
        lazy=False,
        # order_by=desc(Symptom.score)
        order_by=[Symptom.id, desc(Symptom.score)]
    )
)

Symptom.physical_report = db.relationship(
    'PhysicalReport',
    backref=db.backref(
        'symptoms',
        lazy=False,
        # order_by=desc(Symptom.score)
        order_by=[Symptom.id, desc(Symptom.score)]
    )
)


symptom_fields = {
    'name': fields.String,
    'score': fields.Float,
    'enname': fields.String,
}