from flask_restful import fields

from ExaminationModalApi import db


class AdminUser(db.Model):
    __bind_key__ = 'admin'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, index=True)
    name = db.Column(db.Unicode(10))
    password = db.Column(db.String(100))

    access_privileges = db.relationship('AdminCategory', secondary='admin_access_privilege')
    modify_privileges = db.relationship('AdminCategory', secondary='admin_modify_privilege')

    @property
    def privileges(self):
        return {
            'access': list(p.slug for p in self.access_privileges),
            'modify': list(p.slug for p in self.modify_privileges),
        }

    def has_access_privilege(self, slug):
        return slug in set(p.slug for p in self.access_privileges)

    def has_modify_privilege(self, slug):
        return slug in set(p.slug for p in self.modify_privileges)

    @classmethod
    def by_username(cls, username):
        return cls.query.filter(cls.username == username).first()


admin_user_fields = {
    'id': fields.Integer,
    'username': fields.String,
    'name': fields.String,
    'privileges': fields.Nested({
        'access': fields.List(fields.String),
        'modify': fields.List(fields.String),
    })
}
