from datetime import datetime, timedelta

from ExaminationModalApi import db
from ExaminationModalApi.model.photo_thumb import PhotoThumb
from .util import from_dict


class Photo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    owner = db.relationship('User', uselist=False)

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'))
    agency = db.relationship('Agency', uselist=False)

    oss_id = db.Column(db.String(1024))
    upload_time = db.Column(db.DateTime(timezone=False))

    from_dict = classmethod(from_dict)

    def get_thumb(self, bucket, style, lifetime=30 * 24 * 3600):
        new = False
        changed = False
        now = datetime.utcnow()
        thumb = self.thumb
        if not thumb or thumb.valid_till < now + timedelta(days=0, seconds=3600) or thumb.style != style:
            if not thumb:
                thumb = PhotoThumb(photo=self)
                new = True
            url = bucket.get_thumb_url(self.oss_id, style, lifetime=lifetime)
            thumb.style = style
            thumb.url = url
            thumb.valid_till = now + timedelta(days=0, seconds=lifetime)
            changed = True
        return thumb, new, changed

    def get_thumb_url(self, session, bucket, style, lifetime=30 * 24 * 3600):
        thumb, new, changed = self.get_thumb(bucket, style, lifetime)
        should_commit = any([new, changed])
        if new:
            session.add(thumb)
        return thumb.url, should_commit
