from ExaminationModalApi import db
from ExaminationModalApi.model.medical_condition import MedicalCondition


class MedicalHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'))
    report_id = db.Column(db.Integer, db.ForeignKey('report.id'))
    physical_report_id = db.Column(db.Integer, db.ForeignKey('physical_report.id'))
    condition_id = db.Column(db.Integer, db.ForeignKey('medical_condition.id'))


def medical_history(l):
    if not l:
        return None

    try:
        m = int(str(l), 10)
        condition = MedicalCondition.query.get(l)
        if not condition:
            raise ValueError('%d is not a valid condition id')

        return condition
    except ValueError:
        raise
    except Exception:
        raise ValueError('each medical_history item must be an integer')