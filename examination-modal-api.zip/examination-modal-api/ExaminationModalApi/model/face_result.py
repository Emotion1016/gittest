from flask_restful import fields
from urllib.parse import quote_plus
from sqlalchemy import text

from ExaminationModalApi import db, app
from .util import from_dict, BelongsToUserMixin, BelongsToAgencyMixin
from ExaminationModalApi.content_loader.storage import CONTENT_FACE_RESULT
from ExaminationModalApi.util import https_for

content = app.content_storage.content
face_info = content[CONTENT_FACE_RESULT]


class FaceResult(db.Model, BelongsToUserMixin, BelongsToAgencyMixin):
    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    owner = db.relationship('User', uselist=False)

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'), nullable=True)
    agency = db.relationship('Agency', uselist=False)

    photo_id = db.Column(db.Integer, db.ForeignKey('photo.id'), nullable=False)
    photo = db.relationship('Photo', uselist=False)

    time = db.Column(db.DateTime(timezone=False))

    algorithm_version_id = db.Column(db.Integer, db.ForeignKey('version.id'), nullable=False)
    algorithm_version = db.relationship('Version')

    diagnosis_raw = db.Column(db.Integer())

    face_L = db.Column(db.Integer())
    face_a = db.Column(db.Integer())
    face_b = db.Column(db.Integer())

    gloss = db.Column(db.Float())
    less_gloss = db.Column(db.Float())
    none_gloss = db.Column(db.Float())

    lip_L = db.Column(db.Integer())
    lip_a = db.Column(db.Integer())
    lip_b = db.Column(db.Integer())

    faceDetectRes = db.Column(db.Integer())
    faceColor = db.Column(db.Integer())
    faceGloss = db.Column(db.Integer())
    lipDetectRes = db.Column(db.Integer())
    lipColor = db.Column(db.Integer())

    face_recognize_tag = db.Column(db.Integer(), nullable=True, index=True)
    mark = db.Column(db.Integer, default=0, server_default=text('0'))

    channel = db.Column(db.String(100))
    client_info = db.Column(db.String(1000))
    sn = db.Column(db.String(100))

    from_dict = classmethod(from_dict)

    @property
    def report_face_url(self):
        return https_for('report_face/' + quote_plus(str(self.id)), _frontpage=True, csr=self.agency.custom.code)

    @property
    def gloss_indicator(self):
        if self.gloss or self.less_gloss or self.none_gloss:
            return max([self.gloss, self.less_gloss, self.none_gloss])
        else:
            return 0

    @property
    def face_color_name(self):
        return ['面白', '面黑', '面红', '面黄', '面青', '正常'][self.faceColor] if self.faceColor is not None else None

    @property
    def face_gloss_name(self):
        return ['有光泽', '少光泽', '无光泽'][self.faceGloss] if self.faceGloss is not None else None

    @property
    def lip_color_name(self):
        return ['唇淡白', '唇淡红', '唇红', '唇暗红', '唇紫'][self.lipColor] if self.lipColor is not None else '未检测到唇'

    @property
    def face_color_info(self):
        info = face_info.get(self.face_color_name)
        return info[0] if info else None

    @property
    def face_gloss_info(self):
        info = face_info.get(self.face_gloss_name)
        return info[0] if info else None

    @property
    def lip_color_info(self):
        info = face_info.get(self.lip_color_name)
        return info[0] if info else None

    @property
    def lab_define(self):
        return 'Lab颜色模型基于人对颜色的感觉。Lab中的数值描述正常视力的人能够看到的所有颜色。因为Lab描述的是颜色的显示方式，而不是设备(如显示器、桌面打印机或数码相机)生成颜色所需的特定色料的数量，所以Lab被视为与设备无关的颜色模型。颜色 色彩管理系统使用Lab作为色标，以将颜色从一个色彩空间转换到另一个色彩空间。Lab色彩模型是由亮度(L)和有关色彩的a, b三个要素组成。L表示亮度(Luminosity)，a表示从洋红色至绿色的范围，b表示从黄色至蓝色的范围。所有的颜色就以这三个值交互变化所组成。'


basic_face_result_fields = {
    'id': fields.Integer,
    'report_face_url': fields.String,
    'detectRes': fields.Integer(attribute='faceDetectRes'),
    'faceDetectRes': fields.Integer,
    'faceColor': fields.Integer,
    'faceGloss': fields.Integer,
    'lipDetectRes': fields.Integer,
    'lipColor': fields.Integer,
    'face_L': fields.Integer,
    'face_a': fields.Integer,
    'face_b': fields.Integer,
    'gloss_indicator': fields.Float(attribute='gloss_indicator'),
    'lip_L': fields.Integer,
    'lip_a': fields.Integer,
    'lip_b': fields.Integer,
    'face_color_info': fields.Raw,
    'face_gloss_info': fields.Raw,
    'lip_color_info': fields.Raw,
    'lab_define': fields.String,
}

basic_face_result_fields_with_url = dict(basic_face_result_fields)
basic_face_result_fields_with_url.update({
    'photo_url': fields.String
})
