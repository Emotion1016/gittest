import enum
from datetime import datetime
from typing import Tuple

from sqlalchemy import desc

from .. import db, bcrypt


class Scope(enum.Enum):
    register = 1
    reset_password = 2
    login = 3


class VerificationCode(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cellphone = db.Column(db.String(32), index=True)
    code = db.Column(db.String(100))
    scope = db.Column(db.Enum(Scope))
    created_at = db.Column(db.DateTime(timezone=False))
    valid_till = db.Column(db.DateTime(timezone=False))
    invalid = db.Column(db.Boolean)

    @classmethod
    def check(cls, cellphone, code, scope) -> Tuple['VerificationCode', bool]:
        v = cls.query.filter(
            cls.cellphone == cellphone,
            cls.scope == scope,
        ).order_by(desc(cls.created_at)).first()

        code_ok = v and not v.invalid and v.valid_till > datetime.utcnow() and bcrypt.check_password_hash(v.code, code)
        return v, code_ok
