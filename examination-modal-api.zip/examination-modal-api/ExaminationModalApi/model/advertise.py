# -*- encoding: utf-8 -*-
from ExaminationModalApi import db, app

from datetime import datetime
from enum import Enum
from flask_restful import fields


class AdvertiseType(Enum):
    start_pic = 1
    carousel_map = 2
    carousel_map2 = 3
    video = 4


def head_video_image(url):
    if url:
        return url + '?x-oss-process=video/snapshot,t_3000,f_jpg,w_0,h_0,m_fast'
    else:
        return None


advertise_default = {
    '1': {
        'video': [
            {
                'name': '默认',
                'full_url': 'http://content-cdn.zhiyuntcm.com/相宜本草/video/xiangyibencao_hongjingtian_4M.mp4',
                'head_url': 'http://content-cdn.zhiyuntcm.com/相宜本草/video/xiangyibencao_hongjingtian_4M.mp4' +
                            '?x-oss-process=video/snapshot,t_3000,f_jpg,w_0,h_0,m_fast'
            }
        ],
        'carousel_map': [
            {
                'name': '全诊',
                'full_url': 'http://content-cdn.zhiyuntcm.com/advertise/全诊banner.png'
            },
        ],
        'carousel_map2': [
            {
                'name': '分诊',
                'full_url': 'http://content-cdn.zhiyuntcm.com/advertise/分诊banner.png'
            },
        ],
        'start_pic': []
    },
    '2': {
        'video': [],
        'carousel_map': [
            {
                'name': '全诊',
                'full_url': 'http://content-cdn.zhiyuntcm.com/advertise/体质辨识全诊banner.png'
            },
        ],
        'carousel_map2': [
            {
                'name': '分诊',
                'full_url': 'http://content-cdn.zhiyuntcm.com/advertise/体质辨识分诊banner.png'
            },
        ],
        'start_pic': []
    }
}


class Advertise(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    url = db.Column(db.String(1000))
    index_id = db.Column(db.Integer)
    is_show = db.Column(db.Boolean)
    type = db.Column(db.Enum(AdvertiseType))
    create_time = db.Column(db.DateTime, default=datetime.now)

    custom_id = db.Column(db.Integer, db.ForeignKey('custom.id'))

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'))
    category = db.Column(db.Integer)

    @property
    def full_url(self):
        if not self.url:
            return ''

        if self.type.name == 'video':
            host = app.config['CONTENT_ASSET_URL_PREFIX']
        elif self.url and self.url.startswith('/advertise'):
            host = app.config['CONTENT_ASSET_URL_PREFIX']
        else:
            host = app.config['ZHIYUN_ADMIN_URL']
        return host + self.url

    @property
    def head_url(self):
        if self.type.name == 'video':
            return head_video_image(self.full_url)
        else:
            return None


advertise_fields = {
    'name': fields.String,
    'url': fields.String(attribute='full_url'),
    'head_url': fields.String
}
