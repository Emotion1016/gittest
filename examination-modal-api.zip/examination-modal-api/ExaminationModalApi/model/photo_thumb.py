from ExaminationModalApi import db


class PhotoThumb(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    photo_id = db.Column(db.Integer, db.ForeignKey('photo.id'), nullable=False)
    photo = db.relationship('Photo', uselist=False, backref=db.backref('thumb', uselist=False))

    url = db.Column(db.String(1024), nullable=False)
    valid_till = db.Column(db.DateTime(timezone=False), nullable=False)
    style = db.Column(db.String(512), nullable=True)
