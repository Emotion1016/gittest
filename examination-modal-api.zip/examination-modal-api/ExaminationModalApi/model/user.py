from flask_restful import fields

from ExaminationModalApi import db
from ExaminationModalApi.model.util import Gender, calculate_age
from datetime import datetime


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Unicode(128))
    password = db.Column(db.String(100))

    avatar = db.Column(db.String(512))
    birthday = db.Column(db.Date())
    gender = db.Column(db.Enum(Gender))
    cellphone = db.Column(db.String(32), unique=True)

    height = db.Column(db.Integer())
    weight = db.Column(db.Integer())

    create_time = db.Column(db.DateTime(timezone=False), default=datetime.now)

    channel = db.Column(db.String(100))

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'), nullable=True)
    agency = db.relationship('Agency', uselist=False, backref=db.backref('users', lazy=True))

    vendor_id = db.Column(db.Integer, db.ForeignKey('vendor.id'), nullable=True)
    vendor = db.relationship('Vendor', uselist=False, backref=db.backref('users', lazy='dynamic'))

    age_range = db.Column(db.String(32))
    stage = db.Column(db.String(32))

    medical_history = db.relationship('MedicalCondition', secondary='medical_history')

    idcard = db.Column(db.String(32))
    ages = db.Column(db.Integer())

    @property
    def display_birthday(self):
        if self.birthday:
            return self.birthday.isoformat()
        return None

    @property
    def age(self):
        return calculate_age(self.birthday)

    @property
    def report_num(self):
        return self.reports.count()

    @property
    def gender_value(self):
        return self.gender.value

    @property
    def medical_history_keys(self):
        return [x.id for x in self.medical_history]

    def update_info(self, new_info):
        for item in ['weight', 'height', 'stage', 'age_range', 'gender', 'idcard', 'name']:
            if new_info.get(item) is not None:
                setattr(self, item, new_info.get(item))


simple_user_fields = {
    'name': fields.String,
    'birthday': fields.String(attribute='display_birthday'),
    'gender': fields.Integer(attribute='gender_value'),
    'height': fields.Integer,
    'weight': fields.Integer,
    'medical_history': fields.List(fields.Integer, attribute='medical_history_keys'),
    'cellphone': fields.String,
    'age': fields.Integer,
    'avatar': fields.String,
    'report_num': fields.Integer,
    'age_range': fields.String,
    'stage': fields.String,
    'signed': fields.Boolean,
    'sign_id': fields.Integer,
    'idcard': fields.String
}

simple_user_fields_with_id = simple_user_fields.copy()
simple_user_fields_with_id.update({'id': fields.Integer})


def to_gender(key):
    return Gender(int(key))
