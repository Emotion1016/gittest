from ExaminationModalApi import db

from flask_restful import fields
from datetime import datetime


class Problem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    problem_number = db.Column(db.Integer)
    problem_content = db.Column(db.String(100))
    custom_id = db.Column(db.Integer, db.ForeignKey('custom.id'))
    custom = db.relationship('Custom')


class ProblemOption(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    option = db.Column(db.String(10))
    option_content = db.Column(db.String(100))
    problem_id = db.Column(db.Integer, db.ForeignKey('problem.id'))
    problem = db.relationship('Problem', backref=db.backref('problem_options', lazy='select',
                                                            order_by=option))


class ProblemResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    owner = db.relationship('User', uselist=False)

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'))
    agency = db.relationship('Agency', uselist=False)

    time = db.Column(db.DateTime(timezone=False), default=datetime.utcnow)

    problem_id = db.Column(db.Integer, db.ForeignKey('problem.id'))
    problem = db.relationship('Problem')

    problem_option_id = db.Column(db.Integer, db.ForeignKey('problem_option.id'))
    problem_option = db.relationship('ProblemOption')

    report_id = db.Column(db.Integer, db.ForeignKey('report.id'), nullable=True)
    report = db.relationship('Report', uselist=False, backref=db.backref('problem_results', uselist=True, lazy='dynamic'))


problem_option_fields = {
    'problem_option_id': fields.Integer(attribute='id'),
    'option': fields.String,
    'option_content': fields.String,
}


problem_fields = {
    'id': fields.Integer,
    'problem_number': fields.Integer,
    'problem_content': fields.String,
    'problem_options': fields.List(fields.Nested(problem_option_fields))
}


def to_problem_options(l):
    '''A method for deal with problem options.
    :param l: [{'problem_id': 1, {'problem_option_ids': [1,2]}}]
    :return: problem option object list
    '''

    if not l:
        return None

    try:
        problem_options = ProblemOption.query.filter(ProblemOption.id.in_(l['problem_option_ids'])).all()
        if not problem_options:
            raise ValueError('%d is not a valid condition id')
        return problem_options

    except Exception:
        raise ValueError('each medical_history item must be an integer')