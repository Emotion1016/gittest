from ExaminationModalApi import db


class AdminModifyPrivilege(db.Model):
    __bind_key__ = 'admin'
    id = db.Column(db.Integer, primary_key=True)
    admin_user_id = db.Column(db.Integer, db.ForeignKey('admin_user.id'))
    admin_category_id = db.Column(db.Integer, db.ForeignKey('admin_category.id'))
