from ExaminationModalApi import db

from flask_restful import fields
import json


class QuestionResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    owner = db.relationship('User', uselist=False)

    agency_id = db.Column(db.Integer, db.ForeignKey('agency.id'))
    agency = db.relationship('Agency', uselist=False)

    time = db.Column(db.DateTime(timezone=False))

    question_version_id = db.Column(db.Integer, db.ForeignKey('version.id'), nullable=False)
    question_version = db.relationship('Version')

    answer = db.Column(db.UnicodeText())
    category = db.Column(db.Integer)

    @property
    def answer_list(self):
        return json.loads(self.answer) if self.answer else []


question_fields = {
    'id': fields.Integer,
    'owner_id': fields.Integer,
    'agency_id': fields.Integer,
    'time': fields.DateTime,
    'answers': fields.Raw(attribute='answer_list')
}