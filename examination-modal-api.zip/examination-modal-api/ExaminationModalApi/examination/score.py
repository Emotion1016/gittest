# -*- encoding: utf-8 -*-
from datetime import datetime
from eacal import EACal
import pytz
from functools import reduce
import random

from ExaminationModalApi.examination.pipeline import stage

HEALTH_STATUS_HEALTHY = 0
HEALTH_STATUS_SUB_HEALTHY = 1
HEALTH_STATUS_SICK = 2

HEALTH_STATUS_NAMES = {
    HEALTH_STATUS_HEALTHY: '健康',
    HEALTH_STATUS_SUB_HEALTHY: '亚健康',
    HEALTH_STATUS_SICK: '可能有疾病',
}


def locate_term(report_time):
    report_date = report_time.date()
    c = EACal(zh_s=True)
    calendar = c.get_annual_solar_terms(report_time.year)
    # January may need the info of last December
    if report_date.month <= 1:
        calendar = c.get_annual_solar_terms(report_date.year - 1)[-3::] + calendar

    def keep_term(last, current):
        term_date = current[2].date()
        term = current[2]
        if term_date <= report_date:
            # find the nearest term
            return current
        # otherwise, keep the last nearest term
        return last

    last_term = reduce(keep_term, calendar)
    display_time = datetime.strftime(report_time, "%Y-%m-%d %H:%M")
    days = (report_date - last_term[2].date()).days

    if days:
        display_time += ' %s过%d天' % (last_term[0], days)
    else:
        display_time += ' %s' % (last_term[0],)
    return display_time


@stage(150, _type=[1, 2, 3], output_whitelist=('report_time', 'display_time'))
def add_report_time(params):
    report_time = datetime.utcnow()
    china_time = report_time.replace(tzinfo=pytz.utc).astimezone(pytz.timezone('Asia/Shanghai'))
    display_time = locate_term(china_time)
    params['report_time'] = report_time
    params['display_time'] = display_time
    return params


@stage(100, _type=1)
def resolve_conflict_symptoms(params):
    yinxu = None
    yangxu = None
    for s in params['status']:
        if s['name'] == u'阴虚':
            yinxu = s
        elif s['name'] == u'阳虚':
            yangxu = s
    if yinxu['exist'] and yangxu['exist']:
        lighter = yinxu if yinxu['score'] < yangxu['score'] else yangxu
        lighter['exist'] = False

    return params


@stage(100, _type=2)
def resolve_conflict_symptoms_2(params):
    for s in params['status']:
        if s['name'] == u'阴虚质':
            yinxu = s
        elif s['name'] == u'阳虚质':
            yangxu = s
        elif s['name'] == u'痰湿质':
            tanshi = s
        elif s['name'] == u'湿热质':
            shire = s

    if yinxu['exist'] and yangxu['exist']:
        lighter = yinxu if yinxu['score'] < yangxu['score'] else yangxu
        lighter['exist'] = False
    if tanshi['exist'] and shire['exist']:
        lighter = tanshi if tanshi['score'] < shire['score'] else shire
        lighter['exist'] = False

    return params


@stage(100, _type=3)
def resolve_conflict_symptoms_3(params):
    yinxu = None
    yangxu = None
    for s in params['status']:
        if s['name'] == u'阴虚':
            yinxu = s
        elif s['name'] == u'阳虚':
            yangxu = s
    if yinxu['exist'] and yangxu['exist']:
        lighter = yinxu if yinxu['score'] < yangxu['score'] else yangxu
        lighter['exist'] = False

    return params


@stage(100, _type=1,
       output_whitelist=('total_score', 'health_status_index', 'health_status_text', 'symptoms', 'symptom_status'))
def question_answer_helper(params):
    final = {}
    total_score = 0
    status = sorted(filter(lambda e: e['exist'], params['status']), key=lambda v: v['score'], reverse=True)
    d = 0.5
    f = 0.3
    ff = 0.75
    if params['healthy'] or not len(status):
        index = HEALTH_STATUS_HEALTHY
        total_score = params['healthy_score']
        list_normal = ['D', 'D', 'D', 'D', 'E', 'B', 'D', 'B']
        for i in range(8):
            # print(params['answers_map'][i+1])
            if params['answers_map'][i + 1] != [] and params['answers_map'][i + 1][0] != list_normal[i]:
                total_score = 90
    elif len(status) == 1:
        a = 0.5
        index = HEALTH_STATUS_SUB_HEALTHY
        if status[0]['score'] == 80:
            total_score = float(60)
        elif status[0]['name'] == u'气虚' and status[0]['score'] == 20:
            total_score = float('%.2f' % (90 - 20 / 10 * a))
        elif status[0]['name'] == u'痰湿' and status[0]['score'] == 30:
            total_score = float('%.2f' % (90 - 30 / 10 * a))
        elif status[0]['score'] <= 34:
            total_score = float('%.2f' % (90 - abs(status[0]['score'] - 20 * d)))
        elif 34 < status[0]['score'] < 60:
            total_score = float('%.2f' % (90 - (status[0]['score'] / 2) * f))
        elif 60 <= status[0]['score'] < 80:
            total_score = float('%.2f' % (90 - (status[0]['score'] / 2) * ff))
    elif 2 <= len(status) <= 4:
        if 3 <= len(status) and status[2]['score'] == 80:
            index = HEALTH_STATUS_SICK
            total_score = float('%.2f' % (60 - (10 * d)))
        elif 2 <= len(status) and (status[0]['score'] == 80 or status[1]['score'] == 80):
            index = HEALTH_STATUS_SUB_HEALTHY
            total_score = float(60)
        else:
            index = HEALTH_STATUS_SUB_HEALTHY
            if status[0]['score'] <= 34:
                total_score = float('%.2f' % (90 - abs(status[0]['score'] - 20 * d)))
            elif 34 < status[0]['score'] < 60:
                total_score = float('%.2f' % (90 - (status[0]['score'] / 2) * f))
            elif 60 <= status[0]['score'] < 80:
                total_score = float('%.2f' % (90 - (status[0]['score'] / 2) * ff))
    else:
        index = HEALTH_STATUS_SICK
        total_score = float('%.2f' % (60 - (status[0]['score'] / 8) * d))

    params['total_score'] = total_score
    params['health_status_index'] = index
    params['health_status_text'] = HEALTH_STATUS_NAMES[index]
    # keep the top 3 symptoms
    status = status[0:min([len(status), 3])]
    params['symptoms'] = [{'name': s['name'], 'score': s['score'], 'exist': s['exist']} for s in status]
    # params['status'] = status
    params['symptom_status'] = [
        {
            'name': s['name'],
            'score': s['score'] if s['exist'] else 0,
            'exist': s['exist']
        } for s in params['status']]
    return params


@stage(100, _type=2, output_whitelist=('total_score', 'symptoms', 'symptom_status', 'status'))
def generate_physical(params):
    pinghe = list(filter(lambda e: e['name'] == '平和质', params['status']))[0]
    status = list(filter(lambda e: e['name'] != '平和质', params['status']))
    status = sorted(status, key=lambda v: v['score'], reverse=True)
    status = sorted(status, key=lambda v: v['exist'], reverse=True)

    if status[0]['exist']:
        if status[1]['exist']:
            symptoms = status[:2]
        else:
            symptoms = status[:1]
    else:
        symptoms = list()
        symptoms.append(pinghe)
        symptoms.append(status[0])

    symptoms_name = list(map(lambda x: x['name'], symptoms))

    params['symptoms'] = [
        {
            'name': s['name'],
            'score': s['score'],
            'exist': s['exist']
        } for s in symptoms]
    other = [
        {
            'name': s['name'],
            'score': s['score'],
            'exist': s['exist']
        } for s in params['status'] if s['name'] not in symptoms_name]

    params['symptom_status'] = params['symptoms'] + other

    return params


@stage(100, _type=3,
       output_whitelist=('total_score', 'health_status_index', 'health_status_text', 'symptoms', 'symptom_status'))
def question_answer_helper_3(params):
    final = {}
    total_score = 0
    status = sorted(filter(lambda e: e['exist'], params['status']), key=lambda v: v['score'], reverse=True)
    d = 0.5
    f = 0.3
    ff = 0.75
    if params['healthy'] or not len(status):
        index = HEALTH_STATUS_HEALTHY
        total_score = params['healthy_score']
        list_normal = ['B','D','C','D','D','B','B','E','B','B','B','D','B']
        for i in range(13):
            # print(params['answers_map'][i+1])
            if params['answers_map'][i + 1] != [] and params['answers_map'][i + 1][0] != list_normal[i]:
                total_score = 90
    elif len(status) == 1:
        a = 0.5
        index = HEALTH_STATUS_SUB_HEALTHY
        if status[0]['score'] == 80:
            total_score = float(60)
        elif status[0]['name'] == u'气虚' and status[0]['score'] == 20:
            total_score = float('%.2f' % (90 - 20 / 10 * a))
        elif status[0]['name'] == u'痰湿' and status[0]['score'] == 30:
            total_score = float('%.2f' % (90 - 30 / 10 * a))
        elif status[0]['score'] <= 34:
            total_score = float('%.2f' % (90 - abs(status[0]['score'] - 20 * d)))
        elif 34 < status[0]['score'] < 60:
            total_score = float('%.2f' % (90 - (status[0]['score'] / 2) * f))
        elif 60 <= status[0]['score'] < 80:
            total_score = float('%.2f' % (90 - (status[0]['score'] / 2) * ff))
    elif 2 <= len(status) <= 4:
        if 3 <= len(status) and status[2]['score'] == 80:
            index = HEALTH_STATUS_SICK
            total_score = float('%.2f' % (60 - (10 * d)))
        elif 2 <= len(status) and (status[0]['score'] == 80 or status[1]['score'] == 80):
            index = HEALTH_STATUS_SUB_HEALTHY
            total_score = float(60)
        else:
            index = HEALTH_STATUS_SUB_HEALTHY
            if status[0]['score'] <= 34:
                total_score = float('%.2f' % (90 - abs(status[0]['score'] - 20 * d)))
            elif 34 < status[0]['score'] < 60:
                total_score = float('%.2f' % (90 - (status[0]['score'] / 2) * f))
            elif 60 <= status[0]['score'] < 80:
                total_score = float('%.2f' % (90 - (status[0]['score'] / 2) * ff))
    else:
        index = HEALTH_STATUS_SICK
        total_score = float('%.2f' % (60 - (status[0]['score'] / 8) * d))

    params['total_score'] = total_score
    params['health_status_index'] = index
    params['health_status_text'] = HEALTH_STATUS_NAMES[index]
    # keep the top 3 symptoms
    status = status[0:min([len(status), 3])]
    params['symptoms'] = [{'name': s['name'], 'score': s['score'], 'exist': s['exist']} for s in status]
    # params['status'] = status
    params['symptom_status'] = [
        {
            'name': s['name'],
            'score': s['score'] if s['exist'] else 0,
            'exist': s['exist']
        } for s in params['status']]
    return params
