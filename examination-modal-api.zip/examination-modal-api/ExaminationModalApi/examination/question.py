# -*- encoding: utf-8 -*-
from .pipeline import stage
from collections import defaultdict


@stage(10, _type=[1, 2, 3])
def question_answer_helper(params):
    params['answers_map'] = answers = defaultdict(lambda: [])
    for q in params['answers']:
        answers[int(q['id'], 10)] = q['answer']

    def answer_accessor(checker):
        value = checker[-1]
        id_ = int(checker[0:len(checker) - 1], 10)
        return value in answers[id_]
    params['_check_answer'] = answer_accessor
    return params

