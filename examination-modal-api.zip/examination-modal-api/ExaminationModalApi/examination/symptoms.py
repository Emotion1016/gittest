# -*- encoding: utf-8 -*-

from . import modal
from .pipeline import stage

VALID_TONGUE_SYMPTOMS = (
    u'舌体淡或胖',
    u'舌体淡且胖',
    u'舌红少苔',
    u'苔厚腻或腻',
    u'舌质偏暗',
    u'舌体淡',
    u'淡红舌',
    u'薄苔',
    u'白苔',
    u'薄白苔',
    u'舌正常',
    u'苔黄腻或黄厚腻',
)

VALID_FACE_SYMPTOMS = (
    u'面色白或恍白',
    u'面色黄或萎黄',
    u'面色正常',
    u'有光泽',
    u'口唇淡红',
    u'面正常',
    u'口唇暗红',
    u'口唇青紫',
    u'面色晦黯',
)


def coerce_compare(a, b):
    return str(a) == str(b)


@stage(10, _type=[1, 2, 3])
def tongue_symptom(params):
    params[u'舌体淡或胖'] = coerce_compare(params['tongueNatureColor'], modal.TONGUE_NATURE_COLOR_LIGHT_WHITE) or \
                       coerce_compare(params['tongueFatThin'], modal.TONGUE_FAT_THIN_FAT)
    params[u'舌体淡且胖'] = coerce_compare(params['tongueNatureColor'], modal.TONGUE_NATURE_COLOR_LIGHT_WHITE) and \
                       coerce_compare(params['tongueFatThin'], modal.TONGUE_FAT_THIN_FAT)
    params[u'舌红少苔'] = coerce_compare(params['tongueNatureColor'], modal.TONGUE_NATURE_COLOR_RED) and \
                      coerce_compare(params['tongueCoatThickness'], modal.TONGUE_COAT_THICKNESS_THIN)
    params[u'苔厚腻或腻'] = coerce_compare(params['tongueCoatThickness'], modal.TONGUE_COAT_THICKNESS_THICK)
    params[u'舌质偏暗'] = coerce_compare(params['tongueNatureColor'], modal.TONGUE_NATURE_COLOR_DARK_RED)
    params[u'舌体淡'] = str(params['tongueNatureColor']) in (
        str(modal.TONGUE_NATURE_COLOR_REDDISH), str(modal.TONGUE_NATURE_COLOR_LIGHT_WHITE))
    params[u'淡红舌'] = coerce_compare(params['tongueNatureColor'], modal.TONGUE_NATURE_COLOR_REDDISH)
    params[u'薄苔'] = coerce_compare(params['tongueCoatThickness'], modal.TONGUE_COAT_THICKNESS_THIN)
    params[u'白苔'] = coerce_compare(params['tongueCoatColor'], modal.TONGUE_COAT_COLOR_WHITE)
    params[u'薄白苔'] = coerce_compare(params['tongueCoatThickness'], modal.TONGUE_COAT_THICKNESS_THIN) and coerce_compare(
        params['tongueCoatColor'], modal.TONGUE_COAT_COLOR_WHITE)
    params[u'舌正常'] = coerce_compare(params['tongueCrack'], modal.TONGUE_CRACKED_NONE) and coerce_compare(
        params['tongueFatThin'], modal.TONGUE_FAT_THIN_NORMAL)
    params[u'苔黄腻或黄厚腻'] = coerce_compare(params['tongueCoatThickness'], modal.TONGUE_COAT_THICKNESS_THICK) \
                         and coerce_compare(params['tongueCoatColor'], modal.TONGUE_COAT_COLOR_YELLOW)

    def tongue_symptom_checker(symptom):
        assert symptom in VALID_TONGUE_SYMPTOMS, 'invalid tongue symptom name %s' % (symptom,)
        return params[symptom]

    params['_check_tongue'] = tongue_symptom_checker
    return params


@stage(10, _type=[1, 2, 3])
def face_symptom(params):
    params[u'面色白或恍白'] = coerce_compare(params['faceColor'], modal.FACE_COLOR_WHITE)
    params[u'面色黄或萎黄'] = coerce_compare(params['faceColor'], modal.FACE_COLOR_YELLOW)
    params[u'面色晦黯'] = coerce_compare(params['faceColor'], modal.FACE_COLOR_BLACK)
    params[u'面色正常'] = coerce_compare(params['faceColor'], modal.FACE_COLOR_NORMAL)
    params[u'有光泽'] = coerce_compare(params['faceGloss'], modal.FACE_GLOSS_NO)
    params[u'口唇淡红'] = coerce_compare(params['lipColor'], modal.LIP_COLOR_REDDISH)
    params[u'面正常'] = coerce_compare(params['faceColor'], modal.FACE_COLOR_NORMAL) and coerce_compare(
        params['faceGloss'], modal.FACE_GLOSS_NO) and coerce_compare(params['lipColor'], modal.LIP_COLOR_REDDISH)

    params[u'口唇暗红'] = coerce_compare(params['lipColor'], modal.LIP_COLOR_DARK_RED)
    params[u'口唇青紫'] = coerce_compare(params['lipColor'], modal.LIP_COLOR_PURPLE)

    def face_symptom_checker(symptom):
        assert symptom in params, 'invalid symptom name %s' % (symptom,)
        return params[symptom]

    params['_check_face'] = face_symptom_checker
    return params
