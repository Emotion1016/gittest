# -*- encoding: utf-8 -*-
from .pipeline import stage
from operator import itemgetter
import random


def _sum_exists(checker, weights, details=None):
    if details is None:
        details = list()
    calculation = [{'symptom': symptom, 'weight': weight} for symptom, weight in weights.items() if checker(symptom)]
    details.extend(
        calculation
    )
    return sum(map(itemgetter('weight'), calculation))


class Examination(object):
    answer_weight = {}
    critical_answers = []
    necessary_answers = []
    face_weight = {}
    critical_face_symptoms = []
    tongue_weight = {}
    critical_tongue_symptoms = []
    threshold = None
    name = ''
    critical_score = 0

    def __call__(self, params: dict):
        if not self.name:
            raise NotImplementedError('subclass must specify the "name" property')
        exist = False
        reason = ''
        detail = list()

        if self.necessary_answers and \
                not all(map(params['_check_answer'], self.necessary_answers)):
            exist = False
            reason = 'necessary answer(s) not fulfill'
        else:
            if any(map(params['_check_answer'], self.critical_answers)) or \
                    any(map(params['_check_face'], self.critical_face_symptoms)) or \
                    any(map(params['_check_tongue'], self.critical_tongue_symptoms)):
                exist = True
                reason = 'critical symptom'

            if not exist and self.threshold is not None:
                all_symptoms = len(
                    list(filter(bool, map(params['_check_answer'], self.answer_weight.keys())))
                ) + len(
                    list(filter(bool, map(params['_check_face'], self.face_weight.keys())))
                ) + len(
                    list(filter(bool, map(params['_check_tongue'], self.tongue_weight.keys())))
                )
                exist = all_symptoms >= self.threshold
                reason = 'symptom count %d' % (all_symptoms,)

        score = _sum_exists(
            params['_check_answer'], self.answer_weight, detail,
        ) + _sum_exists(
            params['_check_face'], self.face_weight, detail,
        ) + _sum_exists(
            params['_check_tongue'], self.tongue_weight, detail,
        )

        params.setdefault('status', list()).append({
            'name': self.name,
            'exist': exist,
            'score': score,
            'debug_detail': detail,
            'critical_score': self.critical_score,
            'debug_reason': reason,
        })
        return params


@stage(20, _type=1)
class QiXu(Examination):
    name = u'气虚'
    answer_weight = {
        '2A': 20,
        '2B': 12,
        '1A': 10,
        '5D': 8,
        '4C': 8,
        '7B': 7
    }
    critical_answers = ['2A']
    tongue_weight = {
        u'舌体淡或胖': 15,
    }
    threshold = 2


@stage(20, _type=1)
class YangXu(Examination):
    answer_weight = {
        '1A': 20,
        '3B': 12,
        '3C': 10,
        '2A': 6,
        '2B': 6,
        '4C': 6
    }
    face_weight = {
        '面色白或恍白': 5
    }
    tongue_weight = {
        u'舌体淡且胖': 15,
    }
    threshold = 3
    name = u'阳虚'


@stage(20, _type=1)
class YinXu(Examination):
    answer_weight = {
        '1C': 30,
        '2C': 14,
        '3A': 10,
        '6A': 6
    }
    critical_answers = ['1C']
    tongue_weight = {
        u'舌红少苔': 20,
    }
    threshold = 2
    name = u'阴虚'


@stage(20, _type=1)
class TanShi(Examination):
    answer_weight = {
        '5C': 16,
        '5A': 14,
        '4B': 20,
    }
    tongue_weight = {
        u'苔厚腻或腻': 30
    }
    critical_tongue_symptoms = [u'苔厚腻或腻']
    threshold = 2
    name = u'痰湿'


@stage(20, _type=1)
class YuZhi(Examination):
    answer_weight = {
        '6A': 30,
        '7A': 14,
        '7C': 18
    }
    critical_answers = ['6A']
    tongue_weight = {
        u'舌质偏暗': 18,
    }
    threshold = 2
    name = u'郁滞'


@stage(20, _type=1)
class PiXu(Examination):
    answer_weight = {
        '4C': 20,
        '7B': 20
    }
    tongue_weight = {
        u'舌体淡': 20,
    }
    face_weight = {
        u'面色黄或萎黄': 20
    }
    threshold = 2
    name = u'脾虚'


@stage(20, _type=1)
class ShenXu(Examination):
    answer_weight = {
        '8A': 26,
        '1A': 16,
        '3B': 15
    }
    necessary_answers = ['8A']
    face_weight = {
        u'面色白或恍白': 8,
    }
    tongue_weight = {
        u'舌体淡或胖': 15,
    }
    threshold = 2
    name = u'肾虚'


@stage(20, _type=1)
def healthy(params):
    score = 0
    no_symptom = not any(filter(lambda e: e['exist'], params['status']))
    is_healthy = no_symptom
    if is_healthy:
        c = 0.5
        if no_symptom:
            score += float(90)
        if params['_check_tongue'](u'淡红舌') and \
                params['_check_tongue'](u'薄白苔') and params['_check_tongue'](u'舌正常') and params['_check_face'](u'面正常'):
            score += float(10)
        else:
            if params['_check_tongue'](u'淡红舌') and \
                    params['_check_tongue'](u'薄白苔') and params['_check_tongue'](u'舌正常'):
                score += float('%.2f' % (10 - 4 * c))
            if params['_check_face'](u'面正常'):
                score += float('%.2f' % (10 - 6 * c))
    params['healthy'] = is_healthy
    params['healthy_score'] = float('%.2f' % score)
    return params
