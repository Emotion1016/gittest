# -*- encoding: utf-8 -*-
from .pipeline import stage
from operator import itemgetter
import random


def _sum_exists(checker, weights, details=None):
    if details is None:
        details = list()
    calculation = [{'symptom': symptom, 'weight': weight} for symptom, weight in weights.items() if checker(symptom)]
    details.extend(
        calculation
    )
    return sum(map(itemgetter('weight'), calculation))


class FemaleExamination(object):
    answer_weight = {}
    critical_answers = []
    necessary_answers = []
    face_weight = {}
    critical_face_symptoms = []
    tongue_weight = {}
    critical_tongue_symptoms = []
    threshold = None
    name = ''

    def __call__(self, params: dict):
        if not self.name:
            raise NotImplementedError('subclass must specify the "name" property')
        exist = False
        reason = ''
        detail = list()

        if self.necessary_answers and \
                not all(map(params['_check_answer'], self.necessary_answers)):
            exist = False
            reason = 'necessary answer(s) not fulfill'
        else:
            if any(map(params['_check_answer'], self.critical_answers)) or \
                    any(map(params['_check_face'], self.critical_face_symptoms)) or \
                    any(map(params['_check_tongue'], self.critical_tongue_symptoms)):
                exist = True
                reason = 'critical symptom'

            if not exist and self.threshold is not None:
                all_symptoms = len(
                    list(filter(bool, map(params['_check_answer'], self.answer_weight.keys())))
                ) + len(
                    list(filter(bool, map(params['_check_face'], self.face_weight.keys())))
                ) + len(
                    list(filter(bool, map(params['_check_tongue'], self.tongue_weight.keys())))
                )
                exist = all_symptoms >= self.threshold
                reason = 'symptom count %d' % (all_symptoms,)

        score = _sum_exists(
            params['_check_answer'], self.answer_weight, detail,
        ) + _sum_exists(
            params['_check_face'], self.face_weight, detail,
        ) + _sum_exists(
            params['_check_tongue'], self.tongue_weight, detail,
        )
        params.setdefault('status', list()).append({
            'name': self.name,
            'exist': exist,
            'score': score,
            'debug_detail': detail,
            'debug_reason': reason,
        })
        return params


@stage(20, _type=3)
class QiXu(FemaleExamination):
    name = u'气虚'
    answer_weight = {
        '1A': 20,
        '3A': 12,
        '2A': 10,
        '8D': 8,
        '5C': 8,
        '12B': 7
    }
    critical_answers = ['1A']
    tongue_weight = {
        u'舌体淡或胖': 15,
    }
    threshold = 2


@stage(20, _type=3)
class YangXu(FemaleExamination):
    answer_weight = {
        '2A': 20,
        '4B': 12,
        '4C': 10,
        '1A': 6,
        '3A': 6,
        '5C': 6
    }
    face_weight = {
        '面色白或恍白': 5
    }
    tongue_weight = {
        u'舌体淡且胖': 15,
    }
    threshold = 3
    name = u'阳虚'


@stage(20, _type=3)
class YinXu(FemaleExamination):
    answer_weight = {
        '2C': 20,
        '3B': 14,
        '7A': 10,
        '4A': 10,
        '11A': 6
    }
    tongue_weight = {
        u'舌红少苔': 20,
    }
    threshold = 2
    name = u'阴虚'


@stage(20, _type=3)
class TanShi(FemaleExamination):
    answer_weight = {
        '8C': 16,
        '8A': 14,
        '5B': 20,
    }
    tongue_weight = {
        u'苔厚腻或腻': 30
    }
    critical_tongue_symptoms = [u'苔厚腻或腻']
    threshold = 2
    name = u'痰湿'


@stage(20, _type=3)
class YuZhi(FemaleExamination):
    answer_weight = {
        '9A': 20,
        '11A': 10,
        '14A': 14,
        '12C': 18,
    }
    tongue_weight = {
        u'舌质偏暗': 18,
    }
    threshold = 2
    name = u'郁滞'


@stage(20, _type=3)
class PiXu(FemaleExamination):
    answer_weight = {
        '6A': 20,
        '5C': 15,
        '17A': 15,
    }
    tongue_weight = {
        u'舌体淡': 15,
    }
    face_weight = {
        u'面色黄或萎黄': 15
    }
    threshold = 2
    name = u'脾虚'


@stage(20, _type=3)
class ShenXu(FemaleExamination):
    answer_weight = {
        '13A': 20,
        '2A': 16,
        '4B': 15,
        '10A': 6,
        '17B': 15
    }
    necessary_answers = ['13A']
    tongue_weight = {
        u'舌体淡或胖': 8,
    }
    threshold = 2
    name = u'肾虚'


@stage(20, _type=3)
class XueXu(FemaleExamination):
    answer_weight = {
        '15A': 20,
        '16A': 15,
        '17A': 10,
        '10A': 15,
    }
    necessary_answers = ['15A', '16A']
    tongue_weight = {
        u'舌体淡': 10,
    }
    face_weight = {
        u'面色白或恍白': 10
    }
    threshold = 0
    name = u'血虚'


@stage(20, _type=3)
def healthy(params):
    score = 0
    no_symptom = not any(filter(lambda e: e['exist'], params['status']))
    is_healthy = no_symptom
    if is_healthy:
        c = 0.5
        if no_symptom:
            score += float(90)
        if params['_check_tongue'](u'淡红舌') and \
                params['_check_tongue'](u'薄白苔') and params['_check_tongue'](u'舌正常') and params['_check_face'](u'面正常'):
            score += float(10)
        else:
            if params['_check_tongue'](u'淡红舌') and \
                    params['_check_tongue'](u'薄白苔') and params['_check_tongue'](u'舌正常'):
                score += float('%.2f' % (10 - 4 * c))
            if params['_check_face'](u'面正常'):
                score += float('%.2f' % (10 - 6 * c))
    params['healthy'] = is_healthy
    params['healthy_score'] = float('%.2f' % score)
    return params

