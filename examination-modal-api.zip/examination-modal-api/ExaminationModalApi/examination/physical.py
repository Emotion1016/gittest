from ExaminationModalApi.examination.examination import _sum_exists, stage


def create_answer_weight(*arg):
    d = {}
    for i in arg:
        w = 0
        for j in 'ABCDE':
            d['%s%s' % (i, j)] = w
            w += 1
    return d


class PhysicalExamination(object):
    answer_weight = {}
    face_weight = {}
    critical_face_symptoms = []
    tongue_weight = {}
    critical_tongue_symptoms = []
    name = ''
    critical_score = 0
    exist_require = []

    def _symptom_exist_check(self, params):
        answers = params['answers_map']
        for i in self.exist_require:
            for _id in i:
                if type(_id) == int:
                    if 'D' not in answers[_id] and 'E' not in answers[_id]:
                        break
                else:
                    if params[_id] is False:
                        break

            else:
                return True

        return False

    def __call__(self, params: dict):
        if not self.name:
            raise NotImplementedError('subclass must specify the "name" property')
        reason = ''
        detail = list()

        score = _sum_exists(
            params['_check_answer'], self.answer_weight, detail,
        ) + _sum_exists(
            params['_check_face'], self.face_weight, detail,
        ) + _sum_exists(
            params['_check_tongue'], self.tongue_weight, detail,
        )

        exist = self._symptom_exist_check(params)

        params.setdefault('status', list()).append({
            'name': self.name,
            'exist': exist,
            'score': score,
            'debug_detail': detail,
            'critical_score': self.critical_score,
            'debug_reason': reason,
        })
        return params


@stage(20, _type=2)
class QiXuZhi(PhysicalExamination):
    name = u'气虚质'
    answer_weight = create_answer_weight(1, 2, 3)
    tongue_weight = {
        u'舌体淡或胖': 1,
    }
    exist_require = [
        [1, 2, 3],
        [1, 2, u'舌体淡或胖']
    ]
    critical_score = 11


@stage(20, _type=2)
class QiYuZhi(PhysicalExamination):
    name = u'气郁质'
    answer_weight = create_answer_weight(6, 7, 8, 24, 25)
    threshold = 0
    critical_score = 12
    exist_require = [
        [6, 7, 8],
        [6, 7, 24],
        [6, 7, 25],
        [6, 8, 24],
        [6, 8, 25],
        [7, 8, 24],
        [7, 8, 25]
    ]


@stage(20, _type=2)
class TanShiZhi(PhysicalExamination):
    name = u'痰湿质'
    answer_weight = create_answer_weight(9, 11, 18, 21)
    tongue_weight = {
        u'苔厚腻或腻': 4,
    }
    threshold = 0
    critical_score = 15
    exist_require = [
        [11, 18, 21],
        [11, 21, u'苔厚腻或腻']
    ]


@stage(20, _type=2)
class YinXuZhi(PhysicalExamination):
    name = u'阴虚质'
    answer_weight = create_answer_weight(5, 14, 17)
    # tongue_weight = {
    #     u'舌红少苔': 2,
    # }
    threshold = 0
    critical_score = 9
    exist_require = [
        [5, 14],
    ]


@stage(20, _type=2)
class YangXuZhi(PhysicalExamination):
    name = u'阳虚质'
    answer_weight = create_answer_weight(1, 3, 4, 22, 23)
    face_weight = {
        u'面色白或恍白': 1
    }
    tongue_weight = {
        u'舌体淡且胖': 2,
    }
    threshold = 0
    critical_score = 10
    exist_require = [
        [4, 22, 23],
        [4, 22, u'舌体淡且胖'],
        [4, 22, u'面色白或恍白']
    ]


@stage(20, _type=2)
class TeBingZhi(PhysicalExamination):
    name = u'特禀质'
    answer_weight = create_answer_weight(12, 19, 20)
    threshold = 0
    critical_score = 9
    exist_require = [
        [12, 19]
    ]


@stage(20, _type=2)
class XueYuZhi(PhysicalExamination):
    name = u'血瘀质'
    answer_weight = create_answer_weight(13)
    tongue_weight = {
        u'舌质偏暗': 2,
    }
    face_weight = {
        u'口唇暗红': 1,
        u'口唇青紫': 2,
    }
    threshold = 0
    critical_score = 7
    exist_require = [
        [13, u'舌质偏暗', u'口唇暗红'],
        [13, u'舌质偏暗', u'口唇青紫'],
    ]


@stage(20, _type=2)
class SiReZhi(PhysicalExamination):
    name = u'湿热质'
    answer_weight = create_answer_weight(10, 15, 16, 26, 27)
    tongue_weight = {
        u'苔黄腻或黄厚腻': 3,
    }
    threshold = 0
    critical_score = 16
    exist_require = [
        [10, 15, 16],
        [10, 15, u'苔黄腻或黄厚腻'],
        [10, 16, u'苔黄腻或黄厚腻'],
        [10, 26, u'苔黄腻或黄厚腻'],
        [10, 27, u'苔黄腻或黄厚腻'],
    ]


@stage(20, _type=2)
class PingHeZhi(PhysicalExamination):
    name = u'平和质'
    answer_weight = dict()
    for i in range(1, 28):
        answer_weight['%sA' % i] = 0.5

    face_weight = {
        u'面色正常': 0.5,
        u'有光泽': 0.5,
        u'口唇淡红': 0.5
    }

    tongue_weight = {
        u'薄苔': 0.5,
        u'白苔': 0.5,
        u'淡红舌': 0.5
    }
    threshold = 0
    critical_score = 20
