import random

from .. import app
from ..content_loader.storage import ALL_CONTENT_TYPES, solution_count, ALL_CONTENT_TYPES_TIZHI
from .pipeline import stage


def pick_solution(content, symptom, key_list=None, require_count=1):
    symptom_solution = content.get(symptom, None)
    if not symptom_solution:
        return None, None

    if key_list is None:
        have_count = len(symptom_solution)
        key_list = random.sample(
            range(have_count),
            min(have_count, require_count)
        )
    if require_count == 1:
        # for others
        if key_list[0] >= len(symptom_solution):
            return key_list, symptom_solution[0]
        else:
            return key_list, symptom_solution[key_list[0]]
    else:
        # for require_count > 1, example prescription
        return key_list, [symptom_solution[i] for i in key_list if i < len(symptom_solution)]


def load_solutions(symptoms, keys=None, type=1):
    solution_seed = dict()
    content = app.content_storage.content
    solutions = dict()
    if type == 1:
        content_type = ALL_CONTENT_TYPES
    else:
        content_type = ALL_CONTENT_TYPES_TIZHI
    for t in content_type:

        c = content.get(t, None)
        if not c:
            solutions[t] = None
            continue
        require_count = solution_count.get(t, 1)

        solution_seed.setdefault(t, dict())

        for symptom in (symptoms if len(symptoms) else [{'name': '健康'}, ]):
            name = symptom['name']

            if keys:
                # 如果报错，取第一个
                key_list = keys.setdefault(t, dict()).setdefault(name) or list(range(require_count))
                idx_list, s = pick_solution(c, name, key_list=key_list, require_count=require_count)
            else:
                idx_list, s = pick_solution(c, name, require_count=require_count)
            if idx_list:
                solutions.setdefault(t, dict())[name] = s
                solution_seed[t][name] = idx_list

    solutions['keys'] = solution_seed
    solutions['asset_prefix'] = app.config['CONTENT_ASSET_URL_PREFIX']
    return solutions


@stage(200, 1, output_whitelist=('solutions',))
def solution(params):
    params['solutions'] = load_solutions(params['symptoms'])
    return params


@stage(200, 2, output_whitelist=('solutions',))
def solution_tizhi(params):
    params['solutions'] = load_solutions(params['symptoms'], type=2)
    return params


@stage(200, 3, output_whitelist=('solutions',))
def solution_3(params):
    params['solutions'] = load_solutions(params['symptoms'])
    return params
