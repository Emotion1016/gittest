from inspect import isclass

from os import environ

REGISTERED_STAGES = {}
REGISTERED_STAGES_2 = {}
REGISTERED_STAGES_3 = {}
REGISTERED_CLASSES = {}
REGISTERED_CLASSES_2 = {}
REGISTERED_CLASSES_3 = {}
OUTPUT_WHITELIST = []
OUTPUT_WHITELIST_2 = []
OUTPUT_WHITELIST_3 = []


def register(order, _type, output_whitelist, f):
    if _type == 1:
        fun_stages = REGISTERED_STAGES
        cls_stages = REGISTERED_CLASSES
    elif _type == 2:
        fun_stages = REGISTERED_STAGES_2
        cls_stages = REGISTERED_CLASSES_2
    elif _type == 3:
        fun_stages = REGISTERED_STAGES_3
        cls_stages = REGISTERED_CLASSES_3
    else:
        fun_stages = REGISTERED_STAGES
        cls_stages = REGISTERED_CLASSES

    registered = fun_stages.setdefault(order, list())

    if isclass(f):
        if f in cls_stages.get(order, []):
            raise RuntimeWarning('Handler class %s has been registered to the same order %d' % (f, order))
        cls_stages.setdefault(order, list()).append(f)
        f = f()
    elif f in registered:
        raise RuntimeWarning('Handler %s has been registered to the same order %d' % (f, order))
    assert callable(f), 'handler must be callable'
    registered.append(f)
    if output_whitelist:
        if _type == 1:
            OUTPUT_WHITELIST.extend(output_whitelist)
        elif _type == 2:
            OUTPUT_WHITELIST_2.extend(output_whitelist)
        elif _type == 3:
            OUTPUT_WHITELIST_3.extend(output_whitelist)


def stage(order, _type, output_whitelist=None):
    def _decorator(f):
        if type(_type) is list:
            for t in _type:
                register(order, t, output_whitelist, f)
        else:
            register(order, _type, output_whitelist, f)
        return f
    return _decorator


def run(params, _type=1):
    if _type == 1:
        fun_stages = REGISTERED_STAGES
    elif _type == 2:
        fun_stages = REGISTERED_STAGES_2
    elif _type == 3:
        fun_stages = REGISTERED_STAGES_3
    else:
        fun_stages = REGISTERED_STAGES
    pool = fun_stages.keys()
    pool = sorted(pool)
    for order in pool:
        if order in fun_stages:
            for f in fun_stages[order]:
                params = f(dict(params))
    return params


@stage(9999, _type=[1, 2, 3])
def cleanup(params):
    return {k: v for k, v in params.items() if not k.startswith('_')}


@stage(99999, _type=1)
def apply_output_whitelist(params):
    if environ.get('DEBUG_DETAIL'):
        return params
    return {k: params[k] for k in OUTPUT_WHITELIST if k in params}


@stage(99999, _type=2)
def apply_output_whitelist_2(params):
    if environ.get('DEBUG_DETAIL'):
        return params
    return {k: params[k] for k in OUTPUT_WHITELIST_2 if k in params}


@stage(99999, _type=3)
def apply_output_whitelist_3(params):
    if environ.get('DEBUG_DETAIL'):
        return params
    return {k: params[k] for k in OUTPUT_WHITELIST_3 if k in params}
