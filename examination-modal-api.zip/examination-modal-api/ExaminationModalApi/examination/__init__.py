from . import pipeline, examination, question, symptoms, score, solution, physical, examination_female

run = pipeline.run