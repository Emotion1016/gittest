from datetime import datetime
from functools import wraps
from typing import Dict, Callable

import jwt as jwtlib
from flask import request, _request_ctx_stack, abort
from flask_jwt import jwt_required, current_identity, JWTError, _default_jwt_decode_handler
from werkzeug.local import LocalProxy

from ExaminationModalApi import jwt, app, db
from ExaminationModalApi.model.agency import Agency
from ExaminationModalApi.model.user import User
from ExaminationModalApi.model.wechat_account import WeChatAccount
from ExaminationModalApi.views.error_handlers import ExpiredJWTSignatureError

wechat_user = LocalProxy(lambda: getattr(_request_ctx_stack.top, 'wechat_user', None))
login_user = LocalProxy(lambda: getattr(_request_ctx_stack.top, 'login_user', None))
local_agency = LocalProxy(lambda: getattr(_request_ctx_stack.top, 'agency_user', None))
is_agency = LocalProxy(lambda: getattr(_request_ctx_stack.top, 'is_agency', None))
local_agency_type = LocalProxy(lambda: getattr(_request_ctx_stack.top, 'agency_type', None))

local_user = LocalProxy(lambda: getattr(_request_ctx_stack.top, 'end_user', None))


EXT_LOGIN_SOURCES = {}


def add_ext_login_sources(slug, s: Dict[str, Callable]):
    global EXT_LOGIN_SOURCES
    if slug in EXT_LOGIN_SOURCES:
        raise ValueError('slug %s has been taken by %r', slug, EXT_LOGIN_SOURCES[slug])
    required_keys = {'identity_handler', 'request_handler'}
    if set(s.keys()) != required_keys:
        raise ValueError('login source must contain following keys: %s' % (required_keys, ))
    EXT_LOGIN_SOURCES[slug] = s


def load_wechat_user(openid):
    account = WeChatAccount.query.filter(WeChatAccount.openid == openid).first()
    if not account:
        return None
    user = account.user
    app.logger.debug('user of openid %s: %r', openid, user)
    return user


def create_wechat_jwt_token(openid, nickname):
    iat = datetime.utcnow()
    exp = iat + app.config.get('JWT_EXPIRATION_DELTA')
    nbf = iat + app.config.get('JWT_NOT_BEFORE_DELTA')
    payload = {'exp': exp, 'iat': iat, 'nbf': nbf, "openid": openid, 'nickname': nickname}
    secret = app.config['JWT_SECRET_KEY']
    algorithm = app.config['JWT_ALGORITHM']
    jwt_token = jwtlib.encode(payload, secret, algorithm=algorithm)
    return jwt_token


def create_agency_jwt_token(iat: datetime, exp: datetime, nbf: datetime, agency : Agency):
    payload = {
        'exp': exp,
        'iat': iat,
        'nbf': nbf,
        'agency_id': agency.id,
        'type': agency.type,
        'update_time': agency.format_token_time
    }
    secret = app.config['JWT_SECRET_KEY']
    algorithm = app.config['JWT_ALGORITHM']
    jwt_token = jwtlib.encode(payload, secret, algorithm=algorithm)
    return jwt_token


def create_user_jwt_token(user: User):
    iat = datetime.utcnow()
    exp = iat + app.config.get('JWT_EXPIRATION_DELTA')
    nbf = iat + app.config.get('JWT_NOT_BEFORE_DELTA')
    payload = {'exp': exp, 'iat': iat, 'nbf': nbf, "user_id": user.id}
    secret = app.config['JWT_SECRET_KEY']
    algorithm = app.config['JWT_ALGORITHM']
    jwt_token = jwtlib.encode(payload, secret, algorithm=algorithm)
    return jwt_token


def _load_end_user():
    for_user = request.headers.get('X-ZHIYUN-API-FOR-USER', '')
    if not local_agency or local_agency.type != 'A':
        return None
    if for_user:
        # if not User.query.filter(User.cellphone == for_user).count():
        #     db.session.add(User(cellphone=for_user))
        #     db.session.commit()
        return User.query.filter(User.cellphone == for_user).first()
    return None


def token_user(agency: Agency):
    _request_ctx_stack.top.agency_type = agency.type if agency else None
    _request_ctx_stack.top.agency_user = agency
    _request_ctx_stack.top.is_agency = bool(agency)
    _request_ctx_stack.top.end_user = _load_end_user()

    ans = {
        'agency_type': _request_ctx_stack.top.agency_type,
        'agency_user': _request_ctx_stack.top.agency_user,
        'end_user': _request_ctx_stack.top.end_user
    }
    return ans


@jwt.identity_handler
def load_user(payload: dict):
    agency = None
    if not payload:
        pass
    if payload.get('api-token', dict()).get('agency_id', ''):
        agency = Agency.query.get(payload['api-token']['agency_id'])

    ans = token_user(agency=agency) or dict()

    for slug, source in EXT_LOGIN_SOURCES.items():
        if slug + '-token' not in payload:
            continue
        ans[slug] = source['identity_handler'](payload[slug + '-token'])
    app.logger.debug('user logged in: %s', ans)

    return ans


@jwt.request_handler
def load_jwt_token():
    global EXT_LOGIN_SOURCES
    ans = dict()
    if request.cookies and request.cookies.get('X-ZHIYUN-USER-TOKEN'):
        ans['login-token'] = request.cookies['X-ZHIYUN-USER-TOKEN']
    if request.headers and request.headers.get('X-ZHIYUN-USER-TOKEN'):
        ans['api-token'] = request.headers.get('X-ZHIYUN-USER-TOKEN')
    if request.cookies and request.cookies.get('jwt'):
        ans['wechat-token'] = request.cookies['jwt']
    if request.headers and request.headers.get('X-ZHIYUN-API-TOKEN'):
        ans['api-token'] = request.headers['X-ZHIYUN-API-TOKEN']
    if app.config.get('WECHAT_SIGN_IN_DEBUG', False) and 'wechat-token' not in ans:
        user = User.query.get(app.config.get('WECHAT_SIGN_IN_DEBUG_USER_ID', 1))
        ans['wechat-token'] = create_wechat_jwt_token(user.wechat.openid, user.name)
    for slug, source in EXT_LOGIN_SOURCES.items():
        ans[slug + '-token'] = source['request_handler']()
    if not ans:
        app.logger.warn('no jwt in cookie %r or header', request.cookies)
    return ans


def decode_one_jwt(token):
    try:
        return _default_jwt_decode_handler(token)
    except jwtlib.ExpiredSignatureError:
        raise ExpiredJWTSignatureError('JWT expired')
    except jwtlib.InvalidTokenError:
        return None


@jwt.jwt_decode_handler
def decode_jwt_tokens(tokens: dict):
    decoded = {k: decode_one_jwt(v) for k, v in tokens.items()}
    return {k: v for k, v in decoded.items() if v}


def wechat_user_required(realm=None):
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            if wechat_user is None or bool(local_agency_type):
                raise JWTError('token not refer to a wechat user', str(current_identity))
            return fn(*args, **kwargs)

        return jwt_required(realm)(decorator)
    return wrapper


def agency_required(realm=None):
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            if local_agency is None or not bool(local_agency):
                raise JWTError('token not refer to a agency', str(current_identity))
            if local_agency.del_flag == 1:
                raise ExpiredJWTSignatureError('agency expired')
            return fn(*args, **kwargs)

        return jwt_required(realm)(decorator)
    return wrapper


# A机构需要用户, B机构不需要, C机构不需要
def login_user_required(realm=None):
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            if local_agency is None or not bool(local_agency):
                raise JWTError('token not refer to a agency', str(current_identity))
            if local_agency_type == 'A' and (local_user is None or not bool(local_user)):
                raise JWTError('Agency A need a user', str(current_identity))
            return fn(*args, **kwargs)

        return jwt_required(realm)(decorator)
    return wrapper


# A机构需要用户, B机构不允许, C机构不需要
def end_user_required(realm=None):
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            if local_agency is None or not bool(local_agency):
                raise JWTError('token not refer to a agency', str(current_identity))
            if local_agency_type == 'B':
                raise JWTError('Agency B has no local user', str(current_identity))
            if local_agency_type == 'A' and (local_user is None or not bool(local_user)):
                raise JWTError('Agency A need a user', str(current_identity))
            return fn(*args, **kwargs)

        return jwt_required(realm)(decorator)
    return wrapper


def try_load_user():
    token = jwt.request_callback()

    if token is None:
        return None

    try:
        payload = jwt.jwt_decode_callback(token)
    except Exception:
        return None

    return jwt.identity_callback(payload)