from sys import exit

import click
from flask import url_for

from ExaminationModalApi import app, db
from ExaminationModalApi.model.report import Report
from ExaminationModalApi.model.share import Share


@app.cli.command(help='generate a share URL of a certain report')
@click.option('--key', default='', type=str, help='specify key ID, by default it will be automatically generated')
@click.argument('report-id', type=int)
def share_report(report_id, key):
    report = Report.query.get(report_id)
    if not report:
        click.echo(
            'cannot find report of ID %s' % (report_id, ),
            err=True,
        )
        exit(1)

    s = Share.create_and_commit(report, db, key)

    if s is None:
        click.echo('FAIL: cannot generate unique share id or duplicated key specified. Enlarge key length or specify '
                   'a unique key', err=True)
        exit(2)

    click.echo(
        'share link generated for report %s' % (report,)
    )
    click.echo(
        'API resource: %s' % (url_for('get_share', key=s.key, _external=False), )
    )
    click.echo(
        'Page URL: %s' % (s.url, )
    )
