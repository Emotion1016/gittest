import click
from flask.cli import AppGroup

from ExaminationModalApi import app, bcrypt, db
from ExaminationModalApi.model.agency import Agency

agency_cli = AppGroup('agency')


@agency_cli.command('create')
@click.argument('name')
@click.argument('password')
@click.option('--anonymous-report/--no-anonymous-report', default=False)
def create_agency(name, password, anonymous_report):
    click.echo('agency created')
    agency = Agency(
        key=name,
        name=name,
        login_name=name,
        password=bcrypt.generate_password_hash(password, 10),
        anonymous_report=bool(anonymous_report)
    )
    db.session.add(agency)
    db.session.commit()


app.cli.add_command(agency_cli)
