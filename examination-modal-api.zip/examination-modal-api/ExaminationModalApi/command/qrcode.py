from sys import exit

import click

from ExaminationModalApi import app, db
from ExaminationModalApi.model.agency import Agency
from ExaminationModalApi.model.channel import Channel
from ExaminationModalApi.model.qrcode import QRCode


@app.cli.command(help='create qrcode for specified agency and/or channel')
@click.option('--agency-id', default=-1, type=click.INT, help='ID of agency')
@click.option('--channel-id', default=-1, type=click.INT, help='ID of channel')
@click.argument('scene-id', type=click.INT, nargs=1)
def create_qrcode(agency_id, channel_id, scene_id):
    agency = None
    channel = None
    if agency_id > 0:
        agency = Agency.query.get(agency_id)
        if not agency:
            click.echo('cannot find agency of ID %s' % (agency_id, ), err=True)
            exit(1)

    if channel_id > 0:
        channel = Channel.query.get(channel_id)
        if not channel:
            click.echo('cannot find channel of ID %s' % (channel_id, ), err=True)
            exit(1)

    if scene_id <= 0 or scene_id > 100000:
        click.echo('illegal scene ID %s (must between 0 and 100000)' % (scene_id, ), err=True)

    click.echo(
        'creating qrcode for agency %s, channel %s, scene ID %s' % (
            agency, channel, scene_id
        )
    )
    click.pause()
    qrcode = QRCode.create(scene_id, agency and agency.id, channel and channel.id)
    click.echo(
        'QRCode created, ticket %s, url %s, image url: %s' % (
            qrcode.ticket, qrcode.url, qrcode.image_url,
        )
    )
    db.session.add(qrcode)
    db.session.commit()
