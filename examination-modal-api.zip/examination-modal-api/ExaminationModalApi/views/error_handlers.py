from flask import jsonify
import flask_restful
from flask_restful import abort

from ExaminationModalApi import app, api, jwt, api16_bp, api30_bp
import json


class ExpiredJWTSignatureError(Exception):
    pass


class ErrorCode:
    success = (10000, '请求成功')
    not_known = (10001, '未知错误')
    access_error = (10002, '权限验证失败')
    args_error = (10003, '参数错误')
    not_found = (10004, '找不到你想要的页面')
    expired_error = (10005, '权限验证过期')
    access_token_error = (10006, '非法的access token')

    vendor_not_exist = (10010, '无效的厂家码，请重新输入')
    vendor_expired = (100011, '厂家码已过期')
    vendor_not_match = (10012, '厂家码不正确')

    agency_exists = (100020, '该用户名已被注册')
    agency_not_exists = (10021, '该用户名未注册')
    agency_password_error = (10022, '机构账号密码不匹配')
    password_check_error = (10023, '密码错误，请重新输入')
    old_password_error = (10024, '原密码错误，请重新填写')
    agency_deleted = (10025, '账号已禁用')
    agency_permission_denied = (10026, '此账号仅适用于3.0及以上版本')

    cellphone_registered = (10031, '手机号已注册')
    cellphone_not_register = (10032, '手机号未注册')
    cellphone_illegal = (10034, '请输入正确手机号')

    photo_not_found = (10040, '缺少照片')
    photo_format_error = (10041, '格式错误')
    face_not_detected = (10042, '面诊失败, 请重新拍照')
    tongue_not_detected = (10043, '舌诊失败, 请重新拍照')
    picture_too_large = (10044, '图片太大')

    user_not_exist = (10050, '用户不存在')
    user_registered = (10051, '用户已注册')

    request_too_fast = (10060, '请求太频繁')

    code_error = (10070, '请输入正确的验证码')

    not_active = (10080, '尊敬的用户：\n您可能在未激活设备上登录\n如有疑问，可拨打电话联系客服激活设备\n联系电话：13501882374')

    pulse_error = (10090, '脉诊失败')
    pulse_data_error = (10091, '脉诊提交的数据错误')
    pulse_database_error = (10092, '脉诊数据存储到本地错误')
    pulse_first_error = (10093, '脉诊第一步数据提交出错,未返回id')


def generate_response(error, data=None):
    return {
        'message': error[1],
        'status_code': error[0],
        'data': data
    }


def my_abort(http_status_code=400, **kwargs):
    # my_abort(error=ErrorCode.agency_exists)
    if http_status_code == 400:
        # 重定义400返回参数
        kwargs = generate_response(error=kwargs.get('error', ErrorCode.not_known), data=kwargs.get('message', None))
        app.logger.error(kwargs)
        abort(400, **kwargs)

    abort(http_status_code, **kwargs)


flask_restful.abort = my_abort


@app.errorhandler(400)
@app.errorhandler(401)
@app.errorhandler(403)
@app.errorhandler(404)
@app.errorhandler(409)
@app.errorhandler(410)
@app.errorhandler(411)
@app.errorhandler(412)
@app.errorhandler(413)
@app.errorhandler(414)
@app.errorhandler(415)
def error_to_json(error):
    code = getattr(error, 'code', 400)
    data = getattr(error, 'data', None)
    if data:
        body = data
    else:
        body = {
            'message': ErrorCode.not_known[1],
            'status_code': ErrorCode.not_known[0],
            'data': ''
        }
    return jsonify(body), code


def jwt_error_handler(error):
    return jsonify({
        'message': ErrorCode.access_error[1],
        'status_code': ErrorCode.access_error[0],
        'data': ''
    }), 400


jwt.jwt_error_callback = jwt_error_handler


@app.errorhandler(ExpiredJWTSignatureError)
def expired_error_handler(error):
    return jsonify({
        'message': ErrorCode.expired_error[1],
        'status_code': ErrorCode.expired_error[0],
        'data': ''
    }), 400


@api30_bp.after_request
@api16_bp.after_request
def response_handle(response):
    if response.mimetype == 'application/json':
        if response.status_code == 200:
            data = {
                'status_code': ErrorCode.success[0],
                'message': ErrorCode.success[1],
                'data': json.loads(
                    response.data.decode('utf-8')
                )
            }
            response.data = json.dumps(data).encode('utf-8')

        elif response.status_code == 400:
            response.status_code = 200

    return response
