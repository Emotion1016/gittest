from mimetypes import MimeTypes
import logging

import oss2


class Bucket(object):
    def __init__(self, access_key_id, access_key_secret, endpoint, internal_endpoint, bucket, logger=None):
        self.b = bucket
        self.logger = logger if logger else logging.getLogger('BucketService')
        self.auth = oss2.Auth(access_key_id, access_key_secret)
        self.bucket = oss2.Bucket(self.auth, endpoint, bucket)
        self.bucket2 = oss2.Bucket(self.auth, internal_endpoint or endpoint, bucket)

    def upload_content(self, content, content_type, name, meta=None):
        ext = MimeTypes().guess_extension(content_type)
        if not ext:
            ext = '.%s' % content_type.rsplit('/', 1)[-1]
        headers = {'Content-Type': content_type}
        # headers.update({'x-oss-meta-' + k: v for k, v in meta.items()})
        name = name + ext
        self.logger.debug('upload %d bytes as %s (%s)', len(content), name, content_type)
        response = self.bucket2.put_object(
            name,
            content,
            headers=headers
        )

        self.logger.debug('status %s, request_id %s', response.status, response.request_id)

        return name, response

    def get_thumb_url(self, name, style, lifetime=3600):
        return self.bucket.sign_url('GET', name, lifetime, params={'x-oss-process': style})
