from aliyunsdkdysmsapi.request.v20170525 import SendSmsRequest
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.profile import region_provider


# cannot change according to aliyun document
from flask import logging

REGION = "cn-hangzhou"
PRODUCT_NAME = "Dysmsapi"
DOMAIN = "dysmsapi.aliyuncs.com"


class AliSms(object):
    def __init__(self, access_key_id, access_key_secret, logger=None):
        self.acs_client = AcsClient(access_key_id, access_key_secret, REGION)
        region_provider.add_endpoint(PRODUCT_NAME, REGION, DOMAIN)
        self.logger = logger if logger else logging.getLogger('AliSmsClient')

    def send_sms(self, business_id, phone_numbers, sign_name, template_code, template_param=None):
        self.logger.info(
            'sending req %s: to %s, sign %s, code %s, param %s',
            business_id, phone_numbers, sign_name, template_code, template_param
        )
        smsRequest = SendSmsRequest.SendSmsRequest()
        # template code, required
        smsRequest.set_TemplateCode(template_code)

        # parameters for template
        if template_param is not None:
            smsRequest.set_TemplateParam(template_param)

        # business_id, use uuid4 normally
        smsRequest.set_OutId(business_id)

        # signature name
        smsRequest.set_SignName(sign_name)

        # cellphone to send
        smsRequest.set_PhoneNumbers(phone_numbers)

        smsResponse = self.acs_client.do_action_with_exception(smsRequest)
        self.logger.info('req %s result: %s', business_id, smsResponse)
        return smsResponse

