from flask import jsonify, request
import copy
import json
from flask_restful import reqparse, marshal
from datetime import datetime

from ExaminationModalApi import api30_bp, db
from ExaminationModalApi.model.question_result import QuestionResult, question_fields
from ExaminationModalApi.jwt_login import agency_required, local_user, local_agency


questions = {
    "data": [
        {
            "id": 1,
            "index": 1,
            "label": "您自己觉得容易疲劳或乏力吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 2,
            "index": 2,
            "label": "您容易气短，接不上气吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 3,
            "index": 3,
            "label": "您平时容易患感冒吗?（指每年感冒的次数）",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 4,
            "index": 4,
            "label": "您平时容易怕冷或手脚冰凉吗？ ",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 5,
            "index": 5,
            "label": "您觉得平时手脚心发热吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 6,
            "index": 6,
            "label": "您平时容易感到闷闷不乐、情绪低沉或经常无缘无故叹气吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 7,
            "index": 7,
            "label": "您平时容易感到精神紧张、焦虑不安吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 8,
            "index": 8,
            "label": "您平时容易感到害怕或容易受到惊吓吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 9,
            "index": 9,
            "label": "您平时睡觉时打鼾吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 10,
            "index": 10,
            "label": "您平时觉得口苦或口臭吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 11,
            "index": 11,
            "label": "您平时觉得口粘口腻吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 12,
            "index": 12,
            "label": "您的皮肤一抓就红或者经常出现荨麻疹 (风团、风疹块、风疙瘩)吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 13,
            "index": 13,
            "label": "您的皮肤容易出现青紫瘀斑吗？（皮肤在没有外伤的情况下出现青一块紫一块）",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 14,
            "index": 14,
            "label": "您平时觉得皮肤或口唇干燥或眼睛干涩吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 15,
            "index": 15,
            "label": "您面部或鼻部有油腻感或者油亮发光吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 16,
            "index": 16,
            "label": "您小便时尿道有发热感、尿色浓（深）吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 17,
            "index": 17,
            "label": "您平时容易便秘或大便干燥吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 18,
            "index": 18,
            "label": "您平时大便偏黏、容易粘马桶，或有解不尽的感觉吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 19,
            "index": 19,
            "label": "您容易过敏(对药物、食物、气味、花粉或在季节交替、气候变化时)吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 20,
            "index": 20,
            "label": "您没有感冒时也会打喷嚏吗？ ",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 21,
            "index": 21,
            "label": "您平时经常感到身体困重吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 22,
            "index": 22,
            "label": "您胃脘部、背部或腰膝关节等部位怕冷吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 23,
            "index": 23,
            "label": "您吃(喝)凉的东西就会拉肚子或感到不舒服？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False
        },
        {
            "id": 24,
            "index": 24,
            "label": "您乳房或胁肋部、腹部经常感觉胀痛吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False,
            "gender": "2"
        },
        {
            "id": 25,
            "index": 24,
            "label": "您胁肋部或腹部经常感觉胀痛吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False,
            "gender": "1"
        },
        {
            "id": 26,
            "index": 25,
            "label": "您平时白带颜色发黄吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False,
            "gender": "2"
        },
        {
            "id": 27,
            "index": 25,
            "label": "您的阴囊部位潮湿吗？",
            "options": [
                "没有",
                "很少",
                "有时",
                "经常",
                "总是",
            ],
            "exclusiveOption": 1,
            "multiple": False,
            "gender": "1"
        },
    ]
}


@api30_bp.route('/api30/questions', methods=['GET'])
def question_list():
    gender = request.args.get('gender')
    q = copy.deepcopy(questions['data'])
    if gender:
        q = list(filter(lambda x: x.get('gender') in [str(gender), None], q))
    return jsonify(q)


parser = reqparse.RequestParser()
parser.add_argument('answers', type=lambda x: x, action='append', required=True, help='question answers',
                    location=('json',))


@api30_bp.route('/api30/question', methods=['POST'])
@agency_required()
def question():
    args = parser.parse_args()
    answer = json.dumps(args['answers'])
    question_result = QuestionResult(
        owner=local_user if local_user else None,
        agency=local_agency,
        time=datetime.utcnow(),
        question_version_id=1,
        answer=answer,
        category=2
    )
    db.session.add(question_result)
    db.session.commit()
    return jsonify(marshal(question_result, question_fields))


