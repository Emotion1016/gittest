import random

from flask import jsonify, current_app
from flask_restful import abort, marshal, marshal_with, Resource, reqparse
from sqlalchemy import desc

from ExaminationModalApi import api30_bp, api30, db
from ExaminationModalApi.model.physical_report import PhysicalReport, detail_physical_report_fields, \
    physical_report_page_fields
from ExaminationModalApi.model.products import ServiceDiagnoseResult, CustomizationProductCategory, \
    CustomizationProduct, category_fields
from ExaminationModalApi.model.sign_name import SignName
from ExaminationModalApi.jwt_login import agency_required, local_agency, local_user
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode


class ReportList(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('page', type=int, help='Page of report list')

    @staticmethod
    def list_reports():
        query = PhysicalReport.query.filter(PhysicalReport.agency == local_agency, PhysicalReport.mark != 2,
                                            PhysicalReport.del_flag != 1)
        return query

    @agency_required()
    @marshal_with(physical_report_page_fields)
    def get(self):
        args = self.parser.parse_args()
        page = args.get('page')
        query = self.list_reports()
        if local_user:
            query = query.filter(PhysicalReport.owner == local_user)
        paginate = query.order_by(desc(PhysicalReport.time)). \
            paginate(page=page, per_page=6)
        for report in paginate.items:
            report.face_photo_url = current_app.bucket.get_thumb_url(report.face_result.photo.oss_id,
                                                                     current_app.config['OSS_THUMB_MINI_IMAGE_STYLE'])
            report.tongue_photo_url = current_app.bucket.get_thumb_url(report.tongue_result.photo.oss_id,
                                                                       current_app.config['OSS_THUMB_MINI_IMAGE_STYLE'])

        return paginate


api30.add_resource(ReportList, '/api30/reports')


class ReportDetail(Resource):
    @agency_required()
    def delete(self, report_id):
        query = PhysicalReport.query.get(report_id)
        if not query:
            my_abort(error=ErrorCode.not_found)
        if query.agency_id != local_agency.id:
            my_abort(error=ErrorCode.access_error)

        query.del_flag = 1
        db.session.commit()

        return my_abort(error=ErrorCode.success)


api30.add_resource(ReportDetail, '/api30/report/<report_id>')


@api30_bp.route('/api30/share/<string:key>', methods=['GET', ])
def get_share(key):
    report = PhysicalReport.query.filter(PhysicalReport.key == key, PhysicalReport.del_flag != 1).first()
    if not report:
        abort(404)
    report.face_photo_url = current_app.bucket.get_thumb_url(report.face_result.photo.oss_id,
                                                             current_app.config['OSS_THUMB_IMAGE_STYLE'])
    report.tongue_photo_url = current_app.bucket.get_thumb_url(report.tongue_result.photo.oss_id,
                                                               current_app.config['OSS_THUMB_IMAGE_STYLE'])

    sign_name = SignName.query.filter(SignName.physical_report_id == report.id).first()
    if not sign_name and report.agency.type in ['A', 'C']:
        sign_name = SignName.query.filter(SignName.agency_id == report.agency_id,
                                          SignName.user_id == report.owner_id).first()
    report.sign_name_url = current_app.bucket.get_thumb_url(sign_name.oss_id, current_app.config[
        'OSS_THUMB_IMAGE_STYLE']) if sign_name else None
    report.product = get_product(report.id)

    answer = marshal(report, detail_physical_report_fields)
    answer['id'] = key
    return jsonify(answer)


def get_product(report_id):
    report = PhysicalReport.query.get(report_id)
    if not report:
        my_abort(error=ErrorCode.not_found)
    symptoms = report.symptoms

    name = symptoms[0].name if symptoms else '平和质'
    symptom = ServiceDiagnoseResult.query.filter(ServiceDiagnoseResult.name == name).first()
    if symptom:
        products = CustomizationProductCategory.query. \
            join(CustomizationProduct, CustomizationProduct.category_id == CustomizationProductCategory.id). \
            filter(CustomizationProduct.symptoms.any(id=symptom.id),
                   CustomizationProductCategory.agencies.any(id=report.agency.id)).all()
        data = [i for i in products]
    else:
        data = []
    return marshal(data, category_fields)
