from flask_restful import Resource, marshal_with, marshal
from flask import current_app, request
import json

from ExaminationModalApi import db, api30
from ExaminationModalApi.examination import run
from ExaminationModalApi.jwt_login import local_agency, local_user, login_user_required
from ExaminationModalApi.model.face_result import FaceResult, basic_face_result_fields
from ExaminationModalApi.model.question_result import QuestionResult, question_fields
from ExaminationModalApi.model.sign_name import SignName
from ExaminationModalApi.model.physical_report import PhysicalReport, create_physical_report_parser, \
    detail_physical_report_fields
from ExaminationModalApi.model.symptom import Symptom
from ExaminationModalApi.model.tongue_result import TongueResult, basic_tongue_result_fields
from ExaminationModalApi.model.user_info_history import UserInfoHistory
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode
from ExaminationModalApi.api16.problems import save_report_problem_result
from ExaminationModalApi.model.util import get_first_before_this
from ExaminationModalApi.api16.examination import get_ip


class Examination(Resource):
    @staticmethod
    def get_owner():
        return local_user if local_user else None

    @staticmethod
    def get_agency():
        return local_agency if local_agency else None

    @login_user_required()
    @marshal_with(detail_physical_report_fields)
    def post(self):
        args = create_physical_report_parser.parse_args()
        owner, agency = self.get_owner(), self.get_agency()

        try:
            tongue_result = TongueResult.query.get_or_404(args['tongue_result_id'])
            face_result = FaceResult.query.get_or_404(args['face_result_id'])
            question_result = QuestionResult.query.get_or_404(args['question_result_id'])
            pulse_result_id = args["pulse_result_id"]
            exist_report = PhysicalReport.query.with_lockmode(mode='update') \
                .filter(PhysicalReport.tongue_result == tongue_result,
                        PhysicalReport.face_result == face_result,
                        PhysicalReport.question_result == question_result).first()
            if exist_report:
                return exist_report

            report = create_report(face_result, tongue_result, question_result, pulse_result_id, args, agency, owner)

            if face_result.mark == 1 or tongue_result.mark == 1:
                hide_f = FaceResult.query.filter(FaceResult.photo_id == face_result.photo_id,
                                                 FaceResult.mark == 2).first()
                hide_t = TongueResult.query.filter(TongueResult.photo_id == tongue_result.photo_id,
                                                   TongueResult.mark == 2).first()
                if hide_f or hide_t:
                    create_report(hide_f or face_result, hide_t or tongue_result, question_result, args, agency, owner)

            return report
        except Exception as e:
            db.session.rollback()
            current_app.logger.exception('cannot handle request %r, %s' % (request.json, e))
            my_abort(error=ErrorCode.not_known)


api30.add_resource(Examination, '/api30/examinations')


def create_report(face_result, tongue_result, question_result, pulse_result_id, args, agency, owner):
    params = dict()
    params.update(marshal(question_result, question_fields))
    params.update(marshal(face_result, basic_face_result_fields))
    params.update(marshal(tongue_result, basic_tongue_result_fields))

    # current_app.logger.debug('loaded params: %s', pprint.pformat(params))
    result = run(params, _type=2)

    new_info = args.get('user_info')
    if new_info:
        new_info['medical_history'] = args['med_recommend'] or []
    if bool(agency) and bool(owner):
        if new_info:
            owner.update_info(new_info)

    user_info = UserInfoHistory.from_user(owner, new_info, agency.agency_info)

    city = get_ip(request.remote_addr)
    symptom_status = json.dumps(result['symptom_status'])

    report = PhysicalReport(
        owner=owner,
        agency=agency,
        face_result=face_result,
        tongue_result=tongue_result,
        question_result=question_result,
        time=result['report_time'],
        ip=str(request.remote_addr),
        city=city,
        client_info=args['client_info'],
        channel=args.get('channel'),
        sn=request.headers.get('sn'),
        symptom_status=symptom_status,
        solution_json=json.dumps(result['solutions']['keys']),
        ua=request.user_agent.string if request.user_agent else '',
        custom_id=agency.custom_id if agency else None,
        mark=0
    )
    if pulse_result_id:
        report.pulse_result_id = pulse_result_id
    report.medical_history = args.get('med_recommend') or []
    if local_user:
        local_user.medical_history = args.get('med_recommend') or []
    report.user_info = user_info
    db.session.add(report)
    if args.get('sign_name_id'):
        sign_name = SignName.query.get(args.get('sign_name_id'))
        sign_name.physical_report_id = report.id
    if args.get('problem_options'):
        save_report_problem_result(report, args['problem_options'])

    for s in result['symptoms']:
        db.session.add(Symptom(physical_report=report, name=s['name'], score=s['score']))

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        current_app.logger.exception('db commit error: %s' % e)
        current_app.logger.exception(str(args))
    return report
