from ExaminationModalApi.model.mirror import Mirror, create_mirror_parser, basic_mirror_fields
from ExaminationModalApi.jwt_login import agency_required, local_agency
from ExaminationModalApi import api30_bp, db
from ExaminationModalApi.views.error_handlers import my_abort, ErrorCode

from flask import jsonify, request
from flask_restful import marshal


@api30_bp.route('/api30/active', methods=['POST'])
@agency_required()
def active_mirror():
    args = create_mirror_parser.parse_args()

    m = Mirror.query.filter(Mirror.deviceid == args['deviceid']).first()
    if not m:
        m = Mirror(**args)
        m.agencyname = local_agency.login_name
        if local_agency.vendor:
            m.vendor_code = local_agency.vendor.code
            if local_agency.vendor.custom:
                m.custom_name = local_agency.vendor.custom.name
        m.status = 1
        m.accept_type = 3
        db.session.add(m)

    else:
        m.longtitude = args['longtitude']
        m.latitude = args['latitude']
        m.model = args['model']
        if not m.version:
            m.version = args['version']
        if not m.agencyname:
            m.agencyname = local_agency.login_name
        if m.status is None:
            m.status = 1
        if m.accept_type is None:
            m.accept_type = 3

    db.session.commit()
    if m.status != 2:
        my_abort(error=ErrorCode.success)
    else:
        my_abort(error=ErrorCode.not_active)


@api30_bp.route('/api30/xsd/active', methods=['POST'])
def active_xsd_mirror():
    args = create_mirror_parser.parse_args()

    m = Mirror.query.filter(Mirror.deviceid == args['deviceid']).first()
    if not m:
        m = Mirror(**args)
        m.custom_name = '新时代'
        m.status = 1
        m.accept_type = 3
        db.session.add(m)

    else:
        m.longtitude = args['longtitude']
        m.latitude = args['latitude']
        m.model = args['model']
        m.version = args['version']

    db.session.commit()
    if m.status != 2:
        my_abort(error=ErrorCode.success)
    else:
        my_abort(error=ErrorCode.not_active)


@api30_bp.route('/api30/get_mirror_data', methods=['GET'])
def get_mirror_data():
    m = Mirror.query.all()
    return jsonify(marshal(m, basic_mirror_fields))