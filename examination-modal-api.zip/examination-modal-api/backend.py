# -*- encoding: utf-8 -*-
from wsgi import app
import uuid
import os
import time


@app.before_first_request
def send_alert_message():
    tmp = 'tmp'
    send = True
    if os.path.isfile(tmp):
        with open(tmp) as f:
            s = f.read()

        if int(time.time()) < int(s):
            send = False

    if send:
        app.sms.send_sms(
            uuid.uuid1(),
            '13636382436',
            app.config['SMS_SIGNATURE'],
            'SMS_149422770',
            dict(server='m16-dev')
        )
        with open(tmp, 'w') as f:
            f.write(str(int(time.time()) + 36000))


if __name__ == "__main__":
    app.run()