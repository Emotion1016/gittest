# -*- encoding: utf-8 -*-
import tornado.httpserver
import tornado.ioloop
import tornado.web
import tornado.gen

from tornado.options import options, define
from tornado.wsgi import WSGIContainer
from ExaminationModalApi import app
import pymysql
import tormysql
from tormysql import DictCursor
from pydiagnosis import autoPhoto


class PhotoHandler(tornado.web.RequestHandler):
    async def get(self):
        id = self.get_query_argument('id')
        sql = 'select * from face_result where id=%s' % id
        with (await self.application.pool.Connection()) as conn:
            with conn.cursor(DictCursor) as cursor:
                await cursor.execute(sql)
                data = cursor.fetchone()
                del data['time']
        self.write(data)
        self.finish()


class AutoDetectHandler(tornado.web.RequestHandler):
    async def post(self):
        photo = self.request.files.get('photo')[0]['body']
        ans = autoPhoto(photo)
        self.write({'data': ans.to_dict()})


flask_app = WSGIContainer(app)

handlers = [
    # (r"/api_tornado/photo", PhotoHandler),
    (r"/api_tornado/photos/auto_photo", AutoDetectHandler),
    (r".*", tornado.web.FallbackHandler, dict(fallback=flask_app)),
]


class Application(tornado.web.Application):
    def __init__(self):
        # self.pool = tormysql.ConnectionPool(
        #     max_connections=20,
        #     idle_seconds=7200,
        #     wait_connection_timeout=3,
        #     host='127.0.0.1',
        #     user='m_dev_root',
        #     passwd='m_dev_1234',
        #     db='m_test',
        #     port=3307,
        # )
        tornado.web.Application.__init__(self, handlers=handlers, debug=True)


define('port', default=5000, help='run on the port', type=int)

if __name__ == "__main__":
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()
