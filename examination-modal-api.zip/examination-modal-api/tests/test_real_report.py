import os
os.environ['EXAMINATIONMODALAPI_SETTINGS'] = '../settings.cfg'

from ExaminationModalApi.api16.examination import run
from ExaminationModalApi.model.question_result import question_fields
from ExaminationModalApi.model.face_result import basic_face_result_fields
from ExaminationModalApi.model.tongue_result import basic_tongue_result_fields
from ExaminationModalApi.model.report import Report
from flask_restful import marshal


report_id = 1815
report = Report.query.get(report_id)

params = dict()

question_result = report.question_result
face_result = report.face_result
tongue_result = report.tongue_result

basic_face_result_fields.__delitem__('report_face_url')
basic_tongue_result_fields.__delitem__('report_tongue_url')

params.update(marshal(question_result, question_fields))
params.update(marshal(face_result, basic_face_result_fields))
params.update(marshal(tongue_result, basic_tongue_result_fields))

result = run(params, _type=2)
print(result)