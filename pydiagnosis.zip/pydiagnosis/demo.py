#!/usr/bin/env python
from glob import glob
from pprint import pprint

import importlib
import _diagnosis
import pydiagnosis


def test_faces():
    for fn in glob('tests/data/testFace/*.jpg'):
        with open(fn, 'rb') as f:
            print('Result of file ', fn)
            result = pydiagnosis.face(f.read(-1))
            print(result)
            pprint(result.to_dict())


def test_tongues():
    for fn in glob('tests/data/testTongue/*.jpg'):
    # for fn in [
    #     'tests/data/testTongue/neg1.jpg',
    #     'tests/data/testTongue/neg2.png',
    #     'tests/data/testTongue/pos6.jpg',
    # ]:
        importlib.reload(pydiagnosis)
        importlib.reload(_diagnosis)
        with open(fn, 'rb') as f:
            print('Result of file ', fn)
            result = pydiagnosis.tongue(f.read(-1))
            print(result)
            pprint(result.to_dict())


if __name__ == '__main__':
    # test_faces()
    test_tongues()

