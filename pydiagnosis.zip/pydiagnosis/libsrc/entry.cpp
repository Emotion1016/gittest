#define PY_SSIZE_T_CLEAN 1
#include <Python.h>
#include <vector>

#include "ml/TCMProInterface.h"

using namespace std;
using namespace cv;


typedef enum {
    DIAGNOSIS_TYPE_FACE,
    DIAGNOSIS_TYPE_TONGUE,
} DiagnosisType;

static PyObject * diagnosis_test(PyObject *self, PyObject *args)
{
    char* tonf = NULL;
    char* facef = NULL;
    IplImage *image_in1 = NULL;
    IplImage *image_in2 = NULL;
	image_in1 = cvLoadImage("data/testFace/pos1.jpg");
	if(!image_in1)
	{
		cout<<"Loading image is wrong!!"<<endl;
        goto out;
	}
	//cvShowImage("in",image_in1);
	facef = tcmFacePro(image_in1,1);
	cout<<"tcmFaceFeature = "<<facef<<endl;

	image_in2 = cvLoadImage("data/testTongue/pos1.jpg");
	if(!image_in2)
	{
		cout<<"Loading image 2 is wrong!!"<<endl;
        goto out;
	}
    tonf = tcmTonguePro(image_in2,1);
    cout<<"tcmTongueFeature = "<<tonf<<endl;

out:
    Py_RETURN_NONE;
}

static IplImage* _bytes_to_image(char const* buf, int len) {
    Mat raw, img;
    IplImage *out;
    if (len == 0) return NULL;

    raw = Mat(1, len, CV_8UC1, (void*)buf);
    img = imdecode(Mat(raw), CV_LOAD_IMAGE_UNCHANGED);

    if (img.empty())
    {
        return NULL;
    }

    out = new IplImage(img);
    return out;

}

static PyObject* _diagnosis(PyObject *self, PyObject *args, DiagnosisType type)
{
    int ok;
    const char* buf = NULL;
    Py_ssize_t len = 0;
    char const* ans = NULL;
    IplImage *image_in1 = NULL;
    Mat raw, img;

    if (
        type != DIAGNOSIS_TYPE_FACE &&
        type != DIAGNOSIS_TYPE_TONGUE
       ) {
        PyErr_SetString(PyExc_RuntimeError, "internal error: invalid diagnosis type");
        goto out;
    }

    ok = PyArg_ParseTuple(args, "y#", &buf, &len);
    if (!ok) {
        goto out;
    }

    raw = Mat(1, len, CV_8UC1, (void*)buf);
    img = imdecode(Mat(raw), CV_LOAD_IMAGE_UNCHANGED);

    if (img.empty())
    {
        PyErr_SetString(PyExc_RuntimeError, "cannot load the image.");
        goto out;
    }

    image_in1 = new IplImage(img);

    //image_in1 = _bytes_to_image(buf, len);
    if (!image_in1) {
        PyErr_SetString(PyExc_RuntimeError, "cannot load the image.");
        goto out;
    }

    if (type == DIAGNOSIS_TYPE_FACE) {
        ans = tcmFacePro(image_in1, 1);
    }
    else if (type == DIAGNOSIS_TYPE_TONGUE) {
        ans = tcmTonguePro(image_in1, 1);
    }

    if (!ans) {
        PyErr_SetString(PyExc_RuntimeError, "failed to run diagnosis.");
    }

out:
    if (image_in1) {
        delete image_in1;
        image_in1 = NULL;
    }
    if (ans) {
        return Py_BuildValue("s", ans);
    } else {
        return NULL;
    }
}

static PyObject * diagnosis_face(PyObject *self, PyObject *args)
{
    return _diagnosis(self, args, DIAGNOSIS_TYPE_FACE);
}

static PyObject * diagnosis_tongue(PyObject *self, PyObject *args)
{
    return _diagnosis(self, args, DIAGNOSIS_TYPE_TONGUE);
}

static PyMethodDef methods[] = {
    {"test",  diagnosis_test, METH_VARARGS, "Run test procedure."},
    {"face",  diagnosis_face, METH_VARARGS, "Run face diagnosis."},
    {"tongue",  diagnosis_tongue, METH_VARARGS, "Run tongue diagnosis."},
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

static struct PyModuleDef module = {
    PyModuleDef_HEAD_INIT,
    "_pydiagnosis",   /* name of module */
    NULL, /* module documentation, may be NULL */
    -1,       /* size of per-interpreter state of the module,
                 or -1 if the module keeps state in global variables. */
    methods
};

PyMODINIT_FUNC
PyInit__diagnosis(void)
{
    return PyModule_Create(&module);
}

