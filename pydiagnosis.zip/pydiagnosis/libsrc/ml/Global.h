#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv/cxcore.h>
#include <opencv/ml.h>
#include "math.h"
#include <iostream>
#include <sstream>
#include <string>

using namespace std;
using namespace cv;

