#include "faceDignosis.h"

char* tcmFacePro(IplImage* input,int haarFaceDetectSwitch=0);
char* tcmTonguePro(IplImage* input,int haarTongueDetectSwitch=0);