pydiagnosis
===========

Run face & tongue diagnosis with Python.

Usage
-----

Installation
------------

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

`pydiagnosis` was written by `ZHU Jie <zhujie@zhiyuntcm.com>`_.
