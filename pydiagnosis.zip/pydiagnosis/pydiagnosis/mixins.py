from collections import OrderedDict


class ToDictMixin(object):
    def to_dict(self):
        ans = OrderedDict()
        ans['diagnosis'] = diagnosis = OrderedDict()
        for k, v in self.TO_DICT_NAME_MAPPING.items():
            diagnosis[k] = getattr(self, v)
        for k in self._fields:
            ans[k] = getattr(self, k)
        return ans


class FromResultStringMixin(object):
    @classmethod
    def from_result(cls, s):
        converts = cls.RESULT_FIELD_CONVERTS
        parameters = list(filter(bool, s.strip().split(',')))
        assert len(parameters) <= len(converts), 'invalid result string: ' + repr(s)
        fields = []
        for c, v in zip(converts, parameters):
            fields.append(c(v))

        if len(fields) < len(converts):
            fields += [None, ] * (len(converts) - len(fields))
        return cls(*fields)

