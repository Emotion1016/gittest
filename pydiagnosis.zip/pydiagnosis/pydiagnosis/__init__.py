"""pydiagnosis - Run face & tongue diagnosis with Python."""

__version__ = '0.4.2'
__author__ = 'Liu ShaoJie <liushaojie@zhiyuntcm.com>'
__all__ = []

from .face import *
from .tongue import *

