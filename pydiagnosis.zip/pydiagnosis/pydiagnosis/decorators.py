from functools import wraps


def run_if(condition, otherwise=None):
    def _decorator(f):
        @wraps(f)
        def _f(self, *args, **kwargs):
            if condition(self):
                return f(self, *args, **kwargs)
            else:
                return otherwise
        return _f
    return _decorator
