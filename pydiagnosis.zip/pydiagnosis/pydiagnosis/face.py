from collections import namedtuple
from _diagnosis import face as _face

from pydiagnosis.decorators import run_if
from .mixins import ToDictMixin, FromResultStringMixin

FaceDiagnosisResultBase = namedtuple(
    'FaceDiagnosisResultBase',
    (
        'diagnosis_raw', 'face_L', 'face_a', 'face_b', 'gloss',
        'less_gloss', 'none_gloss', 'lip_L', 'lip_a', 'lip_b',
    )
)


class FaceDiagnosisResult(FaceDiagnosisResultBase, ToDictMixin, FromResultStringMixin):
    TO_DICT_NAME_MAPPING = {
        'faceDetectRes': 'face_detect_result',
        'faceColor': 'face_color',
        'faceGloss': 'face_gloss',
        'lipDetectRes': 'lip_detect_result',
        'lipColor': 'lip_color',
    }
    RESULT_FIELD_CONVERTS = (int, int, int, int, float, float, float, int, int, int)

    @property
    def face_detect_result(self):
        return self.diagnosis_raw % 10

    @property
    @run_if(lambda self: self.face_detect_result)
    def face_color(self):
        return self.diagnosis_raw // 10 % 10

    @property
    @run_if(lambda self: self.face_detect_result)
    def face_gloss(self):
        return self.diagnosis_raw // 100 % 10

    @property
    @run_if(lambda self: self.face_detect_result, otherwise=0)
    def lip_detect_result(self):
        return self.diagnosis_raw // 1000 % 10

    @property
    @run_if(lambda self: self.lip_detect_result)
    def lip_color(self):
        return self.diagnosis_raw // 10000 % 10


def face(image):
    return FaceDiagnosisResult.from_result(_face(image))

