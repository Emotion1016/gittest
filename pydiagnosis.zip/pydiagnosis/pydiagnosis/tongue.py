from collections import namedtuple
from _diagnosis import tongue as _tongue

from pydiagnosis import run_if

from .mixins import ToDictMixin, FromResultStringMixin


TongueDiagnosisResultBase = namedtuple(
    'TongueDiagnosisResultBase',
    (
        'diagnosis_raw', 'crack', 'nature_L', 'nature_a', 'nature_b',
        'coat_L', 'coat_a', 'coat_b',
    )
)


class TongueDiagnosisResult(TongueDiagnosisResultBase, ToDictMixin, FromResultStringMixin):
    TO_DICT_NAME_MAPPING = {
        'tongueDetectRes': 'tongue_detect_result',
        'tongueCrack': 'tongue_crack',
        'tongueFatThin': 'tongue_fat_thin',
        'tongueCoatThickness': 'tongue_coat_thickness',
        'tongueCoatColor': 'tongue_coat_color',
        'tongueNatureColor': 'tongue_nature_color',
    }

    RESULT_FIELD_CONVERTS = (int, ) * 8

    @property
    def tongue_detect_result(self):
        return self.diagnosis_raw % 10

    @property
    @run_if(lambda self: self.tongue_detect_result)
    def tongue_crack(self):
        return self.diagnosis_raw // 10 % 10

    @property
    @run_if(lambda self: self.tongue_detect_result)
    def tongue_fat_thin(self):
        return self.diagnosis_raw // 100 % 10

    @property
    @run_if(lambda self: self.tongue_detect_result)
    def tongue_coat_thickness(self):
        return self.diagnosis_raw // 1000 % 10

    @property
    @run_if(lambda self: self.tongue_detect_result)
    def tongue_coat_color(self):
        return self.diagnosis_raw // 10000 % 10

    @property
    @run_if(lambda self: self.tongue_detect_result)
    def tongue_nature_color(self):
        return self.diagnosis_raw // 100000 % 10

def tongue(image):
    return TongueDiagnosisResult.from_result(_tongue(image))

